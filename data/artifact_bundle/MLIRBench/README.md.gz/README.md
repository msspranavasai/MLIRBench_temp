---
task_categories:
  - text-classification
  - text-generation
  - feature-extraction
language:
  - en
tags:
  - MLIR
  - compiler
  - compilers
  - program-analysis
  - semantic-equivalence
  - code-reasoning
  - benchmark
  - linalg
  - torch-mlir
pretty_name: MLIRBench
size_categories:
  - 10K<n<100K
---

# MLIRBench: A Benchmark and Dataset for Compiler and Hardware-Aware Reasoning

MLIRBench is a benchmark for evaluating language models on semantic reasoning about programs in the Multi-Level Intermediate Representation (MLIR). It includes original and mutated MLIR programs, mutation provenance, execution-related annotations, model responses, and model evaluation records. The benchmark covers the `linalg` and `torch` dialects and five mutation levels.

## Dataset details

**Authors:** Pranava Sai Maganti, Meghasyam Peddireddy, Kaining Gao, Farhan Ahmed, Muzakker Hossain, and Ali Jannesari.

**Repository:** [msspranavasai/MLIRBench](https://github.com/msspranavasai/MLIRBench)

**Dataset:** [mlirbench/MLIRBench](https://huggingface.co/datasets/mlirbench/MLIRBench)

**Paper:** _MLIRBench: A Benchmark and Dataset for Compiler and Hardware-Aware Reasoning_. Accepted to CGO 2027 (Practical and Experience track). The arXiv link will be added after publication.

## Dataset at a glance

| Property                                           |     Value |
| -------------------------------------------------- | --------: |
| Curated PyTorch seed programs                      |        40 |
| Unique original–mutated program pairs              |     1,768 |
| `linalg` program pairs                             |       888 |
| `torch` program pairs                              |       880 |
| Mutation levels                                    | 5 (L1–L5) |
| Evaluated language models                          |         9 |
| Model reasoning records                            |    15,912 |
| Model evaluation records                           |    15,907 |
| Gemini reasoning records without judged evaluation |         5 |

Each program pair has a stable `program_id` used to connect records across views. The nine views are complementary representations of the same benchmark, **not nine disjoint datasets**.

### Dataset views

| View                  |   Rows | Contents                                                                           |
| --------------------- | -----: | ---------------------------------------------------------------------------------- |
| `core`                |  1,768 | Program pairs, mutation requirements, semantic annotations, and failure categories |
| `difficulty`          |  1,768 | Mutation-level difficulty groupings and aggregated evaluation information          |
| `errors`              | 15,912 | Per-model error-related records                                                    |
| `evaluation`          | 15,907 | Judged model predictions, verdicts, and scores                                     |
| `master`              |  1,768 | Consolidated program, mutation, validation, and execution-related metadata         |
| `model_arena`         | 15,907 | Per-model evaluation records for comparison                                        |
| `mutation_provenance` |  1,768 | Mutation requirements, validation history, and pipeline provenance                 |
| `performance`         |  1,768 | Program-pair runtime measurements where available                                  |
| `reasoning`           | 15,912 | Per-model reasoning outputs and semantic explanations                              |

The exported views are supplied as JSONL and CSV files, alongside `dataset_info.json` metadata. Nested fields should be read from JSONL when their structured representation matters; CSV nested fields may use JSON or Python-literal formatting.

### Evaluated models

The release includes the following nine model identifiers:

- `claude-haiku-4-5`
- `claude-sonnet-4-5`
- `gemini-3.1-pro-preview`
- `glm-5.1`
- `gpt-4.1-mini`
- `gpt-oss-120b`
- `kimi-k2.6`
- `llama-4`
- `qwen3-coder-next`

Each model has 1,768 records in `reasoning` and `errors`. Eight models have 1,768 judged records each in `evaluation` and `model_arena`. Gemini has 1,763 judged records because five model failures do not have valid judge results. **Do not interpret missing evaluations as a score of zero.**

## Labels and evaluation

The execution-related label vocabulary is:

- **`EQUIV`**: The program pair was recorded as producing matching behavior under the benchmark's validation procedure.
- **`DIVERGE`**: The program pair was recorded as producing different behavior under the benchmark's validation procedure.
- **`ERROR`**: At least one program encountered an execution-related failure in the benchmark's validation procedure.

These are benchmark labels based on the recorded validation setup, not proofs of equivalence for every possible input or execution environment. A model's `predicted_label` is distinct from the benchmark's `ground_truth_label`. Model-generated explanations and predictions must not be treated as independent ground truth.

## Dataset creation

MLIRBench was constructed from 40 curated PyTorch programs lowered into MLIR's `torch` and `linalg` dialects. A mutation pipeline generated dialect-aware transformations across five levels. The pipeline included mutation generation, compiler verification, execution validation, model reasoning, and judging.

The recorded execution-validation configuration used IREE with deterministic inputs and bit-exact output comparison. Reported performance measurements are specific to the original measurement setup and should not be treated as portable hardware performance estimates.

## Data completeness and known limitations

### Three recovered program records

An export audit identified three program IDs missing from the unique program sets in the original `core`, `master`, and `performance` exports, alongside three identical duplicate rows. The processed release removes the duplicates and restores the missing program IDs using matching reasoning records and mutation provenance:

- `torch_seed2_prog12_T2_R1`
- `torch_seed3_prog27_T1_R3`
- `torch_seed3_prog27_T1_R4`

Their program text and mutation provenance were cross-checked against the original mutation-generation archive. **The original execution logs, compilation statuses, embedded execution inputs, and runtime measurements for these three records were not recovered.** Unavailable fields are represented as `null` in the processed `master` and `performance` views. Their mutation-verification records must not be interpreted as proof that the missing execution runs succeeded.

For analyses requiring complete execution evidence or measured runtimes, exclude these three program IDs or explicitly handle missing values. Do not replace missing timings with zero.

### Five unjudged Gemini records

The following Gemini records have reasoning/error entries but no valid judged evaluation:

- `seed3_linalg_prog24_L5_R4`
- `seed3_linalg_prog24_L5_R5`
- `seed3_linalg_prog25_L5_R5`
- `seed3_linalg_prog30_L5_R4`
- `seed3_linalg_prog30_L5_R5`

Consequently, `reasoning` and `errors` have 15,912 rows, while `evaluation` and `model_arena` have 15,907 rows. Analyses comparing all nine models should specify how missing evaluations are handled.

### General limitations

- The benchmark focuses on `linalg` and `torch` MLIR dialects and may not generalize to other dialects.
- Execution-derived labels depend on the original compiler, runtime, inputs, and validation configuration; they are not universal correctness proofs.
- The benchmark is not a substitute for formal verification or production compiler testing.
- Runtime measurements depend on the original environment and should not be compared across hardware without appropriate controls.
- Some fields contain model-generated content, which may be inaccurate even when a program pair has an established benchmark label.

## Intended uses

MLIRBench supports research on MLIR program understanding, semantic equivalence classification, mutation analysis, compiler-aware reasoning, model evaluation, and fine-tuning for program-analysis tasks. Join views using `program_id` and, for per-model views, the model identifier field.

It is not intended to establish production compiler correctness, certify safety-critical transformations, or serve as a general-purpose natural-language benchmark.

## Data integrity

The processed release was audited for unique program IDs, expected per-view row counts, per-model record counts, consistency of shared program fields, JSONL/CSV row equivalence, and dataset metadata counts. All nine processed views passed those structural consistency checks. These checks do not recover missing execution evidence or independently rerun the original benchmark.

## Citation

```
Pranava Sai Maganti, Meghasyam Peddireddy, Muzakker Hossain,
Kaining Gao, Farhan Ahmed, and Ali Jannesari. "MLIRBench: A Benchmark and Dataset for Compiler and Hardware-Aware Reasoning." In Proceedings of the 2027 IEEE/ACM International Symposium on Code Generation and Optimization (CGO 2027), Salt Lake City, Utah, USA, March 2027. (Accepted)
```

### BibTeX

If you use MLIRBench in your research, please cite our paper:

```bibtex
@misc{maganti2027mlirbench,
  title     = {{MLIRBench} - A Benchmark and Dataset for
               Compiler and Hardware-Aware Reasoning},
  author    = {Maganti, Pranava Sai and
               Peddireddy, Meghasyam and
               Hossain, Muzakker and
               Gao, Kaining and
               Ahmed, Farhan and
               Jannesari, Ali},
  booktitle = {Proceedings of the 2027 IEEE/ACM
               International Symposium on Code
               Generation and Optimization (CGO)},
  year      = {2027},
  address   = {Salt Lake City, Utah, USA},
  note      = {Accepted for publication}
}
```

**The arXiv identifier, DOI, and final proceedings citation will be added once available.**

## Authors and Contact

<table>
  <tr>
    <td align="center" width="33%">
      <b>Pranava Sai Maganti</b><br/>
      <a href="mailto:pranava7@iastate.edu">pranava7@iastate.edu</a><br/>
      Iowa State University<br/>
      Ames, Iowa, USA
    </td>
    <td align="center" width="33%">
      <b>Meghasyam Peddireddy</b><br/>
      <a href="mailto:syam@iastate.edu">syam@iastate.edu</a><br/>
      Iowa State University<br/>
      Ames, Iowa, USA
    </td>
    <td align="center" width="33%">
      <b>Muzakker Hossain</b><br/>
      <a href="mailto:muzakker@iastate.edu">muzakker@iastate.edu</a><br/>
      Iowa State University<br/>
      Ames, Iowa, USA
    </td>
  </tr>
  <tr>
    <td align="center">
      <b>Kaining Gao</b><br/>
      <a href="mailto:kaigao@iastate.edu">kaigao@iastate.edu</a><br/>
      Iowa State University<br/>
      Ames, Iowa, USA
    </td>
    <td align="center">
      <b>Farhan Ahmed</b><br/>
      <a href="mailto:fahmed@iastate.edu">fahmed@iastate.edu</a><br/>
      Iowa State University<br/>
      Ames, Iowa, USA
    </td>
    <td align="center">
      <b>Ali Jannesari</b><br/>
      <a href="mailto:jannesar@iastate.edu">jannesar@iastate.edu</a><br/>
      Iowa State University<br/>
      Ames, Iowa, USA
    </td>
  </tr>
</table>
