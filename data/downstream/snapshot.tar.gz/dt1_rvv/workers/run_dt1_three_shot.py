import json
from pathlib import Path

import pandas as pd
import torch

from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

from dt1_common import (
    compute_metrics,
    extract_label,
    save_metrics,
)


MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

TEST_PATH = ROOT / "outputs" / "rvv_benefit_ground_truth.csv"
DEMOS_PATH = ROOT / "outputs" / "dt1_three_shot_examples.csv"

OUTPUT_PATH = ROOT / "outputs" / "dt1_three_shot_predictions.csv"
METRICS_PATH = ROOT / "outputs" / "dt1_three_shot_metrics.json"

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 8


# ============================================================
# Load data
# ============================================================

test_df = pd.read_csv(TEST_PATH)
demos = pd.read_csv(DEMOS_PATH)


# ============================================================
# Tokenizer
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"


# ============================================================
# Build the three MLIRBench demonstrations
# ============================================================

demo_messages = []

for _, demo in demos.iterrows():
    mlir = Path(demo["mlir_path"]).read_text(encoding="utf-8")

    demo_user = f"""
You are analyzing an MLIR program for RISC-V.

The program can be compiled in two configurations:

1. scalar RISC-V
2. RISC-V Vector Extension (RVV)

Predict the expected static instruction-count reduction obtained
by enabling RVV instead of scalar RISC-V.

Use exactly one of these benefit classes:

LOW:
less than 5% instruction-count reduction

MEDIUM:
at least 5% but less than 15%

HIGH:
15% or greater instruction-count reduction

Base your prediction only on the MLIR structure.

Return exactly one word:
LOW
MEDIUM
or
HIGH

MLIR:

```mlir
{mlir}
```

Benefit:
""".strip()

    demo_messages.append(
        {
            "role": "user",
            "content": demo_user,
        }
    )

    demo_messages.append(
        {
            "role": "assistant",
            "content": str(demo["rvv_benefit"]),
        }
    )


# ============================================================
# Prompt
# ============================================================

def build_prompt(row):
    mlir = Path(row["mlir_path"]).read_text(encoding="utf-8")

    final_user = f"""
Now classify this unseen MLIR program.

The program can be compiled in two configurations:

1. scalar RISC-V
2. RISC-V Vector Extension (RVV)

Predict the expected static instruction-count reduction obtained
by enabling RVV instead of scalar RISC-V.

Use exactly one of these benefit classes:

LOW:
less than 5% instruction-count reduction

MEDIUM:
at least 5% but less than 15%

HIGH:
15% or greater instruction-count reduction

Base your prediction only on the MLIR structure.
You do not have access to compiler outputs or execution results.

Return exactly one word:
LOW
MEDIUM
or
HIGH

MLIR:

```mlir
{mlir}
```

Benefit:
""".strip()

    messages = demo_messages + [
        {
            "role": "user",
            "content": final_user,
        }
    ]

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


# ============================================================
# Preflight context-length check BEFORE loading the model
# ============================================================

prompt_lengths = []

for _, row in test_df.iterrows():
    prompt = build_prompt(row)

    length = len(
        tokenizer(
            prompt,
            add_special_tokens=False,
        )["input_ids"]
    )

    prompt_lengths.append(length)

print("\n3-shot prompt lengths:")
print("Min:", min(prompt_lengths))
print("Mean:", sum(prompt_lengths) / len(prompt_lengths))
print("Max:", max(prompt_lengths))

if max(prompt_lengths) > MAX_SEQ_LEN:
    raise RuntimeError(
        "Three-shot prompt exceeds context limit: "
        f"{max(prompt_lengths)} > {MAX_SEQ_LEN}"
    )


# ============================================================
# Model
# ============================================================

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model.eval()


# ============================================================
# Run evaluation
# ============================================================

predictions = []
raw_outputs = []

for _, row in tqdm(
    test_df.iterrows(),
    total=len(test_df),
    desc="DT1 MLIRBench 3-shot",
):
    prompt = build_prompt(row)

    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=False,
    ).to("cuda")

    with torch.inference_mode():
        output = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    generated = tokenizer.decode(
        output[0][inputs["input_ids"].shape[1]:],
        skip_special_tokens=True,
    ).strip()

    raw_outputs.append(generated)
    predictions.append(extract_label(generated))


# ============================================================
# Save
# ============================================================

test_df["prediction"] = predictions
test_df["raw_output"] = raw_outputs
test_df["correct"] = (
    test_df["prediction"] == test_df["rvv_benefit"]
)

test_df.to_csv(
    OUTPUT_PATH,
    index=False,
)

metrics = compute_metrics(
    test_df["rvv_benefit"],
    test_df["prediction"],
    test_df["reduction_pct"],
)

metrics["prompt_length_min"] = min(prompt_lengths)
metrics["prompt_length_mean"] = (
    sum(prompt_lengths) / len(prompt_lengths)
)
metrics["prompt_length_max"] = max(prompt_lengths)

save_metrics(
    metrics,
    METRICS_PATH,
)

print("\nMetrics:")
print(json.dumps(metrics, indent=2))

print("\nSaved:", OUTPUT_PATH)
print("Saved:", METRICS_PATH)
