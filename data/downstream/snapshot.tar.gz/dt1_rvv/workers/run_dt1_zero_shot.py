import json
from pathlib import Path

import pandas as pd
import torch

from tqdm.auto import tqdm

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
)

from dt1_common import (
    compute_metrics,
    extract_label,
    save_metrics,
)


MODEL_NAME = (
    "Qwen/Qwen2.5-Coder-14B-Instruct"
)

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

TEST_PATH = (
    ROOT
    / "outputs"
    / "rvv_benefit_ground_truth.csv"
)

OUTPUT_PATH = (
    ROOT
    / "outputs"
    / "dt1_zero_shot_predictions.csv"
)

METRICS_PATH = (
    ROOT
    / "outputs"
    / "dt1_zero_shot_metrics.json"
)


MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 8


# ============================================================
# Load test data
# ============================================================

df = pd.read_csv(
    TEST_PATH
)


# ============================================================
# Model
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )


model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model.eval()


# ============================================================
# Prompt
# ============================================================

def build_prompt(row):

    mlir = Path(
        row["mlir_path"]
    ).read_text()

    user = f"""
You are analyzing an MLIR program for RISC-V.

The program can be compiled in two configurations:

1. scalar RISC-V
2. RISC-V Vector Extension (RVV)

Your task is to predict the expected static instruction-count
reduction obtained by enabling RVV instead of scalar RISC-V.

Use exactly one of these benefit classes:

LOW:
less than 5% instruction-count reduction

MEDIUM:
at least 5% but less than 15%

HIGH:
15% or greater instruction-count reduction

Base your prediction only on the MLIR structure.
You do not have access to compiler outputs or execution results.

Return exactly one word:

LOW
MEDIUM
or
HIGH

MLIR:

```mlir
{mlir}
```

Benefit:
""".strip()

    messages = [
        {
            "role": "user",
            "content": user,
        }
    ]

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


# ============================================================
# Run
# ============================================================

predictions = []
raw_outputs = []
prompt_lengths = []


for _, row in tqdm(
    df.iterrows(),
    total=len(df),
    desc="DT1 zero-shot",
):

    prompt = build_prompt(row)

    tokenized = tokenizer(
        prompt,
        add_special_tokens=False,
    )

    prompt_len = len(
        tokenized["input_ids"]
    )

    prompt_lengths.append(
        prompt_len
    )

    if prompt_len > MAX_SEQ_LEN:
        raise RuntimeError(
            f"Prompt exceeds context: "
            f"{prompt_len} > {MAX_SEQ_LEN}"
        )


    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=False,
    ).to("cuda")


    with torch.inference_mode():

        output = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=(
                tokenizer.pad_token_id
            ),
            eos_token_id=(
                tokenizer.eos_token_id
            ),
        )


    generated = tokenizer.decode(
        output[0][
            inputs["input_ids"].shape[1]:
        ],
        skip_special_tokens=True,
    ).strip()


    raw_outputs.append(
        generated
    )

    predictions.append(
        extract_label(generated)
    )


# ============================================================
# Save predictions
# ============================================================

df["prediction"] = predictions
df["raw_output"] = raw_outputs
df["correct"] = (
    df["prediction"]
    == df["rvv_benefit"]
)

df.to_csv(
    OUTPUT_PATH,
    index=False,
)


metrics = compute_metrics(
    df["rvv_benefit"],
    df["prediction"],
    df["reduction_pct"],
)

metrics["prompt_length_min"] = min(
    prompt_lengths
)

metrics["prompt_length_mean"] = (
    sum(prompt_lengths)
    / len(prompt_lengths)
)

metrics["prompt_length_max"] = max(
    prompt_lengths
)


save_metrics(
    metrics,
    METRICS_PATH,
)


print("\nMetrics:")
print(
    json.dumps(
        metrics,
        indent=2,
    )
)

print(
    "\nSaved:",
    OUTPUT_PATH,
)
