import shutil
import subprocess


TOOLS = [
    "iree-compile",
    "mlir-opt",
    "mlir-translate",
    "llc",
]


def run(cmd):
    print("\n$", " ".join(cmd))
    result = subprocess.run(
        cmd,
        text=True,
        capture_output=True,
    )

    if result.stdout:
        print(result.stdout[:8000])

    if result.stderr:
        print(result.stderr[:4000])

    return result.returncode


print("=" * 70)
print("TOOLCHAIN")
print("=" * 70)

for tool in TOOLS:
    print(f"{tool:20s}", shutil.which(tool))


iree = shutil.which("iree-compile")

if not iree:
    raise SystemExit(
        "\nERROR: iree-compile is not available."
    )


run(["iree-compile", "--version"])

print("\nChecking registered CPU targets...")
run([
    "iree-compile",
    "--iree-llvmcpu-list-targets",
])

print("\nChecking RISC-V/RVV flags...")
run([
    "iree-compile",
    "--help",
])