import hashlib
import json
import random
import re
from pathlib import Path

import pandas as pd


# ============================================================
# Configuration
# ============================================================

SEED = 42

# We do not need hundreds of programs just to obtain
# representative few-shot examples.
MAX_PROGRAMS = 500


DATA_PATH = Path(
    "/home/pranava7/mlirbench/dt-2/data/train.json"
)

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

PROGRAM_DIR = ROOT / "train_programs"
OUTPUT_DIR = ROOT / "outputs"

PROGRAM_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


# ============================================================
# Helpers
# ============================================================

def normalize_mlir(text):
    return "\n".join(
        line.rstrip()
        for line in str(text).strip().splitlines()
    )


def hash_mlir(text):
    return hashlib.sha256(
        normalize_mlir(text).encode("utf-8")
    ).hexdigest()


def safe_name(text):
    return re.sub(
        r"[^A-Za-z0-9_.-]+",
        "_",
        str(text),
    )


# ============================================================
# Load
# ============================================================

with DATA_PATH.open(
    "r",
    encoding="utf-8",
) as f:
    df = pd.DataFrame(
        json.load(f)
    )


print("=" * 72)
print("DT1 TRAIN PROGRAM SET")
print("=" * 72)

print("Original train examples:", len(df))


# ============================================================
# Same scope as test
# ============================================================

df["level"] = pd.to_numeric(
    df["level"],
    errors="coerce",
)

df = df[
    (df["dialect"] == "linalg")
    & (df["level"].between(1, 4))
    & (df["label"].isin(["EQUIV", "DIVERGE"]))
].copy()


df["mlir_hash"] = (
    df["mutated_mlir"]
    .apply(hash_mlir)
)

df = (
    df
    .drop_duplicates("mlir_hash")
    .reset_index(drop=True)
)


print("Eligible:", len(df))


# ============================================================
# Deterministic sample
# ============================================================

if len(df) > MAX_PROGRAMS:
    df = df.sample(
        n=MAX_PROGRAMS,
        random_state=SEED,
    ).reset_index(drop=True)


print("Selected:", len(df))


# ============================================================
# Write programs
# ============================================================

rows = []


for i, row in df.iterrows():

    pid = safe_name(
        row["program_id"]
    )

    dt1_id = (
        f"train_{i:03d}_{pid}"
    )

    path = (
        PROGRAM_DIR
        / f"{dt1_id}.mlir"
    )

    path.write_text(
        normalize_mlir(
            row["mutated_mlir"]
        )
        + "\n",
        encoding="utf-8",
    )

    rows.append(
        {
            "dt1_id": dt1_id,
            "program_id": row["program_id"],
            "dialect": row["dialect"],
            "level": int(row["level"]),
            "requirement_id": row["requirement_id"],
            "benchmark_label": row["label"],
            "mlir_hash": row["mlir_hash"],
            "mlir_path": str(path),
        }
    )


manifest = pd.DataFrame(rows)

path = (
    OUTPUT_DIR
    / "train_program_manifest.csv"
)

manifest.to_csv(
    path,
    index=False,
)


print("\nSaved:", path)
print("Programs:", len(manifest))