import re
import shutil
import subprocess
import time
from pathlib import Path

import pandas as pd


# ============================================================
# Paths
# ============================================================

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

MANIFEST_PATH = ROOT / "outputs" / "train_program_manifest.csv"

RESULTS_PATH = ROOT / "outputs" / "train_rvv_codegen_results.csv"

DUMP_ROOT = ROOT / "outputs" / "train_codegen"


# ============================================================
# Compiler
# ============================================================

IREE_COMPILE = shutil.which("iree-compile")

if IREE_COMPILE is None:
    raise RuntimeError("iree-compile not found")


# ============================================================
# Target configurations
# ============================================================

SCALAR_FEATURES = (
    "+m,+a,+f,+d,+c"
)

RVV_FEATURES = (
    "+m,+a,+f,+d,+c,+zvl512b,+v"
)


COMMON_ARGS = [
    "--iree-hal-target-device=local",
    "--iree-hal-local-target-device-backends=llvm-cpu",

    "--iree-llvmcpu-target-triple=riscv64",
    "--iree-llvmcpu-target-abi=lp64d",

    "--iree-opt-level=O3",
]


# ============================================================
# Assembly analysis
# ============================================================

# Typical RVV instruction families:
#
# vsetvli
# vsetivli
# vle32.v
# vse32.v
# vfadd.vv
# vfmul.vv
# vredsum.vs
# etc.
#
# This intentionally detects instructions beginning with "v".
# Labels/directives are filtered separately.

RVV_OPCODE = re.compile(
    r"^v[a-zA-Z0-9_.]+$"
)


def find_file(directory: Path, suffix: str):
    files = list(directory.glob(f"*{suffix}"))

    if not files:
        return None

    return files[0]


def parse_assembly(path: Path | None):

    if path is None or not path.exists():
        return {
            "total_instructions": 0,
            "rvv_instructions": 0,
            "rvv_opcodes": "",
            "assembly_bytes": 0,
        }

    text = path.read_text(
        encoding="utf-8",
        errors="ignore",
    )

    total = 0
    rvv = 0
    rvv_ops = []

    for raw_line in text.splitlines():

        line = raw_line.strip()

        # Skip blank lines.
        if not line:
            continue

        # Skip assembler directives.
        if line.startswith("."):
            continue

        # Skip comments.
        if line.startswith("#"):
            continue

        # Skip labels.
        if line.endswith(":"):
            continue

        # Remove trailing comments.
        line = line.split("#", 1)[0].strip()

        if not line:
            continue

        parts = line.split()

        if not parts:
            continue

        opcode = parts[0]

        # Skip a few constructs that are not instructions.
        if opcode.startswith("."):
            continue

        total += 1

        if RVV_OPCODE.fullmatch(opcode):

            # RISC-V vector opcodes start with v.
            #
            # Avoid counting ordinary symbols accidentally.
            if opcode.startswith("v"):
                rvv += 1
                rvv_ops.append(opcode)

    unique_ops = sorted(set(rvv_ops))

    return {
        "total_instructions": total,

        "rvv_instructions": rvv,

        "rvv_opcodes": ";".join(unique_ops),

        "assembly_bytes": path.stat().st_size,
    }


# ============================================================
# Compile helper
# ============================================================

def compile_program(
    mlir_path: Path,
    output_dir: Path,
    cpu_features: str,
    data_tiling: bool,
):

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    vmfb_path = output_dir / "program.vmfb"

    cmd = [
        IREE_COMPILE,
        str(mlir_path),

        "-o",
        str(vmfb_path),

        *COMMON_ARGS,

        (
            "--iree-llvmcpu-target-cpu-features="
            + cpu_features
        ),

        (
            "--iree-hal-dump-executable-files-to="
            + str(output_dir)
        ),
    ]

    if data_tiling:
        cmd.append(
            "--iree-opt-data-tiling"
        )

    start = time.time()

    process = subprocess.run(
        cmd,
        text=True,
        capture_output=True,
    )

    elapsed = time.time() - start

    asm_path = find_file(
        output_dir,
        ".s",
    )

    asm_stats = parse_assembly(
        asm_path
    )

    return {
        "success":
            process.returncode == 0,

        "returncode":
            process.returncode,

        "compile_seconds":
            elapsed,

        "vmfb_exists":
            vmfb_path.exists(),

        "vmfb_bytes":
            (
                vmfb_path.stat().st_size
                if vmfb_path.exists()
                else 0
            ),

        "assembly_path":
            str(asm_path)
            if asm_path
            else "",

        "stderr":
            process.stderr[-2000:],

        **asm_stats,
    }


# ============================================================
# Load programs
# ============================================================

manifest = pd.read_csv(
    MANIFEST_PATH
)

print("=" * 72)
print("DT1: RISC-V RVV CODEGEN EXPERIMENT")
print("=" * 72)

print(
    "\nPrograms:",
    len(manifest),
)


DUMP_ROOT.mkdir(
    parents=True,
    exist_ok=True,
)


# ============================================================
# Run experiment
# ============================================================

results = []


for index, row in manifest.iterrows():

    dt1_id = row["dt1_id"]

    mlir_path = Path(
        row["mlir_path"]
    )

    print(
        f"\n[{index + 1:02d}/{len(manifest):02d}] "
        f"{dt1_id}"
    )


    program_dir = (
        DUMP_ROOT
        / dt1_id
    )


    # --------------------------------------------------------
    # 1. Scalar RISC-V
    # --------------------------------------------------------

    scalar = compile_program(
        mlir_path=mlir_path,

        output_dir=(
            program_dir
            / "scalar"
        ),

        cpu_features=SCALAR_FEATURES,

        data_tiling=False,
    )

    print(
        "  scalar       ",
        "OK" if scalar["success"] else "FAIL",
        f"inst={scalar['total_instructions']}",
    )


    # --------------------------------------------------------
    # 2. RVV baseline
    # --------------------------------------------------------

    rvv = compile_program(
        mlir_path=mlir_path,

        output_dir=(
            program_dir
            / "rvv"
        ),

        cpu_features=RVV_FEATURES,

        data_tiling=False,
    )

    print(
        "  rvv          ",
        "OK" if rvv["success"] else "FAIL",
        f"rvv_inst={rvv['rvv_instructions']}",
    )


    # --------------------------------------------------------
    # 3. RVV + data tiling
    # --------------------------------------------------------

    tiled = compile_program(
        mlir_path=mlir_path,

        output_dir=(
            program_dir
            / "rvv_tiled"
        ),

        cpu_features=RVV_FEATURES,

        data_tiling=True,
    )

    print(
        "  rvv+tiled    ",
        "OK" if tiled["success"] else "FAIL",
        f"rvv_inst={tiled['rvv_instructions']}",
    )


    # ========================================================
    # Differences
    # ========================================================

    rvv_delta = (
        tiled["rvv_instructions"]
        - rvv["rvv_instructions"]
    )

    instruction_delta = (
        tiled["total_instructions"]
        - rvv["total_instructions"]
    )

    asm_size_delta = (
        tiled["assembly_bytes"]
        - rvv["assembly_bytes"]
    )


    # ========================================================
    # Compiler-derived optimization label
    # ========================================================
    #
    # APPLY:
    # Data tiling successfully compiles AND increases
    # realized RVV instructions relative to baseline.
    #
    # SKIP:
    # Data tiling fails or does not increase RVV realization.
    #
    # IMPORTANT:
    # This label means "increases RVV code generation".
    # It does NOT claim runtime speedup.
    # ========================================================

    if (
        tiled["success"]
        and rvv["success"]
        and rvv_delta > 0
    ):
        compiler_decision = "APPLY"

    else:
        compiler_decision = "SKIP"


    result = {
        "dt1_id":
            row["dt1_id"],

        "program_id":
            row["program_id"],

        "level":
            row["level"],

        "requirement_id":
            row["requirement_id"],

        "benchmark_label":
            row["benchmark_label"],

        "mlir_path":
            row["mlir_path"],


        # Scalar
        "scalar_success":
            scalar["success"],

        "scalar_instruction_count":
            scalar["total_instructions"],

        "scalar_compile_seconds":
            scalar["compile_seconds"],


        # RVV baseline
        "rvv_success":
            rvv["success"],

        "rvv_instruction_count":
            rvv["total_instructions"],

        "rvv_vector_instruction_count":
            rvv["rvv_instructions"],

        "rvv_opcodes":
            rvv["rvv_opcodes"],

        "rvv_assembly_bytes":
            rvv["assembly_bytes"],

        "rvv_vmfb_bytes":
            rvv["vmfb_bytes"],

        "rvv_compile_seconds":
            rvv["compile_seconds"],


        # RVV + data tiling
        "tiled_success":
            tiled["success"],

        "tiled_instruction_count":
            tiled["total_instructions"],

        "tiled_vector_instruction_count":
            tiled["rvv_instructions"],

        "tiled_opcodes":
            tiled["rvv_opcodes"],

        "tiled_assembly_bytes":
            tiled["assembly_bytes"],

        "tiled_vmfb_bytes":
            tiled["vmfb_bytes"],

        "tiled_compile_seconds":
            tiled["compile_seconds"],


        # Differences
        "rvv_vector_delta":
            rvv_delta,

        "instruction_delta":
            instruction_delta,

        "assembly_size_delta":
            asm_size_delta,


        # Ground truth for LLM experiment
        "compiler_decision":
            compiler_decision,
    }


    results.append(
        result
    )


    # Save after every program.
    pd.DataFrame(
        results
    ).to_csv(
        RESULTS_PATH,
        index=False,
    )


# ============================================================
# Summary
# ============================================================

results_df = pd.DataFrame(
    results
)


print("\n")
print("=" * 72)
print("COMPLETE")
print("=" * 72)


print(
    "\nCompiler decisions:"
)

print(
    results_df[
        "compiler_decision"
    ].value_counts()
)


print(
    "\nCompilation success:"
)

print(
    results_df[
        [
            "scalar_success",
            "rvv_success",
            "tiled_success",
        ]
    ].mean()
)


print(
    "\nRVV instruction counts:"
)

print(
    results_df[
        [
            "rvv_vector_instruction_count",
            "tiled_vector_instruction_count",
            "rvv_vector_delta",
        ]
    ].describe()
)


print(
    "\nPrograms with increased RVV realization:"
)

improved = results_df[
    results_df["rvv_vector_delta"] > 0
]

print(
    improved[
        [
            "dt1_id",
            "level",
            "requirement_id",
            "rvv_vector_instruction_count",
            "tiled_vector_instruction_count",
            "rvv_vector_delta",
        ]
    ].to_string(
        index=False
    )
)


print(
    "\nSaved:",
    RESULTS_PATH,
)