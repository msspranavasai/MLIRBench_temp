import hashlib
import json
import re
from pathlib import Path

import pandas as pd


# ============================================================
# Paths
# ============================================================

DATA_PATH = Path(
    "/home/pranava7/mlirbench/dt-2/data/test.json"
)

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

PROGRAM_DIR = ROOT / "programs"
OUTPUT_DIR = ROOT / "outputs"

PROGRAM_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


# ============================================================
# Helpers
# ============================================================

def normalize_mlir(text: str) -> str:
    """
    Normalize whitespace at line endings while preserving
    the structure of the MLIR program.
    """
    return "\n".join(
        line.rstrip()
        for line in str(text).strip().splitlines()
    )


def hash_mlir(text: str) -> str:
    """
    Stable hash used for removing duplicate MLIR programs.
    """
    normalized = normalize_mlir(text)

    return hashlib.sha256(
        normalized.encode("utf-8")
    ).hexdigest()


def safe_filename(text: str) -> str:
    """
    Convert program_id into a filesystem-safe string.
    """
    return re.sub(
        r"[^A-Za-z0-9_.-]+",
        "_",
        str(text),
    )


# ============================================================
# Load dataset
# ============================================================

if not DATA_PATH.exists():
    raise FileNotFoundError(
        f"Dataset not found: {DATA_PATH}"
    )

with DATA_PATH.open(
    "r",
    encoding="utf-8",
) as f:
    records = json.load(f)

df = pd.DataFrame(records)


print("=" * 70)
print("DT1: RISC-V RVV PROGRAM SET")
print("=" * 70)

print("\nOriginal test examples:", len(df))

print("\nOriginal dialect distribution:")
print(df["dialect"].value_counts())

print("\nOriginal label distribution:")
print(df["label"].value_counts())


# ============================================================
# Validate required columns
# ============================================================

required_columns = {
    "program_id",
    "dialect",
    "level",
    "requirement_id",
    "mutated_mlir",
    "label",
}

missing = required_columns - set(df.columns)

if missing:
    raise RuntimeError(
        f"Missing required columns: {sorted(missing)}"
    )


# ============================================================
# Select DT1 programs
#
# Scope:
#   - linalg dialect
#   - Levels 1-4
#   - exclude ERROR cases
#
# ERROR examples may fail later compilation/execution and make
# it harder to isolate the effect of the RVV optimization itself.
# ============================================================

df["level"] = pd.to_numeric(
    df["level"],
    errors="coerce",
)

df = df[
    (df["dialect"] == "linalg")
    & (df["level"].between(1, 4))
    & (df["label"].isin(["EQUIV", "DIVERGE"]))
].copy()


print("\nAfter DT1 filtering:", len(df))


# ============================================================
# Deduplicate exact MLIR programs
# ============================================================

df["mlir_hash"] = (
    df["mutated_mlir"]
    .apply(hash_mlir)
)

before_dedup = len(df)

df = (
    df
    .drop_duplicates(
        subset=["mlir_hash"]
    )
    .reset_index(drop=True)
)

duplicates_removed = (
    before_dedup - len(df)
)


print(
    "Duplicate MLIR programs removed:",
    duplicates_removed,
)

print(
    "Final DT1 programs:",
    len(df),
)


# ============================================================
# Print resulting distribution
# ============================================================

print("\nLevel distribution:")
print(
    df["level"]
    .value_counts()
    .sort_index()
)

print("\nMLIRBench semantic-label distribution:")
print(
    df["label"]
    .value_counts()
)

print("\nRequirement distribution:")
print(
    df["requirement_id"]
    .value_counts()
)


# ============================================================
# Write programs and manifest
# ============================================================

manifest_rows = []


for idx, row in df.iterrows():

    program_id = safe_filename(
        row["program_id"]
    )

    dt1_id = (
        f"dt1_{idx:03d}_{program_id}"
    )

    mlir_path = (
        PROGRAM_DIR
        / f"{dt1_id}.mlir"
    )

    mlir_text = normalize_mlir(
        row["mutated_mlir"]
    )

    mlir_path.write_text(
        mlir_text + "\n",
        encoding="utf-8",
    )


    manifest_rows.append(
        {
            "dt1_id": dt1_id,

            "program_id":
                row["program_id"],

            "dialect":
                row["dialect"],

            "level":
                int(row["level"]),

            "requirement_id":
                row["requirement_id"],

            # This is the original MLIRBench semantic
            # relationship label. It is metadata only;
            # it is NOT our RVV optimization label.
            "benchmark_label":
                row["label"],

            "mlir_hash":
                row["mlir_hash"],

            "mlir_path":
                str(mlir_path),
        }
    )


manifest = pd.DataFrame(
    manifest_rows
)


manifest_path = (
    OUTPUT_DIR
    / "program_manifest.csv"
)

manifest.to_csv(
    manifest_path,
    index=False,
)


# ============================================================
# Summary
# ============================================================

print("\n" + "=" * 70)
print("PROGRAM SET CREATED")
print("=" * 70)

print(
    f"\nPrograms written to:\n{PROGRAM_DIR}"
)

print(
    f"\nManifest written to:\n{manifest_path}"
)

print(
    "\nManifest preview:"
)

print(
    manifest[
        [
            "dt1_id",
            "level",
            "requirement_id",
            "benchmark_label",
        ]
    ]
    .head(10)
    .to_string(index=False)
)

print(
    f"\nTotal programs: {len(manifest)}"
)