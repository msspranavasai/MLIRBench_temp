import json
import re

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    f1_score,
)
from scipy.stats import spearmanr


LABELS = [
    "LOW",
    "MEDIUM",
    "HIGH",
]

ALL_PREDICTION_LABELS = [
    "LOW",
    "MEDIUM",
    "HIGH",
    "INVALID",
]

ORDINAL = {
    "LOW": 0,
    "MEDIUM": 1,
    "HIGH": 2,
}


def extract_label(text):
    """
    Extract the final explicit LOW/MEDIUM/HIGH label from model output.

    Any output that does not contain one of the expected labels is
    recorded as INVALID.
    """
    text = str(text).upper()

    matches = re.findall(
        r"\b(LOW|MEDIUM|HIGH)\b",
        text,
    )

    if not matches:
        return "INVALID"

    return matches[-1]


def compute_metrics(
    y_true,
    y_pred,
    reduction_pct,
):
    """
    Compute DT1 classification and ordinal metrics.

    INVALID predictions count as incorrect in headline accuracy,
    macro-F1, weighted-F1, and ordinal metrics. They are not silently
    dropped.

    Spearman correlation is computed only over valid ordinal
    predictions because INVALID has no meaningful ordinal value.
    """

    y_true = [
        str(x).upper()
        for x in y_true
    ]

    y_pred = [
        (
            str(x).upper()
            if str(x).upper() in ALL_PREDICTION_LABELS
            else "INVALID"
        )
        for x in y_pred
    ]

    reduction_pct = [
        float(x)
        for x in reduction_pct
    ]

    if not (
        len(y_true)
        == len(y_pred)
        == len(reduction_pct)
    ):
        raise ValueError(
            "y_true, y_pred, and reduction_pct must have equal length."
        )

    if len(y_true) == 0:
        raise ValueError(
            "Cannot compute metrics on an empty dataset."
        )

    invalid_count = sum(
        pred == "INVALID"
        for pred in y_pred
    )

    metrics = {
        "n": len(y_true),
        "valid_predictions":
            len(y_true) - invalid_count,
        "invalid_predictions":
            invalid_count,
        "invalid_rate":
            invalid_count / len(y_true),

        # INVALID stays in y_pred, so it counts as wrong.
        "accuracy":
            accuracy_score(
                y_true,
                y_pred,
            ),

        "macro_f1":
            f1_score(
                y_true,
                y_pred,
                labels=LABELS,
                average="macro",
                zero_division=0,
            ),

        "weighted_f1":
            f1_score(
                y_true,
                y_pred,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            ),
    }

    per_class_f1 = f1_score(
        y_true,
        y_pred,
        labels=LABELS,
        average=None,
        zero_division=0,
    )

    metrics["per_class_f1"] = {
        label: float(score)
        for label, score in zip(
            LABELS,
            per_class_f1,
        )
    }

    # Ordinal metrics.
    # LOW=0, MEDIUM=1, HIGH=2.
    # INVALID receives maximum ordinal error 2.
    ordinal_errors = []

    for true, pred in zip(
        y_true,
        y_pred,
    ):
        if true not in ORDINAL:
            raise ValueError(
                f"Unexpected ground-truth label: {true}"
            )

        if pred == "INVALID":
            error = 2
        else:
            error = abs(
                ORDINAL[true]
                - ORDINAL[pred]
            )

        ordinal_errors.append(
            error
        )

    ordinal_errors = np.asarray(
        ordinal_errors,
        dtype=float,
    )

    metrics["ordinal_mae"] = float(
        ordinal_errors.mean()
    )

    metrics["severe_error_rate"] = float(
        (ordinal_errors == 2).mean()
    )

    metrics["within_one_class"] = float(
        (ordinal_errors <= 1).mean()
    )

    # Spearman correlation can only use valid ordinal predictions.
    valid_indices = [
        i
        for i, pred in enumerate(y_pred)
        if pred in ORDINAL
    ]

    metrics["spearman_valid_n"] = len(
        valid_indices
    )

    if len(valid_indices) >= 2:
        pred_ord = np.asarray(
            [
                ORDINAL[y_pred[i]]
                for i in valid_indices
            ],
            dtype=float,
        )

        valid_reduction = np.asarray(
            [
                reduction_pct[i]
                for i in valid_indices
            ],
            dtype=float,
        )

        # Constant predictions make Spearman undefined.
        if len(np.unique(pred_ord)) < 2:
            rho = np.nan
            p_value = np.nan
        else:
            rho, p_value = spearmanr(
                pred_ord,
                valid_reduction,
            )

        metrics["spearman_rho"] = (
            None
            if np.isnan(rho)
            else float(rho)
        )

        metrics["spearman_p"] = (
            None
            if np.isnan(p_value)
            else float(p_value)
        )
    else:
        metrics["spearman_rho"] = None
        metrics["spearman_p"] = None

    # Confusion matrix with INVALID shown explicitly as a prediction.
    confusion = {
        true_label: {
            pred_label: 0
            for pred_label
            in ALL_PREDICTION_LABELS
        }
        for true_label
        in LABELS
    }

    for true, pred in zip(
        y_true,
        y_pred,
    ):
        if true not in confusion:
            raise ValueError(
                f"Unexpected ground-truth label: {true}"
            )

        confusion[true][pred] += 1

    metrics["confusion_matrix"] = confusion

    return metrics


def save_metrics(
    metrics,
    path,
):
    with open(
        path,
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            metrics,
            f,
            indent=2,
        )