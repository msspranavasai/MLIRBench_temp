import re
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

TRAIN_RESULTS = (
    ROOT
    / "outputs"
    / "train_rvv_codegen_results.csv"
)

TEST_GROUND_TRUTH = (
    ROOT
    / "outputs"
    / "rvv_benefit_ground_truth.csv"
)

OUTPUT = (
    ROOT
    / "outputs"
    / "train_rvv_benefit_ground_truth.csv"
)

DEMOS_OUTPUT = (
    ROOT
    / "outputs"
    / "dt1_three_shot_examples.csv"
)


# ============================================================
# Helpers
# ============================================================

def benefit_class(x):
    if x < 5:
        return "LOW"
    elif x < 15:
        return "MEDIUM"
    else:
        return "HIGH"


def base_family(program_id):
    """
    Example:

    seed2_linalg_prog14_L3_R3
        ->
    seed2_linalg_prog14

    We use this to prevent few-shot examples from coming
    from the same underlying seed program as test programs.
    """

    match = re.match(
        r"^(seed\d+_linalg_prog\d+)",
        str(program_id),
    )

    if match:
        return match.group(1)

    return str(program_id)


# ============================================================
# Load training compiler results
# ============================================================

train = pd.read_csv(
    TRAIN_RESULTS
)


print("=" * 72)
print("DT1 TRAINING BENEFIT LABELS")
print("=" * 72)

print(
    "\nRaw compiled training examples:",
    len(train),
)


# Only use programs for which both compilation modes succeeded.
train = train[
    train["scalar_success"]
    & train["rvv_success"]
].copy()


print(
    "Valid scalar/RVV examples:",
    len(train),
)


# ============================================================
# Compute compiler-measured RVV benefit
# ============================================================

train["instruction_reduction"] = (
    train["scalar_instruction_count"]
    - train["rvv_instruction_count"]
)

train["reduction_pct"] = (
    train["instruction_reduction"]
    / train["scalar_instruction_count"]
    * 100
)

train["rvv_benefit"] = (
    train["reduction_pct"]
    .apply(benefit_class)
)


# ============================================================
# Identify underlying program families
# ============================================================

train["base_family"] = (
    train["program_id"]
    .apply(base_family)
)


# ============================================================
# Load test families
# ============================================================

test = pd.read_csv(
    TEST_GROUND_TRUTH
)

test["base_family"] = (
    test["program_id"]
    .apply(base_family)
)

test_families = set(
    test["base_family"]
)


train["family_disjoint_from_test"] = (
    ~train["base_family"]
    .isin(test_families)
)


# ============================================================
# Print overall distribution
# ============================================================

print("\nOVERALL BENEFIT DISTRIBUTION")

print(
    train["rvv_benefit"]
    .value_counts()
    .reindex(
        ["LOW", "MEDIUM", "HIGH"],
        fill_value=0,
    )
)


print("\nREDUCTION STATISTICS")

print(
    train["reduction_pct"]
    .describe()
)


# ============================================================
# Leakage-safe demonstration pool
# ============================================================

demo_pool = train[
    train["family_disjoint_from_test"]
].copy()


print(
    "\nFamily-disjoint training examples:",
    len(demo_pool),
)


print(
    "\nFAMILY-DISJOINT CLASS DISTRIBUTION"
)

print(
    demo_pool["rvv_benefit"]
    .value_counts()
    .reindex(
        ["LOW", "MEDIUM", "HIGH"],
        fill_value=0,
    )
)


# ============================================================
# Select one representative example per class
#
# We want:
#   1. one LOW
#   2. one MEDIUM
#   3. one HIGH
#
# Pick a representative example near the median of the class.
# Among similarly representative candidates, prefer a smaller
# MLIR program so that three-shot prompts remain manageable.
# ============================================================

selected = []
used_families = set()


for label in [
    "LOW",
    "MEDIUM",
    "HIGH",
]:

    subset = demo_pool[
        demo_pool["rvv_benefit"] == label
    ].copy()

    if subset.empty:
        raise RuntimeError(
            f"No family-disjoint {label} examples found."
        )

    class_median = (
        subset["reduction_pct"]
        .median()
    )

    subset["distance_to_median"] = (
        (
            subset["reduction_pct"]
            - class_median
        )
        .abs()
    )

    # MLIR size is useful for avoiding a huge few-shot prompt.
    subset["mlir_chars"] = (
        subset["mlir_path"]
        .apply(
            lambda p: Path(p).stat().st_size
        )
    )

    subset = subset[
        ~subset["base_family"]
        .isin(used_families)
    ]

    # Look at representative candidates first,
    # then prefer smaller MLIR.
    subset = subset.sort_values(
        [
            "distance_to_median",
            "mlir_chars",
        ]
    )

    example = subset.iloc[0]

    selected.append(
        example
    )

    used_families.add(
        example["base_family"]
    )


demos = pd.DataFrame(
    selected
)


# ============================================================
# Save outputs
# ============================================================

train.to_csv(
    OUTPUT,
    index=False,
)

demos.to_csv(
    DEMOS_OUTPUT,
    index=False,
)


# ============================================================
# Summary
# ============================================================

print("\n" + "=" * 72)
print("SELECTED THREE-SHOT EXAMPLES")
print("=" * 72)

print(
    demos[
        [
            "dt1_id",
            "base_family",
            "requirement_id",
            "reduction_pct",
            "rvv_benefit",
            "mlir_chars",
        ]
    ].to_string(
        index=False
    )
)


print("\nSaved full training labels:")
print(OUTPUT)

print("\nSaved three-shot examples:")
print(DEMOS_OUTPUT)