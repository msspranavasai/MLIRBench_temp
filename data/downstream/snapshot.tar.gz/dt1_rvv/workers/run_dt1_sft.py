import json
import os
from pathlib import Path

import pandas as pd
import torch
from peft import LoraConfig, PeftModel, get_peft_model
from torch.utils.data import Dataset
from tqdm.auto import tqdm
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)

from dt1_common import (
    compute_metrics,
    extract_label,
    save_metrics,
)


MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

TRAIN_PATH = (
    ROOT
    / "outputs"
    / "train_rvv_benefit_ground_truth.csv"
)

TEST_PATH = (
    ROOT
    / "outputs"
    / "rvv_benefit_ground_truth.csv"
)

ADAPTER_DIR = (
    ROOT
    / "outputs"
    / "dt1_sft_adapter"
)

OUTPUT_PATH = (
    ROOT
    / "outputs"
    / "dt1_sft_predictions.csv"
)

METRICS_PATH = (
    ROOT
    / "outputs"
    / "dt1_sft_metrics.json"
)

MAX_SEQ_LEN = 16384
MAX_NEW_TOKENS = 8

NUM_EPOCHS = 6
LEARNING_RATE = 2e-4
PER_DEVICE_BATCH_SIZE = 1
GRAD_ACCUM_STEPS = 1

SEED = 42


# ============================================================
# Helpers
# ============================================================

def instruction_prompt(mlir: str) -> str:
    return f"""
You are analyzing an MLIR program for RISC-V.

The program can be compiled in two configurations:

1. scalar RISC-V
2. RISC-V Vector Extension (RVV)

Your task is to predict the expected static instruction-count
reduction obtained by enabling RVV instead of scalar RISC-V.

Use exactly one of these benefit classes:

LOW:
less than 5% instruction-count reduction

MEDIUM:
at least 5% but less than 15%

HIGH:
15% or greater instruction-count reduction

Base your prediction only on the MLIR structure.
You do not have access to compiler outputs or execution results.

Return exactly one word:

LOW
MEDIUM
or
HIGH

MLIR:

```mlir
{mlir}
```

Benefit:
""".strip()


# ============================================================
# Load data
# ============================================================

train_df = pd.read_csv(TRAIN_PATH)
test_df = pd.read_csv(TEST_PATH)

# Leakage-safe SFT:
# train only on underlying program families that do NOT occur
# in the DT1 held-out test set.
if "family_disjoint_from_test" in train_df.columns:
    train_df = train_df[
        train_df["family_disjoint_from_test"].astype(bool)
    ].copy()

train_df = train_df[
    train_df["rvv_benefit"].isin(
        ["LOW", "MEDIUM", "HIGH"]
    )
].reset_index(drop=True)

print("=" * 72)
print("DT1 SFT")
print("=" * 72)

print("\nTraining examples:", len(train_df))
print(train_df["rvv_benefit"].value_counts())

print("\nTest examples:", len(test_df))
print(test_df["rvv_benefit"].value_counts())


# ============================================================
# Tokenizer
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "right"


# ============================================================
# Dataset with prompt masking
#
# Only the assistant label contributes to the training loss.
# ============================================================

class DT1SFTDataset(Dataset):
    def __init__(self, dataframe):
        self.examples = []

        for _, row in dataframe.iterrows():
            mlir = Path(
                row["mlir_path"]
            ).read_text(
                encoding="utf-8"
            )

            prompt_messages = [
                {
                    "role": "user",
                    "content": instruction_prompt(mlir),
                }
            ]

            full_messages = prompt_messages + [
                {
                    "role": "assistant",
                    "content": str(row["rvv_benefit"]),
                }
            ]

            prompt_text = tokenizer.apply_chat_template(
                prompt_messages,
                tokenize=False,
                add_generation_prompt=True,
            )

            full_text = tokenizer.apply_chat_template(
                full_messages,
                tokenize=False,
                add_generation_prompt=False,
            )

            prompt_ids = tokenizer(
                prompt_text,
                add_special_tokens=False,
            )["input_ids"]

            encoded = tokenizer(
                full_text,
                add_special_tokens=False,
                truncation=True,
                max_length=MAX_SEQ_LEN,
            )

            input_ids = encoded["input_ids"]
            attention_mask = encoded["attention_mask"]

            if len(input_ids) >= MAX_SEQ_LEN:
                raise RuntimeError(
                    "Training example reaches/truncates at "
                    f"MAX_SEQ_LEN={MAX_SEQ_LEN}. "
                    "Increase MAX_SEQ_LEN before training."
                )

            labels = input_ids.copy()

            # Mask the user prompt and train only on the
            # assistant response tokens.
            prompt_len = min(
                len(prompt_ids),
                len(labels),
            )

            labels[:prompt_len] = [-100] * prompt_len

            self.examples.append(
                {
                    "input_ids": input_ids,
                    "attention_mask": attention_mask,
                    "labels": labels,
                }
            )

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.examples[idx]


class CausalLMDataCollator:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, features):
        max_len = max(
            len(x["input_ids"])
            for x in features
        )

        input_ids = []
        attention_mask = []
        labels = []

        for feature in features:
            length = len(
                feature["input_ids"]
            )

            pad_len = max_len - length

            input_ids.append(
                feature["input_ids"]
                + [self.tokenizer.pad_token_id] * pad_len
            )

            attention_mask.append(
                feature["attention_mask"]
                + [0] * pad_len
            )

            labels.append(
                feature["labels"]
                + [-100] * pad_len
            )

        return {
            "input_ids": torch.tensor(
                input_ids,
                dtype=torch.long,
            ),
            "attention_mask": torch.tensor(
                attention_mask,
                dtype=torch.long,
            ),
            "labels": torch.tensor(
                labels,
                dtype=torch.long,
            ),
        }


train_dataset = DT1SFTDataset(
    train_df
)

data_collator = CausalLMDataCollator(
    tokenizer
)


# ============================================================
# Load model + LoRA
# ============================================================

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    trust_remote_code=True,
)

model.config.use_cache = False
model.gradient_checkpointing_enable()

lora_config = LoraConfig(
    r=64,
    lora_alpha=128,
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=[
        "q_proj",
        "k_proj",
        "v_proj",
        "o_proj",
        "gate_proj",
        "up_proj",
        "down_proj",
    ],
)

model = get_peft_model(
    model,
    lora_config,
)

model.print_trainable_parameters()


# ============================================================
# Train
#
# Supports:
#   python run_dt1_sft.py
#
# or multi-GPU DDP:
#   torchrun --standalone --nproc_per_node=4 run_dt1_sft.py
# ============================================================

training_args = TrainingArguments(
    output_dir=str(
        ROOT / "outputs" / "dt1_sft_checkpoints"
    ),

    num_train_epochs=NUM_EPOCHS,

    per_device_train_batch_size=(
        PER_DEVICE_BATCH_SIZE
    ),

    gradient_accumulation_steps=(
        GRAD_ACCUM_STEPS
    ),

    learning_rate=LEARNING_RATE,

    lr_scheduler_type="cosine",
    warmup_steps=10,

    bf16=True,
    fp16=False,

    gradient_checkpointing=True,

    logging_steps=5,

    save_strategy="epoch",
    save_total_limit=2,

    report_to="none",

    remove_unused_columns=False,

    ddp_find_unused_parameters=False,

    seed=SEED,
    data_seed=SEED,
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    data_collator=data_collator,
)

trainer.train()


# ============================================================
# Save adapter
# ============================================================

trainer.save_model(
    str(ADAPTER_DIR)
)

tokenizer.save_pretrained(
    str(ADAPTER_DIR)
)


# ============================================================
# Only rank 0 performs evaluation/output.
# ============================================================

local_rank = int(
    os.environ.get(
        "LOCAL_RANK",
        "0",
    )
)

if (
    torch.distributed.is_available()
    and torch.distributed.is_initialized()
):
    torch.distributed.barrier()

if local_rank != 0:
    raise SystemExit(0)


# Free Trainer references before reloading for inference.
del trainer
del model

torch.cuda.empty_cache()


# ============================================================
# Reload base + adapter for inference
# ============================================================

tokenizer.padding_side = "left"

base_model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model = PeftModel.from_pretrained(
    base_model,
    str(ADAPTER_DIR),
)

model.eval()


# ============================================================
# Test prompt
# ============================================================

def build_eval_prompt(row):
    mlir = Path(
        row["mlir_path"]
    ).read_text(
        encoding="utf-8"
    )

    messages = [
        {
            "role": "user",
            "content": instruction_prompt(mlir),
        }
    ]

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


# ============================================================
# Evaluate
# ============================================================

predictions = []
raw_outputs = []
prompt_lengths = []

for _, row in tqdm(
    test_df.iterrows(),
    total=len(test_df),
    desc="DT1 SFT evaluation",
):
    prompt = build_eval_prompt(row)

    prompt_len = len(
        tokenizer(
            prompt,
            add_special_tokens=False,
        )["input_ids"]
    )

    prompt_lengths.append(
        prompt_len
    )

    if prompt_len > MAX_SEQ_LEN:
        raise RuntimeError(
            f"Test prompt exceeds context: "
            f"{prompt_len} > {MAX_SEQ_LEN}"
        )

    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=False,
    ).to("cuda")

    with torch.inference_mode():
        output = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    generated = tokenizer.decode(
        output[0][
            inputs["input_ids"].shape[1]:
        ],
        skip_special_tokens=True,
    ).strip()

    raw_outputs.append(
        generated
    )

    predictions.append(
        extract_label(generated)
    )


test_df["prediction"] = predictions
test_df["raw_output"] = raw_outputs
test_df["correct"] = (
    test_df["prediction"]
    == test_df["rvv_benefit"]
)

test_df.to_csv(
    OUTPUT_PATH,
    index=False,
)

metrics = compute_metrics(
    test_df["rvv_benefit"],
    test_df["prediction"],
    test_df["reduction_pct"],
)

metrics["training_examples"] = int(
    len(train_df)
)

metrics["prompt_length_min"] = min(
    prompt_lengths
)

metrics["prompt_length_mean"] = (
    sum(prompt_lengths)
    / len(prompt_lengths)
)

metrics["prompt_length_max"] = max(
    prompt_lengths
)

save_metrics(
    metrics,
    METRICS_PATH,
)

print("\nMetrics:")
print(
    json.dumps(
        metrics,
        indent=2,
    )
)

print("\nSaved adapter:", ADAPTER_DIR)
print("Saved predictions:", OUTPUT_PATH)
print("Saved metrics:", METRICS_PATH)