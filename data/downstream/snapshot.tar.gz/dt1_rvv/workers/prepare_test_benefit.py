from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/dt1_rvv"
)

CODEGEN_RESULTS = (
    ROOT
    / "outputs"
    / "rvv_codegen_results.csv"
)

OUTPUT = (
    ROOT
    / "outputs"
    / "rvv_benefit_ground_truth.csv"
)


# ============================================================
# Fixed benefit thresholds
#
# LOW:    < 5% static instruction-count reduction
# MEDIUM: 5% to < 15%
# HIGH:   >= 15%
#
# Benefit is measured from actual IREE-generated RISC-V
# assembly:
#
# reduction_pct =
#   (scalar_instruction_count - rvv_instruction_count)
#   / scalar_instruction_count * 100
#
# This is a static code-generation metric, not runtime speedup.
# ============================================================

def benefit_class(reduction_pct):
    if reduction_pct < 5:
        return "LOW"

    if reduction_pct < 15:
        return "MEDIUM"

    return "HIGH"


# ============================================================
# Load compiler results
# ============================================================

if not CODEGEN_RESULTS.exists():
    raise FileNotFoundError(
        f"Compiler results not found: {CODEGEN_RESULTS}"
    )

df = pd.read_csv(
    CODEGEN_RESULTS
)

print("=" * 72)
print("DT1 TEST BENEFIT GROUND TRUTH")
print("=" * 72)

print(
    "\nRaw test compiler records:",
    len(df),
)


# ============================================================
# Validate required columns
# ============================================================

required_columns = {
    "dt1_id",
    "program_id",
    "level",
    "requirement_id",
    "benchmark_label",
    "mlir_path",
    "scalar_success",
    "rvv_success",
    "scalar_instruction_count",
    "rvv_instruction_count",
    "rvv_vector_instruction_count",
}

missing = (
    required_columns
    - set(df.columns)
)

if missing:
    raise RuntimeError(
        "Missing required columns: "
        f"{sorted(missing)}"
    )


# ============================================================
# Keep only programs that successfully compile in BOTH
# scalar RISC-V and RVV configurations.
# ============================================================

valid = df[
    df["scalar_success"]
    & df["rvv_success"]
].copy()

excluded = (
    len(df)
    - len(valid)
)

print(
    "Valid scalar/RVV programs:",
    len(valid),
)

print(
    "Excluded compiler failures:",
    excluded,
)

if valid.empty:
    raise RuntimeError(
        "No valid scalar/RVV programs remain."
    )


# ============================================================
# Compute compiler-measured RVV benefit
# ============================================================

if (
    valid["scalar_instruction_count"]
    <= 0
).any():
    bad = valid[
        valid["scalar_instruction_count"]
        <= 0
    ]

    raise RuntimeError(
        "Found non-positive scalar instruction counts:\n"
        + bad[
            [
                "dt1_id",
                "scalar_instruction_count",
            ]
        ].to_string(index=False)
    )


valid["instruction_reduction"] = (
    valid["scalar_instruction_count"]
    - valid["rvv_instruction_count"]
)

valid["reduction_pct"] = (
    valid["instruction_reduction"]
    / valid["scalar_instruction_count"]
    * 100
)

valid["rvv_benefit"] = (
    valid["reduction_pct"]
    .apply(benefit_class)
)


# ============================================================
# Sanity checks
# ============================================================

print(
    "\nBENEFIT DISTRIBUTION"
)

print(
    valid["rvv_benefit"]
    .value_counts()
    .reindex(
        [
            "LOW",
            "MEDIUM",
            "HIGH",
        ],
        fill_value=0,
    )
)

print(
    "\nREDUCTION STATISTICS (%)"
)

print(
    valid["reduction_pct"]
    .describe()
)

print(
    "\nRVV VECTOR-INSTRUCTION STATISTICS"
)

print(
    valid[
        "rvv_vector_instruction_count"
    ].describe()
)


# ============================================================
# Stable ordering and save
# ============================================================

valid = valid.sort_values(
    "dt1_id"
).reset_index(drop=True)

valid.to_csv(
    OUTPUT,
    index=False,
)


# ============================================================
# Summary
# ============================================================

print(
    "\n" + "=" * 72
)

print(
    "TEST BENEFIT GROUND TRUTH CREATED"
)

print(
    "=" * 72
)

print(
    "\nPer-program labels:"
)

print(
    valid[
        [
            "dt1_id",
            "requirement_id",
            "scalar_instruction_count",
            "rvv_instruction_count",
            "instruction_reduction",
            "reduction_pct",
            "rvv_vector_instruction_count",
            "rvv_benefit",
        ]
    ]
    .sort_values(
        "reduction_pct",
        ascending=False,
    )
    .to_string(
        index=False
    )
)

print(
    "\nSaved:",
    OUTPUT,
)