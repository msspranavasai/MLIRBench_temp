import json
import math
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
)


# ============================================================================
# PATHS
# ============================================================================

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench"
)

LINALG_ROOT = ROOT / "DT1_ELEMENTWISE"
TORCH_ROOT = ROOT / "DT1_TORCH_OPT"
GENERIC_ROOT = ROOT / "DT1_GENERIC_OPT"

FIG_DIR = ROOT / "figures" / "dt1_all"
FIG_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


LABELS = [
    "LOW",
    "MEDIUM",
    "HIGH",
]

LABEL_TO_INT = {
    "LOW": 0,
    "MEDIUM": 1,
    "HIGH": 2,
}


# ============================================================================
# HELPERS
# ============================================================================

def clean_label(x):
    if pd.isna(x):
        return None

    x = str(x).strip().upper()

    aliases = {
        "A": "LOW",
        "B": "MEDIUM",
        "C": "HIGH",
    }

    x = aliases.get(
        x,
        x,
    )

    return x


def detect_columns(df):
    gold_candidates = [
        "fusion_benefit",
        "simplification_benefit",
        "gold",
        "gold_label",
        "target",
        "label",
    ]

    pred_candidates = [
        "prediction",
        "predicted_label",
        "pred_label",
        "predicted",
        "prediction_label",
    ]

    gold = next(
        (
            c
            for c in gold_candidates
            if c in df.columns
        ),
        None,
    )

    pred = next(
        (
            c
            for c in pred_candidates
            if c in df.columns
        ),
        None,
    )

    return gold, pred


def parse_fold(path):
    s = str(path)

    matches = re.findall(
        r"fold[_/-]?(\d+)",
        s,
        flags=re.I,
    )

    if not matches:
        return None

    return int(
        matches[-1]
    )


def candidate_score(path):
    name = path.name.lower()

    score = 0

    if name == "val_predictions.csv":
        score += 100

    if "val_prediction" in name:
        score += 80

    if "prediction" in name:
        score += 50

    if "checkpoint" in name:
        score -= 30

    return score


def discover_prediction_files(method_dir):
    """
    Discover one held-out prediction CSV per fold.
    """

    candidates = {}

    if not method_dir.exists():
        return {}

    for path in method_dir.rglob("*.csv"):

        fold = parse_fold(path)

        if fold is None:
            continue

        try:
            small = pd.read_csv(
                path,
                nrows=5,
            )
        except Exception:
            continue

        gold, pred = detect_columns(
            small
        )

        if gold is None or pred is None:
            continue

        score = candidate_score(
            path
        )

        old = candidates.get(
            fold
        )

        if (
            old is None
            or score > old[0]
        ):
            candidates[fold] = (
                score,
                path,
            )

    return {
        fold: item[1]
        for fold, item
        in candidates.items()
    }


def read_prediction_file(path):
    df = pd.read_csv(
        path
    )

    gold_col, pred_col = detect_columns(
        df
    )

    if gold_col is None:
        raise RuntimeError(
            f"No gold column found in {path}"
        )

    if pred_col is None:
        raise RuntimeError(
            f"No prediction column found in {path}"
        )

    out = df.copy()

    out["_gold"] = out[
        gold_col
    ].map(
        clean_label
    )

    out["_pred"] = out[
        pred_col
    ].map(
        clean_label
    )

    out = out[
        out["_gold"].isin(LABELS)
        &
        out["_pred"].isin(LABELS)
    ].copy()

    return out


def compute_metrics(
    gold,
    pred,
):
    gold = list(gold)
    pred = list(pred)

    gold_num = np.array(
        [
            LABEL_TO_INT[x]
            for x in gold
        ]
    )

    pred_num = np.array(
        [
            LABEL_TO_INT[x]
            for x in pred
        ]
    )

    class_f1 = f1_score(
        gold,
        pred,
        labels=LABELS,
        average=None,
        zero_division=0,
    )

    ordinal_error = np.abs(
        gold_num - pred_num
    )

    return {
        "n": len(gold),

        "accuracy":
            accuracy_score(
                gold,
                pred,
            ),

        "balanced_accuracy":
            balanced_accuracy_score(
                gold,
                pred,
            ),

        "macro_f1":
            f1_score(
                gold,
                pred,
                labels=LABELS,
                average="macro",
                zero_division=0,
            ),

        "weighted_f1":
            f1_score(
                gold,
                pred,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            ),

        "ordinal_mae":
            float(
                ordinal_error.mean()
            ),

        "severe_error_rate":
            float(
                (ordinal_error == 2).mean()
            ),

        "within_one_class":
            float(
                (ordinal_error <= 1).mean()
            ),

        "f1_low":
            float(class_f1[0]),

        "f1_medium":
            float(class_f1[1]),

        "f1_high":
            float(class_f1[2]),
    }


# ============================================================================
# METHOD DISCOVERY
# ============================================================================

def pretty_method_name(
    directory_name,
    has_unbalanced=False,
):
    name = directory_name.lower()

    if name == "zero":
        return "Zero-shot"

    if (
        name.startswith(
            "three_shot_seed_"
        )
    ):
        seed = name.split(
            "three_shot_seed_",
            1,
        )[1]

        return (
            f"3-shot\nseed {seed}"
        )

    if (
        name.startswith(
            "three-shot-seed-"
        )
    ):
        seed = name.rsplit(
            "-",
            1,
        )[1]

        return (
            f"3-shot\nseed {seed}"
        )

    if name in {
        "sft_unbalanced",
        "sft-original",
        "sft_original",
    }:
        return "SFT\nunbalanced"

    if name in {
        "sft_balanced",
        "balanced_sft",
    }:
        return "SFT\nbalanced"

    if name == "sft":
        if has_unbalanced:
            return "SFT\nbalanced"

        return "SFT"

    return directory_name.replace(
        "_",
        " ",
    )


def discover_methods(
    task_root,
):
    cv = (
        task_root
        / "outputs"
        / "final_cv"
    )

    methods = {}

    if not cv.exists():
        print(
            "Missing:",
            cv,
        )
        return methods

    has_unbalanced = (
        (cv / "sft_unbalanced").exists()
    )

    for d in sorted(
        cv.iterdir()
    ):
        if not d.is_dir():
            continue

        files = discover_prediction_files(
            d
        )

        if not files:
            continue

        display = pretty_method_name(
            d.name,
            has_unbalanced=has_unbalanced,
        )

        methods[display] = {
            "directory":
                d,

            "prediction_files":
                files,
        }

    return methods


# ============================================================================
# LOAD A TASK
# ============================================================================

def analyze_task(
    task_name,
    task_root,
):
    print()
    print("=" * 90)
    print(task_name)
    print("=" * 90)

    methods = discover_methods(
        task_root
    )

    if not methods:
        print(
            "No prediction methods discovered."
        )

        return (
            pd.DataFrame(),
            pd.DataFrame(),
            {},
        )

    metric_rows = []
    fold_rows = []
    pooled_predictions = {}

    # ------------------------------------------------------------------------
    # Real methods
    # ------------------------------------------------------------------------

    for method, info in methods.items():

        parts = []

        for fold, path in sorted(
            info[
                "prediction_files"
            ].items()
        ):

            df = read_prediction_file(
                path
            )

            if df.empty:
                continue

            df = df.copy()
            df["fold"] = fold

            parts.append(
                df
            )

            fm = compute_metrics(
                df["_gold"],
                df["_pred"],
            )

            fold_rows.append(
                {
                    "task":
                        task_name,

                    "method":
                        method,

                    "fold":
                        fold,

                    **fm,
                }
            )

        if not parts:
            continue

        pooled = pd.concat(
            parts,
            ignore_index=True,
        )

        pooled_predictions[
            method
        ] = pooled

        m = compute_metrics(
            pooled["_gold"],
            pooled["_pred"],
        )

        metric_rows.append(
            {
                "task":
                    task_name,

                "method":
                    method,

                **m,
            }
        )

        print(
            f"{method:24s} "
            f"n={m['n']:4d} "
            f"acc={m['accuracy']:.4f} "
            f"bal={m['balanced_accuracy']:.4f} "
            f"macroF1={m['macro_f1']:.4f} "
            f"MAE={m['ordinal_mae']:.4f}"
        )

    metrics_df = pd.DataFrame(
        metric_rows
    )

    folds_df = pd.DataFrame(
        fold_rows
    )

    if metrics_df.empty:
        return (
            metrics_df,
            folds_df,
            pooled_predictions,
        )

    # ------------------------------------------------------------------------
    # Majority baseline
    # ------------------------------------------------------------------------

    source_method = None

    for candidate in [
        "Zero-shot",
        "SFT",
        "SFT\nunbalanced",
        "SFT\nbalanced",
    ]:
        if candidate in pooled_predictions:
            source_method = candidate
            break

    if source_method is None:
        source_method = next(
            iter(
                pooled_predictions
            )
        )

    gold = pooled_predictions[
        source_method
    ]["_gold"]

    majority = gold.value_counts().idxmax()

    majority_pred = [
        majority
    ] * len(gold)

    majority_metrics = compute_metrics(
        gold,
        majority_pred,
    )

    baseline_row = {
        "task":
            task_name,

        "method":
            f"Majority\n({majority})",

        **majority_metrics,
    }

    metrics_df = pd.concat(
        [
            pd.DataFrame(
                [baseline_row]
            ),
            metrics_df,
        ],
        ignore_index=True,
    )

    # ------------------------------------------------------------------------
    # 3-shot mean across discovered seeds
    # ------------------------------------------------------------------------

    three = metrics_df[
        metrics_df["method"]
        .str.startswith(
            "3-shot",
            na=False,
        )
        &
        (
            metrics_df["method"]
            != "3-shot\nmean"
        )
    ].copy()

    if len(three) >= 2:

        numeric = [
            "accuracy",
            "balanced_accuracy",
            "macro_f1",
            "weighted_f1",
            "ordinal_mae",
            "severe_error_rate",
            "within_one_class",
            "f1_low",
            "f1_medium",
            "f1_high",
        ]

        mean_row = {
            "task":
                task_name,

            "method":
                "3-shot\nmean",

            "n":
                int(
                    round(
                        three["n"].mean()
                    )
                ),
        }

        for c in numeric:
            mean_row[c] = (
                three[c].mean()
            )

        metrics_df = pd.concat(
            [
                metrics_df,
                pd.DataFrame(
                    [mean_row]
                ),
            ],
            ignore_index=True,
        )

        # Per-fold seed mean.
        three_folds = folds_df[
            folds_df[
                "method"
            ].str.startswith(
                "3-shot",
                na=False,
            )
        ]

        if not three_folds.empty:

            grouped = (
                three_folds
                .groupby(
                    [
                        "task",
                        "fold",
                    ],
                    as_index=False,
                )[
                    numeric
                ]
                .mean()
            )

            grouped[
                "method"
            ] = "3-shot\nmean"

            grouped[
                "n"
            ] = np.nan

            folds_df = pd.concat(
                [
                    folds_df,
                    grouped,
                ],
                ignore_index=True,
            )

    return (
        metrics_df,
        folds_df,
        pooled_predictions,
    )


# ============================================================================
# ANALYZE BOTH FINAL DT1 SUBTASKS
# ============================================================================

linalg_metrics, linalg_folds, linalg_preds = (
    analyze_task(
        "DT1(a) Linalg fusion",
        LINALG_ROOT,
    )
)

torch_metrics, torch_folds, torch_preds = (
    analyze_task(
        "DT1(b) Torch simplification",
        TORCH_ROOT,
    )
)

all_metrics = pd.concat(
    [
        linalg_metrics,
        torch_metrics,
    ],
    ignore_index=True,
)

all_folds = pd.concat(
    [
        linalg_folds,
        torch_folds,
    ],
    ignore_index=True,
)


# ============================================================================
# SAVE RAW SUMMARY TABLES
# ============================================================================

all_metrics.to_csv(
    FIG_DIR
    / "dt1_metrics_summary.csv",
    index=False,
)

all_folds.to_csv(
    FIG_DIR
    / "dt1_fold_metrics.csv",
    index=False,
)


# ============================================================================
# METHOD ORDER
# ============================================================================

def method_sort_key(method):
    text = (
        str(method)
        .replace("\n", " ")
        .lower()
    )

    if text.startswith(
        "majority"
    ):
        return (
            0,
            0,
        )

    if text == "zero-shot":
        return (
            1,
            0,
        )

    if (
        text.startswith(
            "3-shot"
        )
        and "seed" in text
    ):
        m = re.search(
            r"seed\s+(\d+)",
            text,
        )

        seed = (
            int(m.group(1))
            if m
            else 0
        )

        return (
            2,
            seed,
        )

    if text == "3-shot mean":
        return (
            3,
            0,
        )

    if (
        "sft"
        in text
        and "unbalanced"
        in text
    ):
        return (
            4,
            0,
        )

    if (
        "sft"
        in text
        and "balanced"
        in text
    ):
        return (
            5,
            0,
        )

    if text == "sft":
        return (
            5,
            0,
        )

    return (
        10,
        text,
    )


# ============================================================================
# GENERAL METHOD COMPARISON
# ============================================================================

def plot_method_comparison(
    metric,
    title,
    ylabel,
    filename,
    percent=False,
    lower_is_better=False,
):
    if all_metrics.empty:
        return

    methods = sorted(
        all_metrics[
            "method"
        ].unique(),
        key=method_sort_key,
    )

    tasks = [
        "DT1(a) Linalg fusion",
        "DT1(b) Torch simplification",
    ]

    x = np.arange(
        len(methods)
    )

    width = 0.36

    fig, ax = plt.subplots(
        figsize=(
            max(
                11,
                len(methods) * 1.25,
            ),
            6.5,
        )
    )

    for task_index, task in enumerate(
        tasks
    ):

        sub = (
            all_metrics[
                all_metrics[
                    "task"
                ]
                == task
            ]
            .set_index(
                "method"
            )
        )

        vals = []

        for method in methods:

            if method in sub.index:
                value = (
                    sub.loc[
                        method,
                        metric,
                    ]
                )

                if isinstance(
                    value,
                    pd.Series,
                ):
                    value = (
                        value.iloc[0]
                    )

                if percent:
                    value *= 100

                vals.append(
                    value
                )

            else:
                vals.append(
                    np.nan
                )

        offset = (
            task_index
            - 0.5
        ) * width

        ax.bar(
            x + offset,
            vals,
            width=width,
            label=task,
        )

    ax.set_title(
        title,
        fontsize=15,
        fontweight="bold",
    )

    ax.set_ylabel(
        ylabel
    )

    ax.set_xticks(
        x
    )

    ax.set_xticklabels(
        methods,
        rotation=30,
        ha="right",
    )

    ax.grid(
        axis="y",
        alpha=0.25,
    )

    ax.legend()

    if percent:
        ax.set_ylim(
            bottom=0
        )

    elif not lower_is_better:
        ax.set_ylim(
            bottom=0
        )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR
        / filename,
        dpi=300,
        bbox_inches="tight",
    )

    fig.savefig(
        FIG_DIR
        / filename.replace(
            ".png",
            ".pdf",
        ),
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


plot_method_comparison(
    metric="accuracy",
    title="DT1 Accuracy Across All Evaluation Settings",
    ylabel="Accuracy (%)",
    filename="01_dt1_accuracy_all_methods.png",
    percent=True,
)

plot_method_comparison(
    metric="balanced_accuracy",
    title="DT1 Balanced Accuracy Across All Evaluation Settings",
    ylabel="Balanced accuracy (%)",
    filename="02_dt1_balanced_accuracy_all_methods.png",
    percent=True,
)

plot_method_comparison(
    metric="macro_f1",
    title="DT1 Macro-F1 Across All Evaluation Settings",
    ylabel="Macro-F1 (%)",
    filename="03_dt1_macro_f1_all_methods.png",
    percent=True,
)

plot_method_comparison(
    metric="ordinal_mae",
    title="DT1 Ordinal Error Across All Evaluation Settings",
    ylabel="Ordinal MAE",
    filename="04_dt1_ordinal_mae_all_methods.png",
    lower_is_better=True,
)

plot_method_comparison(
    metric="severe_error_rate",
    title="DT1 Severe Error Rate Across All Evaluation Settings",
    ylabel="Severe error rate (%)",
    filename="05_dt1_severe_error_all_methods.png",
    percent=True,
    lower_is_better=True,
)


# ============================================================================
# PER-CLASS F1
# ============================================================================

def plot_per_class(
    task,
    filename,
):
    df = all_metrics[
        all_metrics["task"]
        == task
    ].copy()

    if df.empty:
        return

    # Remove majority baseline because its class-F1
    # profile dominates the visualization without
    # adding much interpretive value.
    df = df[
        ~df[
            "method"
        ].str.startswith(
            "Majority",
            na=False,
        )
    ]

    methods = sorted(
        df["method"].unique(),
        key=method_sort_key,
    )

    df = (
        df.set_index(
            "method"
        )
        .reindex(
            methods
        )
    )

    x = np.arange(
        len(methods)
    )

    width = 0.25

    fig, ax = plt.subplots(
        figsize=(
            max(
                10,
                len(methods) * 1.25,
            ),
            6.5,
        )
    )

    for i, (
        col,
        label,
    ) in enumerate(
        [
            (
                "f1_low",
                "LOW",
            ),
            (
                "f1_medium",
                "MEDIUM",
            ),
            (
                "f1_high",
                "HIGH",
            ),
        ]
    ):

        ax.bar(
            x
            + (
                i - 1
            ) * width,
            df[col].values * 100,
            width=width,
            label=label,
        )

    ax.set_title(
        f"{task}: Per-Class F1",
        fontsize=15,
        fontweight="bold",
    )

    ax.set_ylabel(
        "F1 score (%)"
    )

    ax.set_xticks(
        x
    )

    ax.set_xticklabels(
        methods,
        rotation=30,
        ha="right",
    )

    ax.set_ylim(
        0,
        100,
    )

    ax.grid(
        axis="y",
        alpha=0.25,
    )

    ax.legend(
        title="Benefit class"
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR / filename,
        dpi=300,
        bbox_inches="tight",
    )

    fig.savefig(
        FIG_DIR
        / filename.replace(
            ".png",
            ".pdf",
        ),
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


plot_per_class(
    "DT1(a) Linalg fusion",
    "06_dt1a_per_class_f1.png",
)

plot_per_class(
    "DT1(b) Torch simplification",
    "07_dt1b_per_class_f1.png",
)


# ============================================================================
# SFT FOLD VARIABILITY
# ============================================================================

def plot_sft_folds(
    task,
    filename,
):
    df = all_folds[
        all_folds["task"]
        == task
    ].copy()

    if df.empty:
        return

    df = df[
        df[
            "method"
        ].str.contains(
            "SFT",
            case=False,
            na=False,
        )
    ]

    if df.empty:
        return

    fig, ax = plt.subplots(
        figsize=(
            9,
            6,
        )
    )

    for method in sorted(
        df["method"].unique(),
        key=method_sort_key,
    ):

        sub = (
            df[
                df[
                    "method"
                ]
                == method
            ]
            .sort_values(
                "fold"
            )
        )

        ax.plot(
            sub["fold"],
            sub["macro_f1"] * 100,
            marker="o",
            linewidth=2,
            label=method.replace(
                "\n",
                " ",
            ),
        )

    ax.set_title(
        f"{task}: SFT Macro-F1 Across Family-Disjoint Folds",
        fontsize=14,
        fontweight="bold",
    )

    ax.set_xlabel(
        "Fold"
    )

    ax.set_ylabel(
        "Macro-F1 (%)"
    )

    ax.set_xticks(
        sorted(
            df[
                "fold"
            ].dropna().unique()
        )
    )

    ax.set_ylim(
        0,
        100,
    )

    ax.grid(
        alpha=0.25,
    )

    ax.legend()

    fig.tight_layout()

    fig.savefig(
        FIG_DIR / filename,
        dpi=300,
        bbox_inches="tight",
    )

    fig.savefig(
        FIG_DIR
        / filename.replace(
            ".png",
            ".pdf",
        ),
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


plot_sft_folds(
    "DT1(a) Linalg fusion",
    "08_dt1a_sft_fold_variability.png",
)

plot_sft_folds(
    "DT1(b) Torch simplification",
    "09_dt1b_sft_fold_variability.png",
)


# ============================================================================
# TORCH BALANCING ABLATION
# ============================================================================

torch_sft = all_metrics[
    (
        all_metrics["task"]
        == "DT1(b) Torch simplification"
    )
    &
    (
        all_metrics[
            "method"
        ].str.contains(
            "SFT",
            case=False,
            na=False,
        )
    )
].copy()

if len(
    torch_sft
) >= 2:

    preferred = [
        "SFT\nunbalanced",
        "SFT\nbalanced",
    ]

    available = [
        x
        for x in preferred
        if x in set(
            torch_sft["method"]
        )
    ]

    if len(
        available
    ) >= 2:

        sub = (
            torch_sft
            .set_index(
                "method"
            )
            .loc[
                available
            ]
        )

        metrics = [
            (
                "accuracy",
                "Accuracy",
            ),
            (
                "balanced_accuracy",
                "Balanced\naccuracy",
            ),
            (
                "macro_f1",
                "Macro-F1",
            ),
            (
                "f1_medium",
                "MEDIUM F1",
            ),
            (
                "f1_high",
                "HIGH F1",
            ),
        ]

        x = np.arange(
            len(metrics)
        )

        width = 0.36

        fig, ax = plt.subplots(
            figsize=(
                10,
                6,
            )
        )

        for i, method in enumerate(
            available
        ):

            vals = [
                sub.loc[
                    method,
                    col,
                ] * 100
                for col, _
                in metrics
            ]

            ax.bar(
                x
                + (
                    i - 0.5
                ) * width,
                vals,
                width=width,
                label=method.replace(
                    "\n",
                    " ",
                ),
            )

        ax.set_title(
            "DT1(b): Effect of Class-Balanced SFT",
            fontsize=15,
            fontweight="bold",
        )

        ax.set_ylabel(
            "Score (%)"
        )

        ax.set_xticks(
            x
        )

        ax.set_xticklabels(
            [
                label
                for _, label
                in metrics
            ]
        )

        ax.set_ylim(
            0,
            100,
        )

        ax.grid(
            axis="y",
            alpha=0.25,
        )

        ax.legend()

        fig.tight_layout()

        fig.savefig(
            FIG_DIR
            / "10_dt1b_balancing_ablation.png",
            dpi=300,
            bbox_inches="tight",
        )

        fig.savefig(
            FIG_DIR
            / "10_dt1b_balancing_ablation.pdf",
            bbox_inches="tight",
        )

        plt.close(
            fig
        )


# ============================================================================
# CONFUSION MATRICES
# ============================================================================

def plot_confusion(
    pooled,
    title,
    filename,
):
    cm = confusion_matrix(
        pooled["_gold"],
        pooled["_pred"],
        labels=LABELS,
    )

    fig, ax = plt.subplots(
        figsize=(
            6.5,
            5.5,
        )
    )

    im = ax.imshow(
        cm,
        aspect="auto",
    )

    ax.set_title(
        title,
        fontsize=14,
        fontweight="bold",
    )

    ax.set_xlabel(
        "Predicted class"
    )

    ax.set_ylabel(
        "Gold class"
    )

    ax.set_xticks(
        range(
            len(LABELS)
        )
    )

    ax.set_yticks(
        range(
            len(LABELS)
        )
    )

    ax.set_xticklabels(
        LABELS
    )

    ax.set_yticklabels(
        LABELS
    )

    threshold = (
        cm.max() / 2
        if cm.size
        else 0
    )

    for i in range(
        cm.shape[0]
    ):
        for j in range(
            cm.shape[1]
        ):
            ax.text(
                j,
                i,
                str(
                    cm[i, j]
                ),
                ha="center",
                va="center",
            )

    fig.colorbar(
        im,
        ax=ax,
        label="Programs",
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR / filename,
        dpi=300,
        bbox_inches="tight",
    )

    fig.savefig(
        FIG_DIR
        / filename.replace(
            ".png",
            ".pdf",
        ),
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


# Linalg final SFT
for candidate in [
    "SFT\nbalanced",
    "SFT",
    "SFT\nunbalanced",
]:
    if candidate in linalg_preds:

        plot_confusion(
            linalg_preds[
                candidate
            ],
            "DT1(a): SFT Confusion Matrix",
            "11_dt1a_sft_confusion_matrix.png",
        )

        break


# Torch balanced SFT preferred
for candidate in [
    "SFT\nbalanced",
    "SFT",
]:
    if candidate in torch_preds:

        plot_confusion(
            torch_preds[
                candidate
            ],
            "DT1(b): Balanced SFT Confusion Matrix",
            "12_dt1b_balanced_sft_confusion_matrix.png",
        )

        break


if (
    "SFT\nunbalanced"
    in torch_preds
):
    plot_confusion(
        torch_preds[
            "SFT\nunbalanced"
        ],
        "DT1(b): Unbalanced SFT Confusion Matrix",
        "13_dt1b_unbalanced_sft_confusion_matrix.png",
    )


# ============================================================================
# COMPILER TRANSFORMATION COVERAGE
# ============================================================================

coverage_rows = []


# Linalg fusion.
fusion_scan = (
    LINALG_ROOT
    / "outputs"
    / "fusion_scan_results.csv"
)

if fusion_scan.exists():

    df = pd.read_csv(
        fusion_scan
    )

    valid = df[
        df[
            "fusion_success"
        ]
        == True
    ].copy()

    if len(
        valid
    ):

        coverage_rows.append(
            {
                "transformation":
                    "Linalg elementwise fusion",

                "valid_programs":
                    len(valid),

                "changed_programs":
                    int(
                        valid[
                            "fusion_changed_ir"
                        ].sum()
                    ),

                "changed_fraction":
                    float(
                        valid[
                            "fusion_changed_ir"
                        ].mean()
                    ),
            }
        )


# Torch simplification.
torch_scan = (
    TORCH_ROOT
    / "outputs"
    / "torch_opt_scan.csv"
)

if torch_scan.exists():

    df = pd.read_csv(
        torch_scan
    )

    success_col = (
        "simplification_pipeline_success"
    )

    changed_col = (
        "simplification_pipeline_changed_ir"
    )

    if (
        success_col
        in df.columns
        and changed_col
        in df.columns
    ):

        valid = df[
            df[
                success_col
            ]
            == True
        ].copy()

        if len(
            valid
        ):

            coverage_rows.append(
                {
                    "transformation":
                        "Torch simplification",

                    "valid_programs":
                        len(valid),

                    "changed_programs":
                        int(
                            valid[
                                changed_col
                            ].sum()
                        ),

                    "changed_fraction":
                        float(
                            valid[
                                changed_col
                            ].mean()
                        ),
                }
            )


if coverage_rows:

    coverage = pd.DataFrame(
        coverage_rows
    )

    coverage.to_csv(
        FIG_DIR
        / "compiler_transformation_coverage.csv",
        index=False,
    )

    fig, ax = plt.subplots(
        figsize=(
            8,
            5.5,
        )
    )

    ax.bar(
        coverage[
            "transformation"
        ],
        coverage[
            "changed_fraction"
        ] * 100,
    )

    ax.set_title(
        "Compiler-Grounded Transformation Coverage",
        fontsize=14,
        fontweight="bold",
    )

    ax.set_ylabel(
        "Programs with changed IR (%)"
    )

    ax.set_ylim(
        0,
        100,
    )

    ax.grid(
        axis="y",
        alpha=0.25,
    )

    fig.tight_layout()

    fig.savefig(
        FIG_DIR
        / "14_dt1_transformation_coverage.png",
        dpi=300,
        bbox_inches="tight",
    )

    fig.savefig(
        FIG_DIR
        / "14_dt1_transformation_coverage.pdf",
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


# ============================================================================
# RISC-V BACKEND EXTENSION
# ============================================================================

riscv_summary_path = (
    LINALG_ROOT
    / "outputs"
    / "riscv_backend_extension"
    / "riscv_backend_summary.json"
)

if riscv_summary_path.exists():

    with riscv_summary_path.open() as f:
        riscv = json.load(
            f
        )

    by_benefit = riscv.get(
        "by_fusion_benefit",
        {},
    )

    rows = []

    for benefit in LABELS:

        item = by_benefit.get(
            benefit,
            {}
        )

        if not item:
            continue

        rows.append(
            {
                "benefit":
                    benefit,

                "n":
                    item.get(
                        "n",
                        0,
                    ),

                "improved":
                    item.get(
                        "improved",
                        0,
                    ),

                "tied":
                    item.get(
                        "tied",
                        0,
                    ),

                "worsened":
                    item.get(
                        "worsened",
                        0,
                    ),

                "mean_instruction_reduction_pct":
                    item.get(
                        "mean_instruction_reduction_pct",
                        np.nan,
                    ),

                "mean_vector_instruction_delta":
                    item.get(
                        "mean_vector_instruction_delta",
                        np.nan,
                    ),
            }
        )

    backend = pd.DataFrame(
        rows
    )

    if not backend.empty:

        backend.to_csv(
            FIG_DIR
            / "riscv_backend_by_benefit.csv",
            index=False,
        )

        # --------------------------------------------------------------------
        # Outcome counts
        # --------------------------------------------------------------------

        x = np.arange(
            len(
                backend
            )
        )

        width = 0.25

        fig, ax = plt.subplots(
            figsize=(
                8,
                5.5,
            )
        )

        for i, (
            col,
            label,
        ) in enumerate(
            [
                (
                    "improved",
                    "Improved",
                ),
                (
                    "tied",
                    "Tied",
                ),
                (
                    "worsened",
                    "Worsened",
                ),
            ]
        ):

            ax.bar(
                x
                + (
                    i - 1
                ) * width,
                backend[col],
                width=width,
                label=label,
            )

        ax.set_title(
            "RISC-V Backend Outcome by Fusion-Benefit Class",
            fontsize=14,
            fontweight="bold",
        )

        ax.set_ylabel(
            "Programs"
        )

        ax.set_xticks(
            x
        )

        ax.set_xticklabels(
            backend[
                "benefit"
            ]
        )

        ax.grid(
            axis="y",
            alpha=0.25,
        )

        ax.legend()

        fig.tight_layout()

        fig.savefig(
            FIG_DIR
            / "15_dt1_riscv_backend_outcomes.png",
            dpi=300,
            bbox_inches="tight",
        )

        fig.savefig(
            FIG_DIR
            / "15_dt1_riscv_backend_outcomes.pdf",
            bbox_inches="tight",
        )

        plt.close(
            fig
        )

        # --------------------------------------------------------------------
        # Instruction reduction
        # --------------------------------------------------------------------

        fig, ax = plt.subplots(
            figsize=(
                8,
                5.5,
            )
        )

        ax.bar(
            backend[
                "benefit"
            ],
            backend[
                "mean_instruction_reduction_pct"
            ],
        )

        ax.axhline(
            0,
            linewidth=1,
        )

        ax.set_title(
            "RISC-V Mean Instruction Reduction by Fusion-Benefit Class",
            fontsize=14,
            fontweight="bold",
        )

        ax.set_xlabel(
            "Fusion-benefit class"
        )

        ax.set_ylabel(
            "Mean instruction reduction (%)"
        )

        ax.grid(
            axis="y",
            alpha=0.25,
        )

        fig.tight_layout()

        fig.savefig(
            FIG_DIR
            / "16_dt1_riscv_instruction_reduction.png",
            dpi=300,
            bbox_inches="tight",
        )

        fig.savefig(
            FIG_DIR
            / "16_dt1_riscv_instruction_reduction.pdf",
            bbox_inches="tight",
        )

        plt.close(
            fig
        )


# ============================================================================
# OPTIONAL: GENERIC OPTIMIZATION EXPLORATION
# ============================================================================

generic_scan = (
    GENERIC_ROOT
    / "outputs"
    / "generic_opt_scan.csv"
)

if generic_scan.exists():

    df = pd.read_csv(
        generic_scan
    )

    rows = []

    passes = [
        (
            "canonicalize",
            "Canonicalize",
        ),
        (
            "cse",
            "CSE",
        ),
        (
            "canonicalize_cse",
            "Canonicalize + CSE",
        ),
    ]

    for prefix, display in passes:

        success_col = (
            f"{prefix}_success"
        )

        changed_col = (
            f"{prefix}_changed_ir"
        )

        if (
            success_col
            not in df.columns
            or changed_col
            not in df.columns
        ):
            continue

        for dialect in [
            "linalg",
            "torch",
        ]:

            part = df[
                (
                    df["dialect"]
                    == dialect
                )
                &
                (
                    df[
                        success_col
                    ]
                    == True
                )
            ]

            if part.empty:
                continue

            rows.append(
                {
                    "pass":
                        display,

                    "dialect":
                        dialect,

                    "changed_fraction":
                        part[
                            changed_col
                        ].mean(),
                }
            )

    generic_summary = pd.DataFrame(
        rows
    )

    if not generic_summary.empty:

        generic_summary.to_csv(
            FIG_DIR
            / "generic_opt_exploration.csv",
            index=False,
        )

        pass_names = [
            x
            for x in [
                "Canonicalize",
                "CSE",
                "Canonicalize + CSE",
            ]
            if x in set(
                generic_summary[
                    "pass"
                ]
            )
        ]

        x = np.arange(
            len(
                pass_names
            )
        )

        width = 0.36

        fig, ax = plt.subplots(
            figsize=(
                9,
                5.5,
            )
        )

        for i, dialect in enumerate(
            [
                "linalg",
                "torch",
            ]
        ):

            values = []

            for pass_name in pass_names:

                row = generic_summary[
                    (
                        generic_summary[
                            "pass"
                        ]
                        == pass_name
                    )
                    &
                    (
                        generic_summary[
                            "dialect"
                        ]
                        == dialect
                    )
                ]

                value = (
                    row[
                        "changed_fraction"
                    ].iloc[0] * 100
                    if len(row)
                    else np.nan
                )

                values.append(
                    value
                )

            ax.bar(
                x
                + (
                    i - 0.5
                ) * width,
                values,
                width=width,
                label=dialect,
            )

        ax.set_title(
            "Exploratory Cross-Dialect Optimization Coverage",
            fontsize=14,
            fontweight="bold",
        )

        ax.set_ylabel(
            "Programs with changed IR (%)"
        )

        ax.set_xticks(
            x
        )

        ax.set_xticklabels(
            pass_names
        )

        ax.grid(
            axis="y",
            alpha=0.25,
        )

        ax.legend(
            title="Dialect"
        )

        fig.tight_layout()

        fig.savefig(
            FIG_DIR
            / "17_exploratory_generic_optimizations.png",
            dpi=300,
            bbox_inches="tight",
        )

        plt.close(
            fig
        )


# ============================================================================
# OPTIONAL: TORCH PASS EXPLORATION
# ============================================================================

if torch_scan.exists():

    df = pd.read_csv(
        torch_scan
    )

    pass_specs = [
        (
            "simplification_pipeline",
            "Simplification\npipeline",
        ),
        (
            "reduce_op_variants",
            "Reduce op\nvariants",
        ),
        (
            "simplify_shapes",
            "Simplify\nshapes",
        ),
        (
            "decompose_complex",
            "Decompose\ncomplex",
        ),
    ]

    rows = []

    for prefix, display in pass_specs:

        success_col = (
            f"{prefix}_success"
        )

        changed_col = (
            f"{prefix}_changed_ir"
        )

        if (
            success_col
            not in df.columns
            or changed_col
            not in df.columns
        ):
            continue

        valid = df[
            df[
                success_col
            ]
            == True
        ]

        if valid.empty:
            continue

        rows.append(
            {
                "pass":
                    display,

                "success":
                    len(valid),

                "changed_fraction":
                    valid[
                        changed_col
                    ].mean(),
            }
        )

    pass_df = pd.DataFrame(
        rows
    )

    if not pass_df.empty:

        fig, ax = plt.subplots(
            figsize=(
                9,
                5.5,
            )
        )

        ax.bar(
            pass_df[
                "pass"
            ],
            pass_df[
                "changed_fraction"
            ] * 100,
        )

        ax.set_title(
            "Torch-Specific Compiler Pass Coverage",
            fontsize=14,
            fontweight="bold",
        )

        ax.set_ylabel(
            "Programs with changed IR (%)"
        )

        ax.set_ylim(
            0,
            100,
        )

        ax.grid(
            axis="y",
            alpha=0.25,
        )

        fig.tight_layout()

        fig.savefig(
            FIG_DIR
            / "18_exploratory_torch_passes.png",
            dpi=300,
            bbox_inches="tight",
        )

        plt.close(
            fig
        )


# ============================================================================
# FINAL REPORT
# ============================================================================

print()
print("=" * 90)
print("DT1 FIGURES COMPLETE")
print("=" * 90)

print(
    "\nMetrics summary:"
)

display_cols = [
    "task",
    "method",
    "n",
    "accuracy",
    "balanced_accuracy",
    "macro_f1",
    "ordinal_mae",
    "severe_error_rate",
    "f1_low",
    "f1_medium",
    "f1_high",
]

existing = [
    c
    for c in display_cols
    if c in all_metrics.columns
]

if not all_metrics.empty:

    print(
        all_metrics[
            existing
        ]
        .sort_values(
            [
                "task",
                "method",
            ]
        )
        .to_string(
            index=False
        )
    )

print(
    "\nSaved figures to:"
)

print(
    FIG_DIR
)

print(
    "\nGenerated files:"
)

for path in sorted(
    FIG_DIR.iterdir()
):
    print(
        " ",
        path.name,
    )
