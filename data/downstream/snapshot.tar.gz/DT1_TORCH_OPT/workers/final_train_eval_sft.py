import argparse
import inspect
import json
import os
import sys
from pathlib import Path

import pandas as pd
import torch

from peft import (
    LoraConfig,
    get_peft_model,
)

from torch.utils.data import Dataset

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_TORCH_OPT"
)

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from final_common import (
    CLASS_TO_CODE,
    CODE_TO_CLASS,
    MODEL_NAME,
    load_fold,
    metrics_dict,
    resolve_code_token_ids,
    zero_shot_prompt,
)


parser = argparse.ArgumentParser()

parser.add_argument(
    "--fold",
    type=int,
    required=True,
)

args = parser.parse_args()

FOLD = args.fold

if FOLD not in range(5):
    raise ValueError(
        "fold must be 0..4"
    )


SEED = 42
NUM_EPOCHS = 3
LEARNING_RATE = 1e-4
GRAD_ACCUM = int(
    os.environ.get(
        "FUSION_GRAD_ACCUM",
        "4",
    )
)

MAX_SEQ_LEN = 32768


RUN = (
    ROOT
    / "outputs"
    / "final_cv"
    / "sft"
    / f"fold_{FOLD}"
)

ADAPTER = (
    RUN / "adapter"
)

CHECKPOINTS = (
    RUN / "checkpoints"
)

RUN.mkdir(
    parents=True,
    exist_ok=True,
)

ADAPTER.mkdir(
    parents=True,
    exist_ok=True,
)

CHECKPOINTS.mkdir(
    parents=True,
    exist_ok=True,
)


torch.backends.cuda.matmul.allow_tf32 = True


train_df = load_fold(
    FOLD,
    "train",
)

val_df = load_fold(
    FOLD,
    "val",
)


print("=" * 80)
print(
    f"FINAL TORCH SIMPLIFICATION SFT FOLD {FOLD}"
)
print("=" * 80)

print(
    "\nTrain:",
    len(train_df),
)

print(
    train_df[
        "simplification_benefit"
    ].value_counts()
)

print(
    "\nValidation:",
    len(val_df),
)

print(
    val_df[
        "simplification_benefit"
    ].value_counts()
)


tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )

tokenizer.padding_side = "right"


sample_prompt = zero_shot_prompt(
    tokenizer,
    train_df.iloc[0],
)

code_ids = resolve_code_token_ids(
    tokenizer,
    sample_prompt,
)

print(
    "\nClass token IDs:",
    code_ids,
)


class FusionDataset(Dataset):

    def __init__(
        self,
        dataframe,
    ):
        self.examples = []

        lengths = []

        for _, row in dataframe.iterrows():

            prompt = zero_shot_prompt(
                tokenizer,
                row,
            )

            prompt_ids = tokenizer(
                prompt,
                add_special_tokens=False,
            )["input_ids"]

            gold = str(
                row[
                    "simplification_benefit"
                ]
            )

            code = CLASS_TO_CODE[
                gold
            ]

            full_ids = tokenizer(
                prompt + code,
                add_special_tokens=False,
            )["input_ids"]

            if (
                full_ids[
                    :len(prompt_ids)
                ]
                != prompt_ids
            ):
                raise RuntimeError(
                    "Prompt prefix mismatch"
                )

            continuation = full_ids[
                len(prompt_ids):
            ]

            if len(continuation) != 1:
                raise RuntimeError(
                    f"Expected one class token, "
                    f"got {continuation}"
                )

            token_id = continuation[0]

            input_ids = (
                prompt_ids
                + [token_id]
            )

            if (
                len(input_ids)
                > MAX_SEQ_LEN
            ):
                raise RuntimeError(
                    f"Sequence too long: "
                    f"{len(input_ids)}"
                )

            labels = (
                [-100]
                * len(prompt_ids)
                + [token_id]
            )

            self.examples.append(
                {
                    "input_ids":
                        input_ids,

                    "attention_mask":
                        [1]
                        * len(input_ids),

                    "labels":
                        labels,
                }
            )

            lengths.append(
                len(input_ids)
            )

        print(
            "Dataset lengths:",
            "min=", min(lengths),
            "mean=",
            sum(lengths)
            / len(lengths),
            "max=", max(lengths),
        )


    def __len__(self):
        return len(
            self.examples
        )


    def __getitem__(
        self,
        index,
    ):
        return self.examples[
            index
        ]


class Collator:

    def __init__(
        self,
        tokenizer,
    ):
        self.tokenizer = tokenizer


    def __call__(
        self,
        features,
    ):
        max_len = max(
            len(
                x["input_ids"]
            )
            for x in features
        )

        ids = []
        masks = []
        labels = []

        for x in features:

            pad = (
                max_len
                - len(
                    x["input_ids"]
                )
            )

            ids.append(
                x["input_ids"]
                + [
                    self.tokenizer
                    .pad_token_id
                ] * pad
            )

            masks.append(
                x["attention_mask"]
                + [0] * pad
            )

            labels.append(
                x["labels"]
                + [-100] * pad
            )

        return {
            "input_ids":
                torch.tensor(
                    ids,
                    dtype=torch.long,
                ),

            "attention_mask":
                torch.tensor(
                    masks,
                    dtype=torch.long,
                ),

            "labels":
                torch.tensor(
                    labels,
                    dtype=torch.long,
                ),
        }


train_dataset = FusionDataset(
    train_df
)

val_dataset = FusionDataset(
    val_df
)

collator = Collator(
    tokenizer
)


print("\nLoading model...")

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    low_cpu_mem_usage=True,
    trust_remote_code=True,
)

model.config.use_cache = False

model.gradient_checkpointing_enable()


lora = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.0,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=[
        "q_proj",
        "v_proj",
    ],
)


model = get_peft_model(
    model,
    lora,
)

model.print_trainable_parameters()


params = inspect.signature(
    TrainingArguments.__init__
).parameters


kwargs = {
    "output_dir":
        str(CHECKPOINTS),

    "num_train_epochs":
        NUM_EPOCHS,

    "per_device_train_batch_size":
        1,

    "per_device_eval_batch_size":
        1,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "learning_rate":
        LEARNING_RATE,

    "bf16":
        True,

    "tf32":
        True,

    "logging_steps":
        10,

    "save_strategy":
        "epoch",

    "save_total_limit":
        2,

    "report_to":
        "none",

    "seed":
        SEED,

    "remove_unused_columns":
        False,

    "gradient_checkpointing":
        True,

    "optim":
        "adamw_torch_fused",
}


if "eval_strategy" in params:
    kwargs[
        "eval_strategy"
    ] = "epoch"

elif (
    "evaluation_strategy"
    in params
):
    kwargs[
        "evaluation_strategy"
    ] = "epoch"

else:
    raise RuntimeError(
        "No evaluation strategy "
        "argument available"
    )


kwargs[
    "load_best_model_at_end"
] = True

kwargs[
    "metric_for_best_model"
] = "eval_loss"

kwargs[
    "greater_is_better"
] = False


if "warmup_steps" in params:
    kwargs[
        "warmup_steps"
    ] = 20


trainer = Trainer(
    model=model,
    args=TrainingArguments(
        **kwargs
    ),
    train_dataset=
        train_dataset,
    eval_dataset=
        val_dataset,
    data_collator=
        collator,
)


trainer.train()


# Trainer has restored best checkpoint.
trainer.save_model(
    str(ADAPTER)
)

tokenizer.save_pretrained(
    str(ADAPTER)
)


metadata = {
    "fold":
        FOLD,

    "model":
        MODEL_NAME,

    "train_examples":
        len(train_df),

    "val_examples":
        len(val_df),

    "epochs":
        NUM_EPOCHS,

    "learning_rate":
        LEARNING_RATE,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "lora_r":
        16,

    "lora_alpha":
        32,

    "target_modules":
        [
            "q_proj",
            "v_proj",
        ],

    "target_encoding": {
        "A": "LOW",
        "B": "MEDIUM",
        "C": "HIGH",
    },

    "best_model_checkpoint":
        trainer.state
        .best_model_checkpoint,

    "best_eval_loss":
        trainer.state
        .best_metric,
}


with (
    RUN
    / "training_metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


# ============================================================
# Direct-logit evaluation without reloading the 14B model.
# ============================================================

print(
    "\nStarting direct-logit "
    "held-out evaluation..."
)

model = trainer.model
model.eval()

tokenizer.padding_side = "left"

code_ids = resolve_code_token_ids(
    tokenizer,
    zero_shot_prompt(
        tokenizer,
        val_df.iloc[0],
    ),
)

candidate_ids = torch.tensor(
    [
        code_ids["A"],
        code_ids["B"],
        code_ids["C"],
    ],
    dtype=torch.long,
    device=next(
        model.parameters()
    ).device,
)


BATCH_SIZE = 4

records = []


for start in range(
    0,
    len(val_df),
    BATCH_SIZE,
):

    batch = val_df.iloc[
        start:
        start + BATCH_SIZE
    ]

    prompts = [
        zero_shot_prompt(
            tokenizer,
            row,
        )

        for _, row
        in batch.iterrows()
    ]

    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=False,
        add_special_tokens=False,
    ).to(
        next(
            model.parameters()
        ).device
    )

    with torch.inference_mode():

        output = model(
            **inputs,
            use_cache=False,
        )

    last_logits = (
        output.logits[
            :,
            -1,
            :
        ]
        .float()
    )

    candidate_logits = (
        last_logits[
            :,
            candidate_ids
        ]
    )

    probabilities = (
        torch.softmax(
            candidate_logits,
            dim=-1,
        )
        .cpu()
    )

    predicted_indices = (
        candidate_logits
        .argmax(
            dim=-1
        )
        .cpu()
        .tolist()
    )


    for local_index, (
        (_, row)
    ) in enumerate(
        batch.iterrows()
    ):

        code = [
            "A",
            "B",
            "C",
        ][
            predicted_indices[
                local_index
            ]
        ]

        prediction = (
            CODE_TO_CLASS[
                code
            ]
        )

        record = row.to_dict()

        record[
            "prediction"
        ] = prediction

        record[
            "predicted_code"
        ] = code

        record[
            "correct"
        ] = (
            prediction
            == row[
                "simplification_benefit"
            ]
        )

        record[
            "prob_LOW"
        ] = float(
            probabilities[
                local_index,
                0,
            ]
        )

        record[
            "prob_MEDIUM"
        ] = float(
            probabilities[
                local_index,
                1,
            ]
        )

        record[
            "prob_HIGH"
        ] = float(
            probabilities[
                local_index,
                2,
            ]
        )

        records.append(
            record
        )


result = pd.DataFrame(
    records
)

metrics = metrics_dict(
    result[
        "simplification_benefit"
    ],
    result[
        "prediction"
    ],
)

metrics[
    "fold"
] = FOLD

metrics[
    "method"
] = "sft"


result.to_csv(
    RUN
    / "val_predictions.csv",
    index=False,
)

with (
    RUN
    / "val_metrics.json"
).open("w") as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


print(
    "\n" + "=" * 80
)

print(
    f"SFT FOLD {FOLD} RESULT"
)

print("=" * 80)

print(
    json.dumps(
        metrics,
        indent=2,
    )
)

print("\nSaved:", RUN)
