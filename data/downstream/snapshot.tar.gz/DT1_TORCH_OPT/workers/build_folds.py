import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_TORCH_OPT"
)

SOURCE = (
    ROOT
    / "data"
    / "torch_dataset"
    / "torch_dataset.csv"
)

OUT = ROOT / "data" / "folds"
OUT.mkdir(parents=True, exist_ok=True)


SEED = 42
N_SPLITS = 5


df = pd.read_csv(SOURCE)

df = (
    df.sort_values("dt1_id")
      .reset_index(drop=True)
)


print("=" * 80)
print("TORCH FAMILY-DISJOINT 5-FOLD SPLIT")
print("=" * 80)

print("\nPrograms:", len(df))
print("Families:", df["base_family"].nunique())

print("\nOverall class distribution:")
print(df["simplification_benefit"].value_counts())


splitter = StratifiedGroupKFold(
    n_splits=N_SPLITS,
    shuffle=True,
    random_state=SEED,
)


splits = list(
    splitter.split(
        X=df,
        y=df["simplification_benefit"],
        groups=df["base_family"],
    )
)


metadata = {
    "seed": SEED,
    "n_splits": N_SPLITS,
    "split_method":
        "StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=42)",
    "target":
        "simplification_benefit",
    "group":
        "base_family",
    "total":
        int(len(df)),
    "families":
        int(df["base_family"].nunique()),
    "class_counts":
        {
            str(k): int(v)
            for k, v in
            df["simplification_benefit"]
            .value_counts()
            .items()
        },
    "folds": {},
}


all_val_ids = []
all_val_families = []


for fold, (train_idx, val_idx) in enumerate(splits):

    train = (
        df.iloc[train_idx]
        .copy()
        .reset_index(drop=True)
    )

    val = (
        df.iloc[val_idx]
        .copy()
        .reset_index(drop=True)
    )


    train_families = set(
        train["base_family"]
    )

    val_families = set(
        val["base_family"]
    )

    train_hashes = set(
        train["mlir_hash"]
    )

    val_hashes = set(
        val["mlir_hash"]
    )


    family_overlap = (
        train_families
        & val_families
    )

    hash_overlap = (
        train_hashes
        & val_hashes
    )


    assert len(family_overlap) == 0
    assert len(hash_overlap) == 0


    fold_dir = (
        OUT
        / f"fold_{fold}"
    )

    fold_dir.mkdir(
        parents=True,
        exist_ok=True,
    )


    train.to_csv(
        fold_dir / "train.csv",
        index=False,
    )

    val.to_csv(
        fold_dir / "val.csv",
        index=False,
    )

    train.to_json(
        fold_dir / "train.json",
        orient="records",
        indent=2,
    )

    val.to_json(
        fold_dir / "val.json",
        orient="records",
        indent=2,
    )


    all_val_ids.extend(
        val["dt1_id"].tolist()
    )

    all_val_families.extend(
        val["base_family"].tolist()
    )


    metadata["folds"][str(fold)] = {
        "train":
            int(len(train)),

        "validation":
            int(len(val)),

        "train_families":
            int(len(train_families)),

        "validation_families":
            int(len(val_families)),

        "family_overlap":
            0,

        "mlir_hash_overlap":
            0,

        "train_class_counts":
            {
                str(k): int(v)
                for k, v in
                train[
                    "simplification_benefit"
                ]
                .value_counts()
                .items()
            },

        "validation_class_counts":
            {
                str(k): int(v)
                for k, v in
                val[
                    "simplification_benefit"
                ]
                .value_counts()
                .items()
            },

        "validation_families_list":
            sorted(val_families),
    }


    print()
    print("=" * 72)
    print(f"FOLD {fold}")
    print("=" * 72)

    print(
        f"Train: {len(train)} "
        f"| families: {len(train_families)}"
    )

    print(
        train[
            "simplification_benefit"
        ].value_counts()
    )

    print()

    print(
        f"Validation: {len(val)} "
        f"| families: {len(val_families)}"
    )

    print(
        val[
            "simplification_benefit"
        ].value_counts()
    )

    print(
        "\nValidation families:"
    )

    print(
        ", ".join(
            sorted(val_families)
        )
    )

    print(
        "\nFamily overlap:",
        len(family_overlap),
    )

    print(
        "MLIR hash overlap:",
        len(hash_overlap),
    )


# Every program should appear in validation exactly once.
assert len(all_val_ids) == len(df)
assert len(set(all_val_ids)) == len(df)

# Every family should belong to one validation fold only.
assert (
    len(set(all_val_families))
    ==
    df["base_family"].nunique()
)


with (
    OUT / "metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print()
print("=" * 80)
print("GLOBAL LEAKAGE CHECK")
print("=" * 80)

print(
    "Validation rows across folds:",
    len(all_val_ids),
)

print(
    "Unique validation rows:",
    len(set(all_val_ids)),
)

print(
    "Unique validation families:",
    len(set(all_val_families)),
)

print()
print("Saved:", OUT)
