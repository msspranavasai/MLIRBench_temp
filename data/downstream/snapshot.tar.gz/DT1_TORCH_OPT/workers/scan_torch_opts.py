import argparse
import json
import os
import re
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench"
)

ROOT = BASE / "DT1_TORCH_OPT"

SOURCE = (
    BASE
    / "DT1_GENERIC_OPT"
    / "data"
    / "unique_programs.csv"
)

OUT = ROOT / "outputs"
PER_PROGRAM = OUT / "per_program"

OUT.mkdir(parents=True, exist_ok=True)
PER_PROGRAM.mkdir(parents=True, exist_ok=True)

IREE_OPT = shutil.which("iree-opt")

if IREE_OPT is None:
    raise RuntimeError("iree-opt not found")


PASSES = {
    "simplification_pipeline": [
        "--torch-simplification-pipeline",
    ],

    "reduce_op_variants": [
        "--torch-reduce-op-variants",
    ],

    "simplify_shapes": [
        "--torch-simplify-shape-calculations",
    ],

    "decompose_complex": [
        "--torch-decompose-complex-ops",
    ],
}


parser = argparse.ArgumentParser()

parser.add_argument(
    "--num-shards",
    type=int,
    default=1,
)

parser.add_argument(
    "--shard-index",
    type=int,
    default=0,
)

parser.add_argument(
    "--workers",
    type=int,
    default=16,
)

parser.add_argument(
    "--limit",
    type=int,
    default=None,
)

parser.add_argument(
    "--force",
    action="store_true",
)

parser.add_argument(
    "--aggregate-only",
    action="store_true",
)

args = parser.parse_args()


def run(cmd):
    proc = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    return {
        "success": proc.returncode == 0,
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }


def normalize(text):
    return re.sub(
        r"\s+",
        " ",
        str(text),
    ).strip()


def count_ops(text):
    """
    Count operation-looking lines in generic MLIR form.

    This is deliberately generic because Torch custom syntax
    may otherwise be difficult to count consistently.
    """

    count = 0

    for raw in text.splitlines():
        line = raw.strip()

        if not line:
            continue

        if line.startswith(
            (
                "module",
                "func.func",
                "^bb",
                "}",
                "{",
            )
        ):
            continue

        if (
            "=" in line
            or re.search(
                r'\b(?:torch|arith|tensor|func|prim)\.',
                line
            )
        ):
            count += 1

    return count


def generic_ir(path, pass_args=None):
    cmd = [
        IREE_OPT,
        str(path),
        "--mlir-print-op-generic",
    ]

    if pass_args:
        cmd.extend(pass_args)

    return run(cmd)


def atomic_write(path, obj):
    tmp = path.with_suffix(
        ".json.tmp"
    )

    with tmp.open("w") as f:
        json.dump(
            obj,
            f,
            indent=2,
        )

    os.replace(
        tmp,
        path,
    )


def process(row):
    dt1_id = str(
        row["dt1_id"]
    )

    result_path = (
        PER_PROGRAM
        / f"{dt1_id}.json"
    )

    if (
        result_path.exists()
        and not args.force
    ):
        with result_path.open() as f:
            return json.load(f)

    source = Path(
        row["mlir_path"]
    )

    record = {
        "dt1_id": dt1_id,
        "mlir_hash": str(
            row["mlir_hash"]
        ),
        "dialect": str(
            row["dialect"]
        ),
        "base_families": str(
            row["base_families"]
        ),
        "semantic_labels": str(
            row["semantic_labels"]
        ),
    }

    baseline = generic_ir(
        source
    )

    record[
        "baseline_success"
    ] = baseline["success"]

    if not baseline["success"]:
        record[
            "baseline_stderr"
        ] = baseline[
            "stderr"
        ][-3000:]

        atomic_write(
            result_path,
            record,
        )

        return record

    baseline_text = baseline[
        "stdout"
    ]

    baseline_norm = normalize(
        baseline_text
    )

    before_ops = count_ops(
        baseline_text
    )

    record[
        "ops_before"
    ] = before_ops

    record[
        "chars_before"
    ] = len(
        baseline_text
    )

    for name, pass_args in PASSES.items():

        result = generic_ir(
            source,
            pass_args,
        )

        record[
            f"{name}_success"
        ] = result["success"]

        if not result["success"]:
            record[
                f"{name}_stderr"
            ] = result[
                "stderr"
            ][-3000:]
            continue

        text = result[
            "stdout"
        ]

        norm = normalize(
            text
        )

        after_ops = count_ops(
            text
        )

        delta = (
            before_ops
            - after_ops
        )

        record[
            f"{name}_changed_ir"
        ] = (
            norm
            != baseline_norm
        )

        record[
            f"{name}_ops_after"
        ] = after_ops

        record[
            f"{name}_ops_removed"
        ] = delta

        record[
            f"{name}_abs_ops_change"
        ] = abs(delta)

        record[
            f"{name}_reduction_pct"
        ] = (
            delta
            / before_ops
            * 100.0
            if before_ops > 0
            else 0.0
        )

        record[
            f"{name}_chars_after"
        ] = len(text)

        record[
            f"{name}_chars_delta"
        ] = (
            len(text)
            - len(
                baseline_text
            )
        )

    atomic_write(
        result_path,
        record,
    )

    return record


def aggregate():

    source = pd.read_csv(
        SOURCE
    )

    source = source[
        source["dialect"] == "torch"
    ].copy()

    expected_ids = set(
        source["dt1_id"]
        .astype(str)
    )

    rows = []

    for path in sorted(
        PER_PROGRAM.glob(
            "*.json"
        )
    ):
        with path.open() as f:
            row = json.load(f)

        if str(
            row.get("dt1_id")
        ) in expected_ids:
            rows.append(row)

    df = pd.DataFrame(
        rows
    )

    df = (
        df
        .drop_duplicates(
            "dt1_id"
        )
        .sort_values(
            "dt1_id"
        )
    )

    df.to_csv(
        OUT
        / "torch_opt_scan.csv",
        index=False,
    )

    print("=" * 88)
    print("TORCH-SPECIFIC OPTIMIZATION SCAN")
    print("=" * 88)

    print(
        "\nPrograms expected:",
        len(source),
    )

    print(
        "Programs completed:",
        len(df),
    )

    summary = {}

    for name in PASSES:

        print()
        print("=" * 72)
        print(name.upper())
        print("=" * 72)

        success_col = (
            f"{name}_success"
        )

        good = df[
            df[success_col] == True
        ].copy()

        changed = (
            good[
                f"{name}_changed_ir"
            ]
            .fillna(False)
        )

        print(
            "Success:",
            len(good),
        )

        print(
            "Changed IR:",
            int(
                changed.sum()
            ),
        )

        print(
            "Changed fraction:",
            float(
                changed.mean()
            )
            if len(good)
            else 0.0,
        )

        print(
            "\nOps removed:"
        )

        print(
            good[
                f"{name}_ops_removed"
            ].describe(
                percentiles=[
                    .10,
                    .25,
                    .50,
                    .75,
                    .90,
                    .95,
                ]
            )
        )

        print(
            "\nAbsolute op change:"
        )

        print(
            good[
                f"{name}_abs_ops_change"
            ].describe(
                percentiles=[
                    .10,
                    .25,
                    .50,
                    .75,
                    .90,
                    .95,
                ]
            )
        )

        print(
            "\nChanged-only ops removed:"
        )

        changed_df = good[
            changed
        ]

        if len(changed_df):
            print(
                changed_df[
                    f"{name}_ops_removed"
                ].describe()
            )
        else:
            print(
                "No changed programs."
            )

        summary[name] = {
            "success":
                int(
                    len(good)
                ),

            "changed":
                int(
                    changed.sum()
                ),

            "changed_fraction":
                float(
                    changed.mean()
                )
                if len(good)
                else 0.0,

            "mean_ops_removed":
                float(
                    good[
                        f"{name}_ops_removed"
                    ].mean()
                )
                if len(good)
                else None,

            "median_ops_removed":
                float(
                    good[
                        f"{name}_ops_removed"
                    ].median()
                )
                if len(good)
                else None,

            "mean_abs_ops_change":
                float(
                    good[
                        f"{name}_abs_ops_change"
                    ].mean()
                )
                if len(good)
                else None,

            "median_abs_ops_change":
                float(
                    good[
                        f"{name}_abs_ops_change"
                    ].median()
                )
                if len(good)
                else None,
        }

    with (
        OUT
        / "torch_opt_summary.json"
    ).open("w") as f:
        json.dump(
            summary,
            f,
            indent=2,
        )

    print("\nSaved:")
    print(
        OUT
        / "torch_opt_scan.csv"
    )

    print(
        OUT
        / "torch_opt_summary.json"
    )


def main():

    if args.aggregate_only:
        aggregate()
        return

    df = pd.read_csv(
        SOURCE
    )

    df = df[
        df["dialect"] == "torch"
    ].copy()

    df = (
        df
        .sort_values(
            "dt1_id"
        )
        .reset_index(
            drop=True
        )
    )

    if args.limit is not None:
        df = df.head(
            args.limit
        )
    else:
        df = df[
            df.index
            % args.num_shards
            == args.shard_index
        ]

    print("=" * 72)
    print("TORCH OPTIMIZATION SCAN")
    print("=" * 72)

    print(
        "Host:",
        os.uname().nodename,
    )

    print(
        "Programs:",
        len(df),
    )

    print(
        "Shard:",
        f"{args.shard_index}/"
        f"{args.num_shards}",
    )

    print(
        "Workers:",
        args.workers,
    )

    with ThreadPoolExecutor(
        max_workers=args.workers
    ) as pool:

        futures = {
            pool.submit(
                process,
                row,
            ):
                row["dt1_id"]

            for _, row
            in df.iterrows()
        }

        done = 0

        rows = []

        for future in as_completed(
            futures
        ):
            rows.append(
                future.result()
            )

            done += 1

            if (
                done % 25 == 0
                or done == len(df)
            ):
                print(
                    f"{done}/{len(df)}"
                )

    shard_path = (
        OUT
        / (
            f"shard_{args.shard_index}"
            f"_of_{args.num_shards}.csv"
        )
    )

    pd.DataFrame(
        rows
    ).to_csv(
        shard_path,
        index=False,
    )

    print(
        "Saved:",
        shard_path,
    )


if __name__ == "__main__":
    main()
