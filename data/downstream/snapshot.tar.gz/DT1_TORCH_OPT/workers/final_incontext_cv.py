import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
)


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_TORCH_OPT"
)

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from final_common import (
    CODE_TO_CLASS,
    MODEL_NAME,
    choose_three_shot,
    few_shot_prompt,
    load_fold,
    metrics_dict,
    resolve_code_token_ids,
    zero_shot_prompt,
)


parser = argparse.ArgumentParser()

parser.add_argument(
    "--mode",
    choices=[
        "zero",
        "three-shot",
    ],
    required=True,
)

parser.add_argument(
    "--seed",
    type=int,
    default=42,
)

args = parser.parse_args()

MODE = args.mode
SEED = args.seed


if MODE == "zero":

    TAG = "zero"

else:

    TAG = (
        f"three_shot_seed_{SEED}"
    )


OUT = (
    ROOT
    / "outputs"
    / "final_cv"
    / TAG
)

OUT.mkdir(
    parents=True,
    exist_ok=True,
)


torch.backends.cuda.matmul.allow_tf32 = True


print("=" * 80)
print(
    f"FINAL {TAG.upper()} "
    "5-FOLD EVALUATION"
)
print("=" * 80)


tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )

tokenizer.padding_side = "left"


print("\nLoading model once...")

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model.eval()

device = next(
    model.parameters()
).device


all_fold_metrics = []


for fold in range(5):

    print(
        "\n" + "=" * 72
    )

    print(
        f"{TAG} FOLD {fold}"
    )

    print("=" * 72)


    train_df = load_fold(
        fold,
        "train",
    )

    val_df = load_fold(
        fold,
        "val",
    )


    examples = None

    if MODE == "three-shot":

        examples = choose_three_shot(
            train_df,
            SEED,
        )

        print(
            "Demonstrations:"
        )

        for ex in examples:

            print(
                ex["dt1_id"],
                ex["simplification_benefit"],
                ex["base_family"],
            )


    def make_prompt(row):

        if MODE == "zero":

            return zero_shot_prompt(
                tokenizer,
                row,
            )

        return few_shot_prompt(
            tokenizer,
            row,
            examples,
        )


    sample_prompt = make_prompt(
        val_df.iloc[0]
    )

    code_ids = resolve_code_token_ids(
        tokenizer,
        sample_prompt,
    )

    candidate_ids = torch.tensor(
        [
            code_ids["A"],
            code_ids["B"],
            code_ids["C"],
        ],
        dtype=torch.long,
        device=device,
    )


    lengths = []

    for _, row in (
        val_df.iterrows()
    ):

        prompt = make_prompt(
            row
        )

        lengths.append(
            len(
                tokenizer(
                    prompt,
                    add_special_tokens=False,
                )[
                    "input_ids"
                ]
            )
        )


    print(
        "Prompt lengths:",
        "min=", min(lengths),
        "mean=",
        sum(lengths)
        / len(lengths),
        "max=", max(lengths),
    )


    if max(lengths) >= 32768:

        raise RuntimeError(
            f"Prompt exceeds context "
            f"window: {max(lengths)}"
        )


    # 3-shot prompts are substantially longer.
    BATCH_SIZE = (
        4
        if MODE == "zero"
        else 2
    )


    records = []


    for start in range(
        0,
        len(val_df),
        BATCH_SIZE,
    ):

        batch = val_df.iloc[
            start:
            start + BATCH_SIZE
        ]

        prompts = [
            make_prompt(
                row
            )

            for _, row
            in batch.iterrows()
        ]


        inputs = tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=False,
            add_special_tokens=False,
        ).to(
            device
        )


        with torch.inference_mode():

            output = model(
                **inputs,
                use_cache=False,
            )


        last_logits = (
            output.logits[
                :,
                -1,
                :
            ]
            .float()
        )


        candidate_logits = (
            last_logits[
                :,
                candidate_ids
            ]
        )


        probabilities = (
            torch.softmax(
                candidate_logits,
                dim=-1,
            )
            .cpu()
        )


        predicted_indices = (
            candidate_logits
            .argmax(
                dim=-1
            )
            .cpu()
            .tolist()
        )


        for local_index, (
            (_, row)
        ) in enumerate(
            batch.iterrows()
        ):

            code = [
                "A",
                "B",
                "C",
            ][
                predicted_indices[
                    local_index
                ]
            ]

            prediction = (
                CODE_TO_CLASS[
                    code
                ]
            )

            record = (
                row.to_dict()
            )

            record[
                "prediction"
            ] = prediction

            record[
                "predicted_code"
            ] = code

            record[
                "correct"
            ] = (
                prediction
                == row[
                    "simplification_benefit"
                ]
            )

            record[
                "prob_LOW"
            ] = float(
                probabilities[
                    local_index,
                    0,
                ]
            )

            record[
                "prob_MEDIUM"
            ] = float(
                probabilities[
                    local_index,
                    1,
                ]
            )

            record[
                "prob_HIGH"
            ] = float(
                probabilities[
                    local_index,
                    2,
                ]
            )

            records.append(
                record
            )


    result = pd.DataFrame(
        records
    )


    metrics = metrics_dict(
        result[
            "simplification_benefit"
        ],
        result[
            "prediction"
        ],
    )


    metrics[
        "fold"
    ] = fold

    metrics[
        "method"
    ] = TAG

    metrics[
        "prompt_lengths"
    ] = {
        "min":
            int(
                min(lengths)
            ),

        "mean":
            float(
                sum(lengths)
                / len(lengths)
            ),

        "max":
            int(
                max(lengths)
            ),
    }


    result.to_csv(
        OUT
        / f"fold_{fold}_val_predictions.csv",
        index=False,
    )


    with (
        OUT
        / f"fold_{fold}_val_metrics.json"
    ).open("w") as f:

        json.dump(
            metrics,
            f,
            indent=2,
        )


    if examples is not None:

        demo_records = [
            {
                "dt1_id":
                    str(
                        ex["dt1_id"]
                    ),

                "simplification_benefit":
                    str(
                        ex[
                            "simplification_benefit"
                        ]
                    ),

                "base_family":
                    str(
                        ex[
                            "base_family"
                        ]
                    ),
            }

            for ex in examples
        ]


        with (
            OUT
            / f"fold_{fold}_examples.json"
        ).open("w") as f:

            json.dump(
                demo_records,
                f,
                indent=2,
            )


    all_fold_metrics.append(
        metrics
    )


    print(
        json.dumps(
            metrics,
            indent=2,
        )
    )


with (
    OUT
    / "all_fold_metrics.json"
).open("w") as f:

    json.dump(
        all_fold_metrics,
        f,
        indent=2,
    )


print(
    "\nCompleted all five folds."
)
