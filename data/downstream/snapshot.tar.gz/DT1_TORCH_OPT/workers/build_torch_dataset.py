import json
import re
from pathlib import Path

import pandas as pd


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench"
)

ROOT = BASE / "DT1_TORCH_OPT"

UNIQUE = (
    BASE
    / "DT1_GENERIC_OPT"
    / "data"
    / "unique_programs.csv"
)

SCAN = (
    ROOT
    / "outputs"
    / "torch_opt_scan.csv"
)

OUT = (
    ROOT
    / "data"
    / "torch_dataset"
)

OUT.mkdir(
    parents=True,
    exist_ok=True,
)


PATTERN = re.compile(
    r"^torch_(seed\d+)_(prog\d+)_T(\d+)_R(\d+)$"
)


def parse_ids(value):

    parsed = []

    for pid in str(value).split(";"):

        pid = pid.strip()

        if not pid:
            continue

        m = PATTERN.match(pid)

        if not m:
            raise ValueError(
                f"Could not parse Torch program ID: {pid}"
            )

        parsed.append(
            {
                "program_id": pid,
                "base_family":
                    f"{m.group(1)}_{m.group(2)}",
                "level":
                    int(m.group(3)),
                "replicate":
                    int(m.group(4)),
            }
        )

    return parsed


unique = pd.read_csv(
    UNIQUE
)

unique = unique[
    unique["dialect"] == "torch"
].copy()


scan = pd.read_csv(
    SCAN
)

scan = scan[
    scan[
        "simplification_pipeline_success"
    ] == True
].copy()


df = scan.merge(
    unique[
    [
        "dt1_id",
        "mlir_hash",
        "mlir_path",
        "program_ids",
    ]
    ],
    on=[
        "dt1_id",
        "mlir_hash",
    ],
    how="left",
    validate="one_to_one",
)


base_families = []
representative_levels = []
representative_ids = []
family_counts = []


for _, row in df.iterrows():

    parsed = parse_ids(
        row["program_ids"]
    )

    families = sorted({
        p["base_family"]
        for p in parsed
    })

    if len(families) != 1:
        raise ValueError(
            f"{row['dt1_id']} spans families: {families}"
        )

    representative = sorted(
        parsed,
        key=lambda p: (
            p["level"],
            p["replicate"],
            p["program_id"],
        ),
    )[0]

    base_families.append(
        families[0]
    )

    family_counts.append(
        len(families)
    )

    representative_levels.append(
        representative["level"]
    )

    representative_ids.append(
        representative["program_id"]
    )


df["base_family"] = base_families
df["family_count"] = family_counts
df["level"] = representative_levels
df["program_id"] = representative_ids


# ============================================================
# Compiler-grounded target
#
# LOW:    <= 0 operations removed
# MEDIUM: 1-2 operations removed
# HIGH:   >= 3 operations removed
# ============================================================

x = df[
    "simplification_pipeline_ops_removed"
]


def benefit(v):

    if v <= 0:
        return "LOW"

    if v <= 2:
        return "MEDIUM"

    return "HIGH"


df["simplification_benefit"] = (
    x.apply(benefit)
)


# Cleaner singular semantic label when possible.
df["semantic_label"] = (
    df["semantic_labels"]
    .astype(str)
    .apply(
        lambda s:
            s
            if ";" not in s
            else "MULTI"
    )
)


columns = [
    "dt1_id",
    "program_id",
    "mlir_hash",
    "mlir_path",
    "base_family",
    "level",
    "semantic_label",
    "semantic_labels",

    "ops_before",

    "simplification_pipeline_changed_ir",
    "simplification_pipeline_ops_after",
    "simplification_pipeline_ops_removed",
    "simplification_pipeline_reduction_pct",

    "simplification_benefit",
]


df = df[
    columns
].sort_values(
    "dt1_id"
).reset_index(
    drop=True
)


csv_path = (
    OUT
    / "torch_dataset.csv"
)

json_path = (
    OUT
    / "torch_dataset.json"
)

metadata_path = (
    OUT
    / "metadata.json"
)


df.to_csv(
    csv_path,
    index=False,
)

with json_path.open("w") as f:
    json.dump(
        df.to_dict(
            orient="records"
        ),
        f,
        indent=2,
    )


metadata = {
    "population":
        "compiler-valid unique MLIRBench Torch programs",

    "optimization":
        "torch-simplification-pipeline",

    "total":
        int(len(df)),

    "families":
        int(
            df[
                "base_family"
            ].nunique()
        ),

    "class_definition": {
        "LOW":
            "operations_removed <= 0",

        "MEDIUM":
            "1 <= operations_removed <= 2",

        "HIGH":
            "operations_removed >= 3",
    },

    "class_counts":
        {
            str(k): int(v)
            for k, v
            in df[
                "simplification_benefit"
            ].value_counts().items()
        },

    "level_counts":
        {
            str(k): int(v)
            for k, v
            in df[
                "level"
            ].value_counts().items()
        },

    "semantic_label_counts":
        {
            str(k): int(v)
            for k, v
            in df[
                "semantic_label"
            ].value_counts().items()
        },
}


with metadata_path.open("w") as f:
    json.dump(
        metadata,
        f,
        indent=2,
    )


print("=" * 80)
print("FINAL TORCH SIMPLIFICATION DATASET")
print("=" * 80)

print("\nPrograms:", len(df))
print(
    "Families:",
    df["base_family"].nunique(),
)

print("\nBenefit classes:")
print(
    df[
        "simplification_benefit"
    ].value_counts()
)

print("\nLevels:")
print(
    df["level"].value_counts()
    .sort_index()
)

print("\nSemantic labels:")
print(
    df[
        "semantic_label"
    ].value_counts()
)

print("\nOperations removed:")
print(
    df[
        "simplification_pipeline_ops_removed"
    ].describe()
)

print("\nSaved:")
print(csv_path)
print(json_path)
print(metadata_path)
