import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
)


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_TORCH_OPT"
)

FOLDS = ROOT / "data" / "folds"

MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"

CLASSES = [
    "LOW",
    "MEDIUM",
    "HIGH",
]

CLASS_TO_CODE = {
    "LOW": "A",
    "MEDIUM": "B",
    "HIGH": "C",
}

CODE_TO_CLASS = {
    "A": "LOW",
    "B": "MEDIUM",
    "C": "HIGH",
}

ORDINAL = {
    "LOW": 0,
    "MEDIUM": 1,
    "HIGH": 2,
}


def load_fold(fold, split):
    with (
        FOLDS
        / f"fold_{fold}"
        / f"{split}.json"
    ).open() as f:
        return pd.DataFrame(
            json.load(f)
        )


def count(text, pattern):
    return len(
        re.findall(
            pattern,
            str(text),
        )
    )



def program_text(row):
    """
    Return the original Torch MLIR program text.

    DT1_TORCH_OPT stores the program in the file referenced by mlir_path.
    """

    # Support inline program text too, if ever present.
    for key in [
        "mlir",
        "mutated_mlir",
        "program",
    ]:
        try:
            value = row.get(key, None)
        except Exception:
            value = None

        if value is not None:
            value = str(value).strip()

            if value and value.lower() != "nan":
                return value

    # Current dataset format.
    try:
        path_value = row.get(
            "mlir_path",
            None,
        )
    except Exception:
        path_value = None

    if path_value is not None:
        path = Path(
            str(path_value)
        )

        if path.exists():
            return path.read_text(
                errors="replace"
            )

    return ""


def static_features(row):
    """
    Static Torch-program features derived only from the input program.
    """

    mlir = program_text(row)
    lowered = mlir.lower()

    def count(pattern):
        return len(
            re.findall(
                pattern,
                mlir,
                flags=re.IGNORECASE,
            )
        )

    return {
        "chars":
            len(mlir),

        "lines":
            len(
                mlir.splitlines()
            ),

        "torch_ops":
            count(
                r"\btorch\.[A-Za-z0-9_.]+"
            ),

        "aten_ops":
            count(
                r"\btorch\.aten\.[A-Za-z0-9_.]+"
            ),

        "arith_ops":
            count(
                r"\barith\.[A-Za-z0-9_.]+"
            ),

        "tensor_ops":
            count(
                r"\btensor\.[A-Za-z0-9_.]+"
            ),

        "add_tokens":
            len(
                re.findall(
                    r"add",
                    lowered,
                )
            ),

        "mul_tokens":
            len(
                re.findall(
                    r"mul",
                    lowered,
                )
            ),

        "slice_tokens":
            len(
                re.findall(
                    r"slice",
                    lowered,
                )
            ),

        "view_tokens":
            len(
                re.findall(
                    r"view",
                    lowered,
                )
            ),

        "reshape_tokens":
            len(
                re.findall(
                    r"reshape",
                    lowered,
                )
            ),

        "transpose_tokens":
            len(
                re.findall(
                    r"transpose",
                    lowered,
                )
            ),

        "permute_tokens":
            len(
                re.findall(
                    r"permute",
                    lowered,
                )
            ),

        "broadcast_tokens":
            len(
                re.findall(
                    r"broadcast",
                    lowered,
                )
            ),

        "cat_tokens":
            len(
                re.findall(
                    r"\bcat\b",
                    lowered,
                )
            ),

        "matmul_tokens":
            len(
                re.findall(
                    r"matmul|\.mm\b|\bbmm\b",
                    lowered,
                )
            ),

        "reduction_tokens":
            len(
                re.findall(
                    r"\bsum\b|\bmean\b|\bmax\b|\bmin\b|reduce",
                    lowered,
                )
            ),
    }


def task_text(row):
    """
    Torch simplification-benefit prediction task.
    """

    mlir = program_text(row)
    features = static_features(row)

    feature_lines = "\n".join(
        f"- {key}: {value}"
        for key, value
        in features.items()
    )

    return (
        "Predict the structural optimization benefit of applying the "
        "Torch simplification pipeline to the Torch-dialect program below.\n\n"

        "Compiler transformation:\n"
        "torch-simplification-pipeline\n\n"

        "The benefit classes are defined by the number of operations "
        "removed after applying the compiler transformation:\n\n"

        "LOW: removes no operations or increases operation count\n"
        "MEDIUM: removes 1 or 2 operations\n"
        "HIGH: removes 3 or more operations\n\n"

        "Output encoding:\n"
        "A = LOW\n"
        "B = MEDIUM\n"
        "C = HIGH\n\n"

        "Use only the original static program structure. "
        "Do not assume simplification is always beneficial.\n\n"

        "Static structural features:\n"
        f"{feature_lines}\n\n"

        "Torch MLIR program:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```\n\n"

        "Return exactly one token: A, B, or C."
    )


def zero_shot_prompt(
    tokenizer,
    row,
):
    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content":
                    task_text(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


def few_shot_prompt(
    tokenizer,
    row,
    examples,
):
    messages = []

    for ex in examples:
        messages.append(
            {
                "role": "user",
                "content":
                    task_text(ex),
            }
        )

        messages.append(
            {
                "role": "assistant",
                "content":
                    CLASS_TO_CODE[
                        str(
                            ex[
                                "simplification_benefit"
                            ]
                        )
                    ],
            }
        )

    messages.append(
        {
            "role": "user",
            "content":
                task_text(row),
        }
    )

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def choose_three_shot(
    train_df,
    seed,
):
    examples = []

    for index, label in enumerate(
        CLASSES
    ):
        subset = train_df[
            train_df[
                "simplification_benefit"
            ] == label
        ].copy()

        if subset.empty:
            raise RuntimeError(
                f"No training examples "
                f"for class {label}"
            )

        subset[
            "_chars"
        ] = (
            subset.apply(program_text, axis=1)
            .astype(str)
            .str.len()
        )

        # Short examples protect context length.
        pool = (
            subset
            .sort_values(
                "_chars"
            )
            .head(
                min(
                    20,
                    len(subset),
                )
            )
        )

        chosen = pool.sample(
            n=1,
            random_state=(
                seed
                + index * 1000
            ),
        ).iloc[0]

        examples.append(
            chosen
        )

    return examples


def resolve_code_token_ids(
    tokenizer,
    sample_prompt,
):
    prompt_ids = tokenizer(
        sample_prompt,
        add_special_tokens=False,
    )["input_ids"]

    result = {}

    for code in [
        "A",
        "B",
        "C",
    ]:
        full_ids = tokenizer(
            sample_prompt + code,
            add_special_tokens=False,
        )["input_ids"]

        if (
            full_ids[
                :len(prompt_ids)
            ]
            != prompt_ids
        ):
            raise RuntimeError(
                "Prompt prefix mismatch "
                f"for code {code}"
            )

        continuation = full_ids[
            len(prompt_ids):
        ]

        if len(continuation) != 1:
            raise RuntimeError(
                f"{code} is not one token "
                f"in context: {continuation}"
            )

        result[
            code
        ] = continuation[0]

    return result


def metrics_dict(
    y_true,
    y_pred,
):
    y_true = list(y_true)
    y_pred = list(y_pred)

    accuracy = accuracy_score(
        y_true,
        y_pred,
    )

    balanced_accuracy = (
        balanced_accuracy_score(
            y_true,
            y_pred,
        )
    )

    macro_f1 = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average="macro",
        zero_division=0,
    )

    weighted_f1 = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average="weighted",
        zero_division=0,
    )

    per_class = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average=None,
        zero_division=0,
    )

    distances = []

    for gold, pred in zip(
        y_true,
        y_pred,
    ):
        distances.append(
            abs(
                ORDINAL[gold]
                - ORDINAL[pred]
            )
        )

    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=CLASSES,
    )

    return {
        "n":
            int(len(y_true)),

        "accuracy":
            float(accuracy),

        "balanced_accuracy":
            float(
                balanced_accuracy
            ),

        "macro_f1":
            float(macro_f1),

        "weighted_f1":
            float(weighted_f1),

        "per_class_f1": {
            label:
                float(score)

            for label, score
            in zip(
                CLASSES,
                per_class,
            )
        },

        "ordinal_mae":
            float(
                np.mean(
                    distances
                )
            ),

        "severe_error_rate":
            float(
                np.mean(
                    [
                        d == 2
                        for d
                        in distances
                    ]
                )
            ),

        "within_one_class":
            float(
                np.mean(
                    [
                        d <= 1
                        for d
                        in distances
                    ]
                )
            ),

        "confusion_matrix_labels":
            CLASSES,

        "confusion_matrix":
            cm.tolist(),
    }
