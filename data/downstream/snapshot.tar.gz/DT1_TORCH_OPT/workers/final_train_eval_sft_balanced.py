import os
import random
import runpy
import sys
from pathlib import Path

import numpy as np
import pandas as pd


WORKERS = Path(__file__).resolve().parent

sys.path.insert(
    0,
    str(WORKERS),
)

import final_common


TARGET = "simplification_benefit"

LABELS = [
    "LOW",
    "MEDIUM",
    "HIGH",
]

BALANCE_SEED = int(
    os.environ.get(
        "BALANCE_SEED",
        "42",
    )
)


# ============================================================
# Reproducibility
# ============================================================

random.seed(
    BALANCE_SEED
)

np.random.seed(
    BALANCE_SEED
)

try:
    import torch

    torch.manual_seed(
        BALANCE_SEED
    )

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(
            BALANCE_SEED
        )

except Exception:
    pass


# ============================================================
# Preserve original loader
# ============================================================

_original_load_fold = (
    final_common.load_fold
)

_printed = set()


# ============================================================
# Balanced training loader
# ============================================================

def balanced_load_fold(
    fold,
    split,
):
    df = _original_load_fold(
        fold,
        split,
    ).copy()

    # --------------------------------------------------------
    # Validation/test data MUST remain untouched.
    # --------------------------------------------------------

    if str(split).lower() != "train":
        return df

    fold = int(fold)

    counts_before = (
        df[TARGET]
        .value_counts()
        .reindex(
            LABELS,
            fill_value=0,
        )
    )

    missing = [
        label
        for label in LABELS
        if counts_before[label] == 0
    ]

    if missing:
        raise RuntimeError(
            f"Fold {fold} is missing classes: {missing}"
        )

    # Largest class determines balanced size.
    target_n = int(
        counts_before.max()
    )

    pieces = []

    for label_index, label in enumerate(
        LABELS
    ):
        subset = df[
            df[TARGET] == label
        ].copy()

        current_n = len(
            subset
        )

        if current_n < target_n:

            extra_n = (
                target_n
                - current_n
            )

            extra = subset.sample(
                n=extra_n,
                replace=True,
                random_state=(
                    BALANCE_SEED
                    + fold * 1000
                    + label_index
                ),
            )

            subset = pd.concat(
                [
                    subset,
                    extra,
                ],
                ignore_index=True,
            )

        pieces.append(
            subset
        )

    balanced = pd.concat(
        pieces,
        ignore_index=True,
    )

    # Shuffle after oversampling.
    balanced = balanced.sample(
        frac=1.0,
        random_state=(
            BALANCE_SEED
            + fold * 1000
            + 999
        ),
    ).reset_index(
        drop=True
    )

    counts_after = (
        balanced[TARGET]
        .value_counts()
        .reindex(
            LABELS,
            fill_value=0,
        )
    )

    key = (
        fold,
        str(split),
    )

    if key not in _printed:

        _printed.add(
            key
        )

        print(
            "\n"
            + "=" * 80
        )

        print(
            f"BALANCED TRAINING FOLD {fold}"
        )

        print(
            "=" * 80
        )

        print(
            "\nBefore:"
        )

        print(
            counts_before
        )

        print(
            "\nAfter:"
        )

        print(
            counts_after
        )

        print(
            "\nOriginal rows:",
            len(df),
        )

        print(
            "Balanced rows:",
            len(balanced),
        )

        print(
            "=" * 80
            + "\n"
        )

    assert (
        len(
            set(
                counts_after.tolist()
            )
        )
        == 1
    )

    return balanced


# Make the original training script receive our loader.
final_common.load_fold = (
    balanced_load_fold
)


# ============================================================
# Optional CPU-only preflight
# ============================================================

if (
    os.environ.get(
        "BALANCE_PREFLIGHT_ONLY",
        "0",
    )
    == "1"
):

    for fold in range(5):

        train = balanced_load_fold(
            fold,
            "train",
        )

        val = _original_load_fold(
            fold,
            "val",
        )

        print(
            f"Fold {fold}: "
            f"train={len(train)}, "
            f"val={len(val)}"
        )

        print(
            "Validation:"
        )

        print(
            val[TARGET]
            .value_counts()
            .reindex(
                LABELS,
                fill_value=0,
            )
        )

        print()

    print(
        "BALANCED SFT PREFLIGHT PASSED"
    )

    raise SystemExit(0)


# ============================================================
# Run the existing SFT implementation unchanged.
# ============================================================

runpy.run_path(
    str(
        WORKERS
        / "final_train_eval_sft.py"
    ),
    run_name="__main__",
)
