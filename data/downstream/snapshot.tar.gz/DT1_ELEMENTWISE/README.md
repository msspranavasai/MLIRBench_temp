# MLIRBench Downstream Task 1: Elementwise Fusion

## Goal

Evaluate whether MLIRBench supervision helps a language model make
compiler-grounded elementwise fusion decisions for MLIR programs.

The model receives static MLIR and predicts whether an elementwise
producer-consumer fusion optimization should be applied.

The predicted optimization is then executed with the MLIR/IREE
compiler pipeline and lowered to RISC-V for compiler-grounded
evaluation.

## Planned evaluation

1. Build a corpus from real MLIRBench linalg programs.
2. Apply an elementwise fusion pipeline to each compiler-valid program.
3. Compare original and fused IR.
4. Define compiler-grounded APPLY_FUSION / KEEP_UNFUSED targets.
5. Use family-disjoint train/validation/test splits.
6. Compare:
   - static baseline
   - zero-shot Qwen2.5-Coder-14B-Instruct
   - few-shot
   - MLIRBench supervised fine-tuning
7. Apply predicted plans and measure actual compiler outcomes.

## Important

MLIRBench semantic labels (EQUIV / DIVERGE / ERROR) are retained as
metadata but are not automatically used as fusion targets.
