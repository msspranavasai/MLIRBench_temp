import json
import os
import platform
import subprocess
from pathlib import Path

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

OUT = ROOT / "outputs"
OUT.mkdir(parents=True, exist_ok=True)


def command(cmd):
    try:
        return subprocess.check_output(
            cmd,
            shell=True,
            text=True,
            stderr=subprocess.STDOUT,
        ).strip()
    except subprocess.CalledProcessError as e:
        return e.output.strip()


metadata = {
    "hostname": command("hostname"),
    "python": command("python --version"),
    "platform": platform.platform(),
    "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
    "slurm_cpus_on_node": os.environ.get("SLURM_CPUS_ON_NODE"),
    "iree_compile": command("which iree-compile"),
    "iree_opt": command("which iree-opt"),
    "iree_version": command("iree-compile --version"),
    "nvidia_smi": command(
        "nvidia-smi --query-gpu=index,name,memory.total "
        "--format=csv,noheader"
    ),
}

path = OUT / "environment.json"

with path.open("w") as f:
    json.dump(metadata, f, indent=2)

print(json.dumps(metadata, indent=2))
print("\nSaved:", path)
