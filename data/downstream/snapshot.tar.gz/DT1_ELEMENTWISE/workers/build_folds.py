import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

SOURCE = (
    ROOT
    / "data"
    / "fusion_dataset"
    / "fusion_dataset.json"
)

OUT = (
    ROOT
    / "data"
    / "folds"
)

OUT.mkdir(
    parents=True,
    exist_ok=True,
)


with SOURCE.open() as f:
    df = pd.DataFrame(
        json.load(f)
    )


sgkf = StratifiedGroupKFold(
    n_splits=5,
    shuffle=True,
    random_state=42,
)


metadata = {
    "seed": 42,
    "method":
        "StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=42)",

    "target":
        "fusion_benefit",

    "group":
        "base_family",

    "total":
        int(len(df)),

    "families":
        int(
            df["base_family"]
            .nunique()
        ),

    "folds": {},
}


print("=" * 80)
print("ELEMENTWISE FUSION FAMILY-DISJOINT FOLDS")
print("=" * 80)


for fold, (
    train_idx,
    val_idx,
) in enumerate(
    sgkf.split(
        df,
        df["fusion_benefit"],
        groups=df["base_family"],
    )
):

    train = (
        df.iloc[train_idx]
        .reset_index(drop=True)
    )

    val = (
        df.iloc[val_idx]
        .reset_index(drop=True)
    )


    train_families = set(
        train["base_family"]
    )

    val_families = set(
        val["base_family"]
    )


    family_overlap = (
        train_families
        & val_families
    )


    train_hashes = set(
        train["mlir_hash"]
    )

    val_hashes = set(
        val["mlir_hash"]
    )


    hash_overlap = (
        train_hashes
        & val_hashes
    )


    if family_overlap:
        raise RuntimeError(
            f"Family leakage fold {fold}: "
            f"{family_overlap}"
        )


    if hash_overlap:
        raise RuntimeError(
            f"MLIR leakage fold {fold}: "
            f"{len(hash_overlap)}"
        )


    fold_dir = (
        OUT / f"fold_{fold}"
    )

    fold_dir.mkdir(
        parents=True,
        exist_ok=True,
    )


    train.to_json(
        fold_dir / "train.json",
        orient="records",
        indent=2,
    )

    val.to_json(
        fold_dir / "val.json",
        orient="records",
        indent=2,
    )


    train.to_csv(
        fold_dir / "train.csv",
        index=False,
    )

    val.to_csv(
        fold_dir / "val.csv",
        index=False,
    )


    info = {
        "train":
            int(len(train)),

        "val":
            int(len(val)),

        "train_families":
            int(
                train["base_family"]
                .nunique()
            ),

        "val_families":
            int(
                val["base_family"]
                .nunique()
            ),

        "train_counts": {
            str(k): int(v)
            for k, v
            in train[
                "fusion_benefit"
            ]
            .value_counts()
            .to_dict()
            .items()
        },

        "val_counts": {
            str(k): int(v)
            for k, v
            in val[
                "fusion_benefit"
            ]
            .value_counts()
            .to_dict()
            .items()
        },

        "family_overlap":
            0,

        "mlir_hash_overlap":
            0,
    }


    metadata[
        "folds"
    ][str(fold)] = info


    print(
        "\n" + "=" * 72
    )

    print(
        f"FOLD {fold}"
    )

    print("=" * 72)

    print(
        "Train:",
        len(train),
        "| families:",
        train[
            "base_family"
        ].nunique(),
    )

    print(
        train[
            "fusion_benefit"
        ].value_counts()
    )

    print()

    print(
        "Validation:",
        len(val),
        "| families:",
        val[
            "base_family"
        ].nunique(),
    )

    print(
        val[
            "fusion_benefit"
        ].value_counts()
    )


with (
    OUT / "metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print("\nSaved:", OUT)
