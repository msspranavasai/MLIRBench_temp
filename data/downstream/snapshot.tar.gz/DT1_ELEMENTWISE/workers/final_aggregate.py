import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from final_common import (
    metrics_dict,
)


BASE = (
    ROOT
    / "outputs"
    / "final_cv"
)


methods = {
    "Zero-shot":
        (
            BASE
            / "zero"
        ),

    "3-shot seed 42":
        (
            BASE
            / "three_shot_seed_42"
        ),

    "3-shot seed 123":
        (
            BASE
            / "three_shot_seed_123"
        ),

    "SFT":
        (
            BASE
            / "sft"
        ),
}


summary_rows = []

pooled_results = {}


for name, directory in (
    methods.items()
):

    frames = []
    fold_metrics = []


    for fold in range(5):

        if name == "SFT":

            pred_path = (
                directory
                / f"fold_{fold}"
                / "val_predictions.csv"
            )

            metric_path = (
                directory
                / f"fold_{fold}"
                / "val_metrics.json"
            )

        else:

            pred_path = (
                directory
                / f"fold_{fold}_val_predictions.csv"
            )

            metric_path = (
                directory
                / f"fold_{fold}_val_metrics.json"
            )


        if (
            not pred_path.exists()
            or not metric_path.exists()
        ):
            raise RuntimeError(
                f"Missing outputs for "
                f"{name} fold {fold}"
            )


        df = pd.read_csv(
            pred_path
        )

        df["cv_fold"] = fold

        frames.append(
            df
        )


        with metric_path.open() as f:

            fold_metrics.append(
                json.load(f)
            )


    pooled = pd.concat(
        frames,
        ignore_index=True,
    )


    if len(pooled) != 693:

        raise RuntimeError(
            f"{name}: expected 693 "
            f"held-out predictions, "
            f"got {len(pooled)}"
        )


    if (
        pooled[
            "dt1_id"
        ].nunique()
        != 693
    ):

        raise RuntimeError(
            f"{name}: expected "
            "693 unique programs"
        )


    pooled_metric = metrics_dict(
        pooled[
            "fusion_benefit"
        ],
        pooled[
            "prediction"
        ],
    )


    pooled_results[
        name
    ] = pooled_metric


    row = {
        "method":
            name,

        "pooled_accuracy":
            pooled_metric[
                "accuracy"
            ],

        "pooled_balanced_accuracy":
            pooled_metric[
                "balanced_accuracy"
            ],

        "pooled_macro_f1":
            pooled_metric[
                "macro_f1"
            ],

        "pooled_ordinal_mae":
            pooled_metric[
                "ordinal_mae"
            ],

        "pooled_severe_error_rate":
            pooled_metric[
                "severe_error_rate"
            ],
    }


    for key in [
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "ordinal_mae",
        "severe_error_rate",
    ]:

        vals = [
            x[key]
            for x
            in fold_metrics
        ]

        row[
            f"fold_{key}_mean"
        ] = float(
            np.mean(vals)
        )

        row[
            f"fold_{key}_std"
        ] = float(
            np.std(
                vals,
                ddof=1,
            )
        )


    summary_rows.append(
        row
    )


    pooled.to_csv(
        BASE
        / (
            name.lower()
            .replace(
                " ",
                "_",
            )
            .replace(
                "-",
                "",
            )
            + "_pooled_predictions.csv"
        ),
        index=False,
    )


summary = pd.DataFrame(
    summary_rows
)


print("=" * 100)
print(
    "FINAL ELEMENTWISE FUSION CV RESULTS"
)
print("=" * 100)

print(
    summary[
        [
            "method",
            "pooled_accuracy",
            "pooled_balanced_accuracy",
            "pooled_macro_f1",
            "pooled_ordinal_mae",
            "fold_macro_f1_mean",
            "fold_macro_f1_std",
        ]
    ].to_string(
        index=False
    )
)


print(
    "\nPER-CLASS POOLED F1"
)

for method, metrics in (
    pooled_results.items()
):

    print(
        method,
        metrics[
            "per_class_f1"
        ],
    )


summary.to_csv(
    BASE
    / "final_summary.csv",
    index=False,
)


with (
    BASE
    / "pooled_metrics.json"
).open("w") as f:

    json.dump(
        pooled_results,
        f,
        indent=2,
    )


print("\nSaved:")
print(
    BASE
    / "final_summary.csv"
)

print(
    BASE
    / "pooled_metrics.json"
)
