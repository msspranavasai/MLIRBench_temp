import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

SOURCE = Path(
    "/home/pranava7/mlirbench/"
    "dt-2-all-dataset/data/dt2_all_dataset_source.json"
)

PROGRAMS = ROOT / "programs"
DATA = ROOT / "data"

PROGRAMS.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)


def family_from_program_id(program_id):
    s = str(program_id)

    m = re.search(
        r"(seed\d+)_linalg_(prog\d+)",
        s,
    )

    if not m:
        return None

    return f"{m.group(1)}_{m.group(2)}"


def clean_mlir(text):
    return str(text).strip()


def sha(text):
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


with SOURCE.open() as f:
    rows = json.load(f)


records = []

excluded = []


for row in rows:

    if (
        str(row.get("dialect", "")).lower()
        != "linalg"
    ):
        continue

    mlir = clean_mlir(
        row.get("mutated_mlir", "")
    )

    if mlir in {
        "",
        "GENERATION_FAILED",
    }:
        excluded.append(row)
        continue

    records.append(
        {
            **row,
            "base_family":
                family_from_program_id(
                    row["program_id"]
                ),
            "mlir_hash":
                sha(mlir),
        }
    )


df = pd.DataFrame(records)

print("=" * 72)
print("ELEMENTWISE CORPUS")
print("=" * 72)

print("Usable rows:", len(df))
print(
    "Families:",
    df["base_family"].nunique(),
)

print("\nSemantic labels:")
print(
    df["label"].value_counts()
)

print("\nLevels:")
print(
    df["level"].value_counts()
    .sort_index()
)


# ============================================================
# Deduplicate exact MLIR.
# ============================================================

unique_rows = []

for index, (
    mlir_hash,
    group,
) in enumerate(
    df.groupby(
        "mlir_hash",
        sort=True,
    )
):

    representative = (
        group.iloc[0]
    )

    dt1_id = (
        f"elt_{index:04d}"
    )

    mlir = clean_mlir(
        representative[
            "mutated_mlir"
        ]
    )

    path = (
        PROGRAMS
        / f"{dt1_id}.mlir"
    )

    path.write_text(
        mlir + "\n"
    )


    unique_rows.append(
        {
            "dt1_id":
                dt1_id,

            "mlir_hash":
                mlir_hash,

            "mlir_path":
                str(path),

            "row_count":
                len(group),

            "family_count":
                group[
                    "base_family"
                ].nunique(),

            "families":
                ",".join(
                    sorted(
                        group[
                            "base_family"
                        ]
                        .dropna()
                        .astype(str)
                        .unique()
                    )
                ),

            "semantic_labels":
                ",".join(
                    sorted(
                        group[
                            "label"
                        ]
                        .astype(str)
                        .unique()
                    )
                ),

            "representative_label":
                str(
                    representative[
                        "label"
                    ]
                ),

            "representative_level":
                int(
                    representative[
                        "level"
                    ]
                ),

            "representative_program_id":
                str(
                    representative[
                        "program_id"
                    ]
                ),

            "base_family":
                str(
                    representative[
                        "base_family"
                    ]
                ),
        }
    )


unique_df = pd.DataFrame(
    unique_rows
)


df.to_csv(
    DATA / "corpus_rows.csv",
    index=False,
)

unique_df.to_csv(
    DATA / "unique_programs.csv",
    index=False,
)

pd.DataFrame(
    excluded
).to_csv(
    DATA / "excluded_rows.csv",
    index=False,
)


metadata = {
    "source_total":
        len(rows),

    "usable_linalg_rows":
        len(df),

    "unique_programs":
        len(unique_df),

    "families":
        int(
            df[
                "base_family"
            ].nunique()
        ),

    "excluded":
        len(excluded),

    "semantic_labels":
        {
            str(k): int(v)
            for k, v
            in df[
                "label"
            ]
            .value_counts()
            .to_dict()
            .items()
        },
}


with (
    DATA
    / "corpus_metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print("\nUnique programs:", len(unique_df))

print(
    "Program files:",
    len(
        list(
            PROGRAMS.glob(
                "*.mlir"
            )
        )
    ),
)

print("\nSaved:")
print(
    DATA / "unique_programs.csv"
)
print(
    DATA / "corpus_metadata.json"
)
