import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
)


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

FOLDS = ROOT / "data" / "folds"

MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"

CLASSES = [
    "LOW",
    "MEDIUM",
    "HIGH",
]

CLASS_TO_CODE = {
    "LOW": "A",
    "MEDIUM": "B",
    "HIGH": "C",
}

CODE_TO_CLASS = {
    "A": "LOW",
    "B": "MEDIUM",
    "C": "HIGH",
}

ORDINAL = {
    "LOW": 0,
    "MEDIUM": 1,
    "HIGH": 2,
}


def load_fold(fold, split):
    with (
        FOLDS
        / f"fold_{fold}"
        / f"{split}.json"
    ).open() as f:
        return pd.DataFrame(
            json.load(f)
        )


def count(text, pattern):
    return len(
        re.findall(
            pattern,
            str(text),
        )
    )


def static_features(mlir):
    text = str(mlir)

    return {
        "characters":
            len(text),

        "lines":
            len(text.splitlines()),

        "linalg_ops":
            count(
                text,
                r"\blinalg\.[A-Za-z0-9_]+",
            ),

        "linalg_generic":
            count(
                text,
                r"\blinalg\.generic\b",
            ),

        "linalg_fill":
            count(
                text,
                r"\blinalg\.fill\b",
            ),

        "linalg_matmul":
            count(
                text,
                r"\blinalg\.(?:matmul|batch_matmul)\b",
            ),

        "linalg_yield":
            count(
                text,
                r"\blinalg\.yield\b",
            ),

        "arith_ops":
            count(
                text,
                r"\barith\.[A-Za-z0-9_]+",
            ),

        "tensor_ops":
            count(
                text,
                r"\btensor\.[A-Za-z0-9_]+",
            ),

        "scf_ops":
            count(
                text,
                r"\bscf\.[A-Za-z0-9_]+",
            ),

        "math_ops":
            count(
                text,
                r"\bmath\.[A-Za-z0-9_]+",
            ),

        "extract_slice":
            count(
                text,
                r"\btensor\.extract_slice\b",
            ),

        "insert_slice":
            count(
                text,
                r"\btensor\.insert_slice\b",
            ),

        "parallel_iterators":
            count(
                text,
                r'"parallel"',
            ),

        "reduction_iterators":
            count(
                text,
                r'"reduction"',
            ),

        "f32_tokens":
            count(
                text,
                r"\bf32\b",
            ),

        "f64_tokens":
            count(
                text,
                r"\bf64\b",
            ),

        "i1_tokens":
            count(
                text,
                r"\bi1\b",
            ),

        "i32_tokens":
            count(
                text,
                r"\bi32\b",
            ),

        "i64_tokens":
            count(
                text,
                r"\bi64\b",
            ),
    }


def feature_text(mlir):
    features = static_features(
        mlir
    )

    return "\n".join(
        f"- {name}: {value}"
        for name, value
        in features.items()
    )


def task_text(row):
    mlir = str(
        row["mlir"]
    )

    return (
        "You are an MLIR compiler optimization planner.\n\n"

        "Estimate the structural benefit of applying the MLIR "
        "elementwise producer-consumer fusion pass:\n"
        "linalg-fuse-elementwise-ops\n\n"

        "Benefit is measured by the number of Linalg operations "
        "eliminated after applying the real compiler pass.\n\n"

        "Classes:\n"
        "LOW: 0 to 6 Linalg operations removed\n"
        "MEDIUM: 7 to 11 Linalg operations removed\n"
        "HIGH: 12 or more Linalg operations removed\n\n"

        "Use exactly one output code:\n"
        "A = LOW\n"
        "B = MEDIUM\n"
        "C = HIGH\n\n"

        "Use only the static program structure below. "
        "Do not assume that fusion is always highly beneficial.\n\n"

        "Static MLIR features:\n"
        f"{feature_text(mlir)}\n\n"

        "MLIR program:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```\n\n"

        "Return exactly one code: A, B, or C."
    )


def zero_shot_prompt(
    tokenizer,
    row,
):
    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content":
                    task_text(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


def few_shot_prompt(
    tokenizer,
    row,
    examples,
):
    messages = []

    for ex in examples:
        messages.append(
            {
                "role": "user",
                "content":
                    task_text(ex),
            }
        )

        messages.append(
            {
                "role": "assistant",
                "content":
                    CLASS_TO_CODE[
                        str(
                            ex[
                                "fusion_benefit"
                            ]
                        )
                    ],
            }
        )

    messages.append(
        {
            "role": "user",
            "content":
                task_text(row),
        }
    )

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def choose_three_shot(
    train_df,
    seed,
):
    examples = []

    for index, label in enumerate(
        CLASSES
    ):
        subset = train_df[
            train_df[
                "fusion_benefit"
            ] == label
        ].copy()

        if subset.empty:
            raise RuntimeError(
                f"No training examples "
                f"for class {label}"
            )

        subset[
            "_chars"
        ] = (
            subset["mlir"]
            .astype(str)
            .str.len()
        )

        # Short examples protect context length.
        pool = (
            subset
            .sort_values(
                "_chars"
            )
            .head(
                min(
                    20,
                    len(subset),
                )
            )
        )

        chosen = pool.sample(
            n=1,
            random_state=(
                seed
                + index * 1000
            ),
        ).iloc[0]

        examples.append(
            chosen
        )

    return examples


def resolve_code_token_ids(
    tokenizer,
    sample_prompt,
):
    prompt_ids = tokenizer(
        sample_prompt,
        add_special_tokens=False,
    )["input_ids"]

    result = {}

    for code in [
        "A",
        "B",
        "C",
    ]:
        full_ids = tokenizer(
            sample_prompt + code,
            add_special_tokens=False,
        )["input_ids"]

        if (
            full_ids[
                :len(prompt_ids)
            ]
            != prompt_ids
        ):
            raise RuntimeError(
                "Prompt prefix mismatch "
                f"for code {code}"
            )

        continuation = full_ids[
            len(prompt_ids):
        ]

        if len(continuation) != 1:
            raise RuntimeError(
                f"{code} is not one token "
                f"in context: {continuation}"
            )

        result[
            code
        ] = continuation[0]

    return result


def metrics_dict(
    y_true,
    y_pred,
):
    y_true = list(y_true)
    y_pred = list(y_pred)

    accuracy = accuracy_score(
        y_true,
        y_pred,
    )

    balanced_accuracy = (
        balanced_accuracy_score(
            y_true,
            y_pred,
        )
    )

    macro_f1 = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average="macro",
        zero_division=0,
    )

    weighted_f1 = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average="weighted",
        zero_division=0,
    )

    per_class = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average=None,
        zero_division=0,
    )

    distances = []

    for gold, pred in zip(
        y_true,
        y_pred,
    ):
        distances.append(
            abs(
                ORDINAL[gold]
                - ORDINAL[pred]
            )
        )

    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=CLASSES,
    )

    return {
        "n":
            int(len(y_true)),

        "accuracy":
            float(accuracy),

        "balanced_accuracy":
            float(
                balanced_accuracy
            ),

        "macro_f1":
            float(macro_f1),

        "weighted_f1":
            float(weighted_f1),

        "per_class_f1": {
            label:
                float(score)

            for label, score
            in zip(
                CLASSES,
                per_class,
            )
        },

        "ordinal_mae":
            float(
                np.mean(
                    distances
                )
            ),

        "severe_error_rate":
            float(
                np.mean(
                    [
                        d == 2
                        for d
                        in distances
                    ]
                )
            ),

        "within_one_class":
            float(
                np.mean(
                    [
                        d <= 1
                        for d
                        in distances
                    ]
                )
            ),

        "confusion_matrix_labels":
            CLASSES,

        "confusion_matrix":
            cm.tolist(),
    }
