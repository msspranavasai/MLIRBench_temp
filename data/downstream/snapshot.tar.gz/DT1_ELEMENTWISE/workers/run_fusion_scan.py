import hashlib
import json
import re
import subprocess
import time

from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)

from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

DATA = ROOT / "data"
OUT = ROOT / "outputs"
CODEGEN = ROOT / "codegen" / "fusion_scan"

IREE_OPT = (
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/"
    ".venv/bin/iree-opt"
)

WORKERS = 16
TIMEOUT = 120


CODEGEN.mkdir(
    parents=True,
    exist_ok=True,
)

OUT.mkdir(
    parents=True,
    exist_ok=True,
)


programs = pd.read_csv(
    DATA / "unique_programs.csv"
)


def sha(text):
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def count_pattern(
    text,
    pattern,
):
    return len(
        re.findall(
            pattern,
            text,
        )
    )


def stats(text):

    return {
        "chars":
            len(text),

        "lines":
            len(
                text.splitlines()
            ),

        "linalg_ops":
            count_pattern(
                text,
                r"\blinalg\.[A-Za-z0-9_]+",
            ),

        "linalg_generic":
            count_pattern(
                text,
                r"\blinalg\.generic\b",
            ),

        "tensor_ops":
            count_pattern(
                text,
                r"\btensor\.[A-Za-z0-9_]+",
            ),

        "arith_ops":
            count_pattern(
                text,
                r"\barith\.[A-Za-z0-9_]+",
            ),

        "extract_slice":
            count_pattern(
                text,
                r"\btensor\.extract_slice\b",
            ),

        "insert_slice":
            count_pattern(
                text,
                r"\btensor\.insert_slice\b",
            ),
    }


def run_command(cmd):

    start = time.time()

    try:

        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=TIMEOUT,
        )

        return {
            "returncode":
                p.returncode,

            "stdout":
                p.stdout,

            "stderr":
                p.stderr,

            "seconds":
                time.time() - start,

            "timeout":
                False,
        }

    except subprocess.TimeoutExpired as e:

        return {
            "returncode":
                -999,

            "stdout":
                e.stdout or "",

            "stderr":
                e.stderr or "",

            "seconds":
                time.time() - start,

            "timeout":
                True,
        }


def process(row):

    dt1_id = str(
        row["dt1_id"]
    )

    mlir_path = Path(
        row["mlir_path"]
    )


    # --------------------------------------------------------
    # Baseline: parse + print only.
    # --------------------------------------------------------

    baseline_cmd = [
        IREE_OPT,
        str(mlir_path),
    ]


    baseline = run_command(
        baseline_cmd
    )


    result = {
        "dt1_id":
            dt1_id,

        "mlir_hash":
            row["mlir_hash"],

        "base_family":
            row["base_family"],

        "semantic_label":
            row[
                "representative_label"
            ],

        "level":
            row[
                "representative_level"
            ],

        "program_id":
            row[
                "representative_program_id"
            ],

        "baseline_success":
            baseline[
                "returncode"
            ] == 0,

        "baseline_returncode":
            baseline[
                "returncode"
            ],

        "baseline_seconds":
            baseline[
                "seconds"
            ],

        "baseline_stderr":
            baseline[
                "stderr"
            ][-4000:],

        "fusion_success":
            False,

        "fusion_changed_ir":
            False,
    }


    if baseline[
        "returncode"
    ] != 0:

        return result


    baseline_text = (
        baseline["stdout"]
    )


    # --------------------------------------------------------
    # Fusion pass
    # --------------------------------------------------------

    fusion_cmd = [
        IREE_OPT,
        str(mlir_path),
        "--linalg-fuse-elementwise-ops",
    ]


    fusion = run_command(
        fusion_cmd
    )


    result[
        "fusion_success"
    ] = (
        fusion[
            "returncode"
        ] == 0
    )

    result[
        "fusion_returncode"
    ] = fusion[
        "returncode"
    ]

    result[
        "fusion_seconds"
    ] = fusion[
        "seconds"
    ]

    result[
        "fusion_stderr"
    ] = fusion[
        "stderr"
    ][-4000:]


    if fusion[
        "returncode"
    ] != 0:

        return result


    fused_text = (
        fusion["stdout"]
    )


    baseline_stats = stats(
        baseline_text
    )

    fused_stats = stats(
        fused_text
    )


    result[
        "baseline_hash"
    ] = sha(
        baseline_text
    )

    result[
        "fused_hash"
    ] = sha(
        fused_text
    )

    result[
        "fusion_changed_ir"
    ] = (
        result[
            "baseline_hash"
        ]
        != result[
            "fused_hash"
        ]
    )


    for key, value in (
        baseline_stats.items()
    ):

        result[
            f"{key}_before"
        ] = value


    for key, value in (
        fused_stats.items()
    ):

        result[
            f"{key}_after"
        ] = value


    for key in [
        "chars",
        "lines",
        "linalg_ops",
        "linalg_generic",
        "tensor_ops",
        "arith_ops",
        "extract_slice",
        "insert_slice",
    ]:

        result[
            f"{key}_delta"
        ] = (
            result[
                f"{key}_after"
            ]
            - result[
                f"{key}_before"
            ]
        )


    # Save IR only for changed programs.
    if result[
        "fusion_changed_ir"
    ]:

        program_dir = (
            CODEGEN
            / dt1_id
        )

        program_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        (
            program_dir
            / "baseline.mlir"
        ).write_text(
            baseline_text
        )

        (
            program_dir
            / "fused.mlir"
        ).write_text(
            fused_text
        )


    return result


print("=" * 80)
print("ELEMENTWISE FUSION CORPUS SCAN")
print("=" * 80)

print(
    "Programs:",
    len(programs),
)

print(
    "Workers:",
    WORKERS,
)


results = []


with ThreadPoolExecutor(
    max_workers=WORKERS
) as executor:

    futures = {
        executor.submit(
            process,
            row,
        ): row["dt1_id"]

        for _, row
        in programs.iterrows()
    }


    completed = 0

    for future in as_completed(
        futures
    ):

        result = future.result()

        results.append(
            result
        )

        completed += 1

        if (
            completed % 50 == 0
            or completed
            == len(programs)
        ):

            print(
                f"{completed}/"
                f"{len(programs)}"
            )


df = pd.DataFrame(
    results
).sort_values(
    "dt1_id"
)


path = (
    OUT
    / "fusion_scan_results.csv"
)

df.to_csv(
    path,
    index=False,
)


baseline_ok = df[
    "baseline_success"
] == True

fusion_ok = df[
    "fusion_success"
] == True

changed = df[
    "fusion_changed_ir"
] == True


summary = {
    "programs":
        int(len(df)),

    "baseline_success":
        int(
            baseline_ok.sum()
        ),

    "fusion_success":
        int(
            fusion_ok.sum()
        ),

    "fusion_changed_ir":
        int(
            changed.sum()
        ),

    "unchanged":
        int(
            (
                fusion_ok
                & ~changed
            ).sum()
        ),

    "baseline_failures":
        int(
            (~baseline_ok).sum()
        ),

    "fusion_failures_after_baseline":
        int(
            (
                baseline_ok
                & ~fusion_ok
            ).sum()
        ),
}


with (
    OUT
    / "fusion_scan_summary.json"
).open("w") as f:

    json.dump(
        summary,
        f,
        indent=2,
    )


print("\n" + "=" * 80)
print("SUMMARY")
print("=" * 80)

print(
    json.dumps(
        summary,
        indent=2,
    )
)


if changed.any():

    changed_df = df[
        changed
    ]

    print(
        "\nChanged programs by semantic label:"
    )

    print(
        changed_df[
            "semantic_label"
        ].value_counts()
    )


    print(
        "\nChanged programs by level:"
    )

    print(
        changed_df[
            "level"
        ].value_counts()
        .sort_index()
    )


    print(
        "\nLinalg-op delta:"
    )

    print(
        changed_df[
            "linalg_ops_delta"
        ].describe()
    )


    print(
        "\nTensor-op delta:"
    )

    print(
        changed_df[
            "tensor_ops_delta"
        ].describe()
    )


print("\nSaved:")
print(path)
