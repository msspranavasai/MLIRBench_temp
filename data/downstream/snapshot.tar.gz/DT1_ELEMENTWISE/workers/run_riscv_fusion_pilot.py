import hashlib
import json
import re
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

DATA = ROOT / "data"
OUT = ROOT / "outputs"
PILOT = ROOT / "pilot" / "riscv_fusion"
CODEGEN = ROOT / "codegen" / "riscv_fusion_pilot"

IREE_OPT = (
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/.venv/bin/iree-opt"
)

IREE_COMPILE = (
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/.venv/bin/iree-compile"
)

WORKERS = 8
TIMEOUT = 180

PILOT.mkdir(parents=True, exist_ok=True)
CODEGEN.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)


scan = pd.read_csv(
    OUT / "fusion_scan_results.csv"
)

programs = pd.read_csv(
    DATA / "unique_programs.csv"
)

df = scan.merge(
    programs[
        [
            "dt1_id",
            "mlir_path",
        ]
    ],
    on="dt1_id",
    how="left",
    validate="one_to_one",
)

valid = df[
    df["fusion_success"] == True
].copy()

changed = valid[
    valid["fusion_changed_ir"] == True
].copy()

unchanged = valid[
    valid["fusion_changed_ir"] == False
].copy()


# ============================================================
# Deterministic pilot:
#   20 strongest structural reductions
#   20 random other changed
#   10 random unchanged
# ============================================================

top = (
    changed
    .sort_values("linalg_ops_delta")
    .head(20)
)

remaining_changed = changed[
    ~changed["dt1_id"].isin(top["dt1_id"])
]

random_changed = remaining_changed.sample(
    n=min(20, len(remaining_changed)),
    random_state=42,
)

random_unchanged = unchanged.sample(
    n=min(10, len(unchanged)),
    random_state=42,
)

pilot_df = pd.concat(
    [
        top,
        random_changed,
        random_unchanged,
    ],
    ignore_index=True,
).drop_duplicates("dt1_id")


print("=" * 80)
print("RISC-V ELEMENTWISE-FUSION PILOT")
print("=" * 80)

print("Programs:", len(pilot_df))
print(
    "Changed:",
    int(pilot_df["fusion_changed_ir"].sum()),
)
print(
    "Unchanged:",
    int((~pilot_df["fusion_changed_ir"]).sum()),
)


def run(cmd):
    start = time.time()

    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=TIMEOUT,
        )

        return {
            "success": p.returncode == 0,
            "returncode": p.returncode,
            "stdout": p.stdout,
            "stderr": p.stderr,
            "seconds": time.time() - start,
        }

    except subprocess.TimeoutExpired as e:
        return {
            "success": False,
            "returncode": -999,
            "stdout": e.stdout or "",
            "stderr": e.stderr or "",
            "seconds": time.time() - start,
        }


def canonicalize(input_path, fused=False):

    cmd = [
        IREE_OPT,
        str(input_path),
    ]

    if fused:
        cmd.append(
            "--linalg-fuse-elementwise-ops"
        )

    return run(cmd)


def count_asm_instructions(text):

    count = 0

    for raw in text.splitlines():

        line = raw.strip()

        if not line:
            continue

        if line.startswith((
            ".",
            "#",
            "//",
            ";",
        )):
            continue

        if line.endswith(":"):
            continue

        # Remove trailing comments.
        line = re.split(
            r"\s+#|\s+//",
            line,
            maxsplit=1,
        )[0].strip()

        if not line:
            continue

        # Assembly instruction normally starts with mnemonic.
        if re.match(
            r"^[A-Za-z][A-Za-z0-9_.]*\s",
            line,
        ):
            count += 1

    return count


def assembly_info(directory):

    files = sorted(
        directory.rglob("*.s")
    )

    combined = []

    instructions = 0

    for path in files:
        text = path.read_text(
            errors="replace"
        )

        combined.append(text)

        instructions += (
            count_asm_instructions(
                text
            )
        )

    blob = "\n".join(combined)

    return {
        "assembly_files":
            len(files),

        "instruction_count":
            instructions,

        "assembly_hash":
            hashlib.sha256(
                blob.encode()
            ).hexdigest()
            if files
            else None,

        "assembly_bytes":
            len(
                blob.encode()
            ),
    }


def compile_riscv(
    mlir_path,
    out_dir,
):

    if out_dir.exists():
        shutil.rmtree(
            out_dir
        )

    out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    vmfb = (
        out_dir
        / "program.vmfb"
    )

    cmd = [
        IREE_COMPILE,
        str(mlir_path),

        "-o",
        str(vmfb),

        "--iree-hal-target-device=local",

        "--iree-hal-local-target-device-backends=llvm-cpu",

        "--iree-llvmcpu-target-triple=riscv64",

        "--iree-llvmcpu-target-abi=lp64d",

        "--iree-opt-level=O3",

        "--iree-llvmcpu-target-cpu-features="
        "+m,+a,+f,+d,+c,+zvl512b,+v",

        "--iree-hal-dump-executable-files-to="
        + str(out_dir),
    ]

    result = run(cmd)

    info = assembly_info(
        out_dir
    )

    result.update(info)

    result[
        "vmfb_exists"
    ] = vmfb.exists()

    result[
        "vmfb_bytes"
    ] = (
        vmfb.stat().st_size
        if vmfb.exists()
        else None
    )

    return result


def process(row):

    dt1_id = str(
        row["dt1_id"]
    )

    source = Path(
        row["mlir_path"]
    )

    work = (
        PILOT
        / dt1_id
    )

    work.mkdir(
        parents=True,
        exist_ok=True,
    )

    baseline_ir = (
        work
        / "baseline.mlir"
    )

    fused_ir = (
        work
        / "fused.mlir"
    )


    base_opt = canonicalize(
        source,
        fused=False,
    )

    fused_opt = canonicalize(
        source,
        fused=True,
    )


    record = {
        "dt1_id":
            dt1_id,

        "program_id":
            row["program_id"],

        "base_family":
            row["base_family"],

        "semantic_label":
            row["semantic_label"],

        "level":
            row["level"],

        "fusion_changed_ir":
            bool(
                row[
                    "fusion_changed_ir"
                ]
            ),

        "linalg_ops_before":
            row.get(
                "linalg_ops_before"
            ),

        "linalg_ops_after":
            row.get(
                "linalg_ops_after"
            ),

        "linalg_ops_delta":
            row.get(
                "linalg_ops_delta"
            ),

        "canonical_baseline_success":
            base_opt["success"],

        "canonical_fusion_success":
            fused_opt["success"],
    }


    if (
        not base_opt["success"]
        or not fused_opt["success"]
    ):
        return record


    baseline_ir.write_text(
        base_opt["stdout"]
    )

    fused_ir.write_text(
        fused_opt["stdout"]
    )


    baseline_dir = (
        CODEGEN
        / dt1_id
        / "baseline"
    )

    fused_dir = (
        CODEGEN
        / dt1_id
        / "fused"
    )


    base_compile = compile_riscv(
        baseline_ir,
        baseline_dir,
    )

    fused_compile = compile_riscv(
        fused_ir,
        fused_dir,
    )


    record.update(
        {
            "baseline_compile_success":
                base_compile[
                    "success"
                ],

            "fused_compile_success":
                fused_compile[
                    "success"
                ],

            "baseline_compile_seconds":
                base_compile[
                    "seconds"
                ],

            "fused_compile_seconds":
                fused_compile[
                    "seconds"
                ],

            "baseline_instruction_count":
                base_compile[
                    "instruction_count"
                ],

            "fused_instruction_count":
                fused_compile[
                    "instruction_count"
                ],

            "baseline_assembly_bytes":
                base_compile[
                    "assembly_bytes"
                ],

            "fused_assembly_bytes":
                fused_compile[
                    "assembly_bytes"
                ],

            "baseline_vmfb_bytes":
                base_compile[
                    "vmfb_bytes"
                ],

            "fused_vmfb_bytes":
                fused_compile[
                    "vmfb_bytes"
                ],

            "baseline_assembly_hash":
                base_compile[
                    "assembly_hash"
                ],

            "fused_assembly_hash":
                fused_compile[
                    "assembly_hash"
                ],

            "assembly_identical":
                (
                    base_compile[
                        "assembly_hash"
                    ]
                    == fused_compile[
                        "assembly_hash"
                    ]
                )
                if (
                    base_compile[
                        "assembly_hash"
                    ]
                    and fused_compile[
                        "assembly_hash"
                    ]
                )
                else None,
        }
    )


    if (
        base_compile["success"]
        and fused_compile["success"]
    ):

        before = (
            base_compile[
                "instruction_count"
            ]
        )

        after = (
            fused_compile[
                "instruction_count"
            ]
        )


        record[
            "instruction_delta"
        ] = (
            after - before
        )


        record[
            "instruction_reduction_pct"
        ] = (
            (
                before - after
            )
            / before
            * 100.0
            if before
            else None
        )


        bbytes = (
            base_compile[
                "assembly_bytes"
            ]
        )

        fbytes = (
            fused_compile[
                "assembly_bytes"
            ]
        )


        record[
            "assembly_byte_reduction_pct"
        ] = (
            (
                bbytes - fbytes
            )
            / bbytes
            * 100.0
            if bbytes
            else None
        )


    return record


results = []


with ThreadPoolExecutor(
    max_workers=WORKERS
) as executor:

    futures = {
        executor.submit(
            process,
            row,
        ): row["dt1_id"]

        for _, row
        in pilot_df.iterrows()
    }


    completed = 0

    for future in as_completed(
        futures
    ):

        try:
            result = future.result()

        except Exception as e:
            result = {
                "dt1_id":
                    futures[
                        future
                    ],

                "worker_exception":
                    repr(e),
            }

        results.append(
            result
        )

        completed += 1

        print(
            f"{completed}/"
            f"{len(pilot_df)} "
            f"{result.get('dt1_id')}"
        )


result_df = pd.DataFrame(
    results
).sort_values(
    "dt1_id"
)


result_path = (
    OUT
    / "riscv_fusion_pilot.csv"
)

result_df.to_csv(
    result_path,
    index=False,
)


both = result_df[
    (
        result_df[
            "baseline_compile_success"
        ] == True
    )
    &
    (
        result_df[
            "fused_compile_success"
        ] == True
    )
].copy()


summary = {
    "pilot_programs":
        int(len(result_df)),

    "both_compile":
        int(len(both)),

    "assembly_identical":
        int(
            both[
                "assembly_identical"
            ].fillna(False).sum()
        ),

    "assembly_different":
        int(
            (
                both[
                    "assembly_identical"
                ] == False
            ).sum()
        ),
}


if len(both):

    summary[
        "instruction_reduction_mean_pct"
    ] = float(
        both[
            "instruction_reduction_pct"
        ].mean()
    )

    summary[
        "instruction_reduction_median_pct"
    ] = float(
        both[
            "instruction_reduction_pct"
        ].median()
    )

    summary[
        "instruction_reduction_min_pct"
    ] = float(
        both[
            "instruction_reduction_pct"
        ].min()
    )

    summary[
        "instruction_reduction_max_pct"
    ] = float(
        both[
            "instruction_reduction_pct"
        ].max()
    )

    summary[
        "fusion_backend_improves"
    ] = int(
        (
            both[
                "instruction_reduction_pct"
            ] > 0
        ).sum()
    )

    summary[
        "fusion_backend_ties"
    ] = int(
        (
            both[
                "instruction_reduction_pct"
            ] == 0
        ).sum()
    )

    summary[
        "fusion_backend_worsens"
    ] = int(
        (
            both[
                "instruction_reduction_pct"
            ] < 0
        ).sum()
    )


with (
    OUT
    / "riscv_fusion_pilot_summary.json"
).open("w") as f:

    json.dump(
        summary,
        f,
        indent=2,
    )


print("\n" + "=" * 80)
print("PILOT SUMMARY")
print("=" * 80)

print(
    json.dumps(
        summary,
        indent=2,
    )
)

print("\nSaved:")
print(result_path)
