import json
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
)


# ============================================================
# Paths
# ============================================================

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

OUTPUTS = ROOT / "outputs" / "final_cv"
FIGURES = ROOT / "figures" / "final_cv"

FIGURES.mkdir(
    parents=True,
    exist_ok=True,
)


CLASSES = [
    "LOW",
    "MEDIUM",
    "HIGH",
]


# ============================================================
# Helpers
# ============================================================

def metric_dict(y_true, y_pred):
    return {
        "n": len(y_true),

        "accuracy": accuracy_score(
            y_true,
            y_pred,
        ),

        "balanced_accuracy": balanced_accuracy_score(
            y_true,
            y_pred,
        ),

        "macro_f1": f1_score(
            y_true,
            y_pred,
            labels=CLASSES,
            average="macro",
            zero_division=0,
        ),

        "weighted_f1": f1_score(
            y_true,
            y_pred,
            labels=CLASSES,
            average="weighted",
            zero_division=0,
        ),

        "per_class_f1": {
            c: v
            for c, v in zip(
                CLASSES,
                f1_score(
                    y_true,
                    y_pred,
                    labels=CLASSES,
                    average=None,
                    zero_division=0,
                ),
            )
        },

        "confusion_matrix": confusion_matrix(
            y_true,
            y_pred,
            labels=CLASSES,
        ).tolist(),
    }


def find_prediction_csvs():
    """
    Search recursively for prediction CSV files produced by the
    final experiment.

    Expected columns somewhere in the CSV:
      fusion_benefit
      prediction

    The method and fold are inferred from either:
      - columns in the CSV
      - directory/file names
    """

    candidates = list(
        OUTPUTS.rglob("*.csv")
    )

    found = []

    for path in candidates:
        try:
            df = pd.read_csv(path)
        except Exception:
            continue

        columns = set(df.columns)

        if (
            "fusion_benefit" not in columns
            or "prediction" not in columns
        ):
            continue

        found.append(
            (path, df)
        )

    return found


def infer_fold(path, df):
    if "fold" in df.columns:
        vals = (
            df["fold"]
            .dropna()
            .unique()
        )

        if len(vals) == 1:
            return int(vals[0])

    text = str(path)

    patterns = [
        r"fold[_\-]?(\d+)",
        r"/(\d+)/",
    ]

    for pattern in patterns:
        m = re.search(
            pattern,
            text,
            flags=re.IGNORECASE,
        )

        if m:
            return int(
                m.group(1)
            )

    return None


def infer_method(path, df):
    if "method" in df.columns:
        vals = (
            df["method"]
            .dropna()
            .astype(str)
            .unique()
        )

        if len(vals) == 1:
            raw = vals[0].lower()

            if raw == "sft":
                return "SFT"

            if raw == "zero":
                return "Zero-shot"

            if "three" in raw and "42" in raw:
                return "3-shot (seed 42)"

            if "three" in raw and "123" in raw:
                return "3-shot (seed 123)"

    text = str(path).lower()

    if "sft" in text:
        return "SFT"

    if "three" in text and "42" in text:
        return "3-shot (seed 42)"

    if "three" in text and "123" in text:
        return "3-shot (seed 123)"

    if "zero" in text:
        return "Zero-shot"

    return None


def load_predictions():
    rows = []

    prediction_files = find_prediction_csvs()

    print("=" * 80)
    print("DISCOVERED PREDICTION FILES")
    print("=" * 80)

    for path, df in prediction_files:

        method = infer_method(
            path,
            df,
        )

        fold = infer_fold(
            path,
            df,
        )

        if method is None:
            print(
                "Skipping unknown method:",
                path,
            )
            continue

        if fold is None:
            print(
                "Skipping unknown fold:",
                path,
            )
            continue

        use = df.copy()

        use = use[
            use["fusion_benefit"].isin(
                CLASSES
            )
            &
            use["prediction"].isin(
                CLASSES
            )
        ].copy()

        use["method_name"] = method
        use["fold_id"] = fold
        use["source_file"] = str(path)

        rows.append(use)

        print(
            f"{method:22s} "
            f"fold={fold} "
            f"rows={len(use):3d} "
            f"{path}"
        )

    if not rows:
        raise RuntimeError(
            "No prediction CSVs were found under "
            f"{OUTPUTS}"
        )

    all_df = pd.concat(
        rows,
        ignore_index=True,
    )

    return all_df


# ============================================================
# Results tables
# ============================================================

def compute_results(all_df):
    pooled_rows = []
    fold_rows = []
    class_rows = []
    confusion = {}

    for method, df in all_df.groupby(
        "method_name"
    ):

        metrics = metric_dict(
            df["fusion_benefit"],
            df["prediction"],
        )

        pooled_rows.append({
            "method": method,
            "n": metrics["n"],
            "accuracy": metrics["accuracy"],
            "balanced_accuracy": metrics[
                "balanced_accuracy"
            ],
            "macro_f1": metrics["macro_f1"],
            "weighted_f1": metrics[
                "weighted_f1"
            ],
        })

        for cls in CLASSES:
            class_rows.append({
                "method": method,
                "class": cls,
                "f1": metrics[
                    "per_class_f1"
                ][cls],
            })

        confusion[method] = np.array(
            metrics["confusion_matrix"]
        )

        for fold, fold_df in df.groupby(
            "fold_id"
        ):
            fm = metric_dict(
                fold_df["fusion_benefit"],
                fold_df["prediction"],
            )

            fold_rows.append({
                "method": method,
                "fold": int(fold),
                "n": fm["n"],
                "accuracy": fm[
                    "accuracy"
                ],
                "balanced_accuracy": fm[
                    "balanced_accuracy"
                ],
                "macro_f1": fm[
                    "macro_f1"
                ],
                "weighted_f1": fm[
                    "weighted_f1"
                ],
            })

    pooled = pd.DataFrame(
        pooled_rows
    )

    folds = pd.DataFrame(
        fold_rows
    )

    per_class = pd.DataFrame(
        class_rows
    )

    return (
        pooled,
        folds,
        per_class,
        confusion,
    )


# ============================================================
# Plot helpers
# ============================================================

METHOD_ORDER = [
    "Zero-shot",
    "3-shot (seed 42)",
    "3-shot (seed 123)",
    "SFT",
]


def method_order_present(df):
    present = set(
        df["method"]
    )

    return [
        m
        for m in METHOD_ORDER
        if m in present
    ]


def save_figure(fig, stem):
    png = (
        FIGURES
        / f"{stem}.png"
    )

    pdf = (
        FIGURES
        / f"{stem}.pdf"
    )

    fig.savefig(
        png,
        dpi=300,
        bbox_inches="tight",
    )

    fig.savefig(
        pdf,
        bbox_inches="tight",
    )

    plt.close(fig)

    print("Saved:", png)
    print("Saved:", pdf)


# ============================================================
# Figure 1
# Overall comparison
# ============================================================

def plot_overall_metrics(pooled):
    methods = method_order_present(
        pooled
    )

    frame = (
        pooled
        .set_index("method")
        .loc[methods]
    )

    metrics = [
        (
            "accuracy",
            "Accuracy",
        ),
        (
            "balanced_accuracy",
            "Balanced Accuracy",
        ),
        (
            "macro_f1",
            "Macro-F1",
        ),
    ]

    x = np.arange(
        len(methods)
    )

    width = 0.24

    fig, ax = plt.subplots(
        figsize=(10, 5.5)
    )

    for i, (column, label) in enumerate(
        metrics
    ):
        values = frame[
            column
        ].to_numpy()

        positions = (
            x
            + (
                i
                - (
                    len(metrics) - 1
                ) / 2
            )
            * width
        )

        bars = ax.bar(
            positions,
            values,
            width,
            label=label,
        )

        for bar, value in zip(
            bars,
            values,
        ):
            ax.text(
                bar.get_x()
                + bar.get_width() / 2,
                value + 0.015,
                f"{value:.3f}",
                ha="center",
                va="bottom",
                fontsize=8,
                rotation=90,
            )

    ax.set_xticks(x)
    ax.set_xticklabels(
        methods
    )

    ax.set_ylim(
        0,
        1.0,
    )

    ax.set_ylabel(
        "Score"
    )

    ax.set_title(
        "Elementwise Fusion Benefit Prediction"
    )

    ax.legend(
        frameon=False
    )

    ax.grid(
        axis="y",
        alpha=0.25,
    )

    fig.tight_layout()

    save_figure(
        fig,
        "01_overall_method_comparison",
    )


# ============================================================
# Figure 2
# Fold-wise Macro-F1
# ============================================================

def plot_fold_macro_f1(folds):
    methods = method_order_present(
        folds
    )

    fig, ax = plt.subplots(
        figsize=(10, 5.5)
    )

    for method in methods:
        df = (
            folds[
                folds["method"]
                == method
            ]
            .sort_values("fold")
        )

        ax.plot(
            df["fold"],
            df["macro_f1"],
            marker="o",
            linewidth=2,
            label=method,
        )

    ax.set_xticks(
        sorted(
            folds["fold"]
            .unique()
        )
    )

    ax.set_ylim(
        0,
        1.0,
    )

    ax.set_xlabel(
        "Held-out family fold"
    )

    ax.set_ylabel(
        "Macro-F1"
    )

    ax.set_title(
        "Generalization Across Family-Disjoint Folds"
    )

    ax.grid(
        alpha=0.25,
    )

    ax.legend(
        frameon=False
    )

    fig.tight_layout()

    save_figure(
        fig,
        "02_macro_f1_by_fold",
    )


# ============================================================
# Figure 3
# SFT vs Zero by fold
# ============================================================

def plot_sft_vs_zero(folds):
    wanted = [
        x
        for x in [
            "Zero-shot",
            "SFT",
        ]
        if x in set(
            folds["method"]
        )
    ]

    if len(wanted) != 2:
        print(
            "Skipping SFT vs Zero figure: "
            "both methods not present."
        )
        return

    pivot = folds.pivot(
        index="fold",
        columns="method",
        values="macro_f1",
    )

    pivot = pivot[
        wanted
    ]

    x = np.arange(
        len(pivot.index)
    )

    width = 0.36

    fig, ax = plt.subplots(
        figsize=(9, 5)
    )

    for i, method in enumerate(
        wanted
    ):
        values = pivot[
            method
        ].to_numpy()

        ax.bar(
            x
            + (
                i - 0.5
            ) * width,
            values,
            width,
            label=method,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(
        [
            f"Fold {i}"
            for i
            in pivot.index
        ]
    )

    ax.set_ylim(
        0,
        1.0,
    )

    ax.set_ylabel(
        "Macro-F1"
    )

    ax.set_title(
        "Effect of Benchmark Supervision"
    )

    ax.legend(
        frameon=False
    )

    ax.grid(
        axis="y",
        alpha=0.25,
    )

    fig.tight_layout()

    save_figure(
        fig,
        "03_sft_vs_zero_by_fold",
    )


# ============================================================
# Figure 4
# Per-class F1
# ============================================================

def plot_per_class_f1(per_class):
    methods = method_order_present(
        per_class
    )

    pivot = (
        per_class
        .pivot(
            index="class",
            columns="method",
            values="f1",
        )
        .reindex(
            CLASSES
        )
    )

    pivot = pivot[
        [
            m
            for m in methods
            if m in pivot.columns
        ]
    ]

    x = np.arange(
        len(CLASSES)
    )

    n_methods = len(
        pivot.columns
    )

    width = (
        0.8 / n_methods
    )

    fig, ax = plt.subplots(
        figsize=(10, 5.5)
    )

    for i, method in enumerate(
        pivot.columns
    ):
        values = pivot[
            method
        ].to_numpy()

        pos = (
            x
            - 0.4
            + width / 2
            + i * width
        )

        ax.bar(
            pos,
            values,
            width,
            label=method,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(
        CLASSES
    )

    ax.set_ylim(
        0,
        1.0,
    )

    ax.set_ylabel(
        "F1"
    )

    ax.set_xlabel(
        "Fusion benefit class"
    )

    ax.set_title(
        "Per-Class Fusion Benefit Prediction"
    )

    ax.legend(
        frameon=False,
    )

    ax.grid(
        axis="y",
        alpha=0.25,
    )

    fig.tight_layout()

    save_figure(
        fig,
        "04_per_class_f1",
    )


# ============================================================
# Figure 5+
# Confusion matrices
# ============================================================

def plot_confusion_matrix(
    matrix,
    method,
    normalized=False,
):

    matrix = np.asarray(
        matrix,
        dtype=float,
    )

    if normalized:
        row_sum = (
            matrix.sum(
                axis=1,
                keepdims=True,
            )
        )

        matrix = np.divide(
            matrix,
            row_sum,
            out=np.zeros_like(
                matrix
            ),
            where=(
                row_sum != 0
            ),
        )

    fig, ax = plt.subplots(
        figsize=(5.5, 5)
    )

    image = ax.imshow(
        matrix,
        vmin=0,
        vmax=(
            1
            if normalized
            else None
        ),
    )

    for i in range(
        len(CLASSES)
    ):
        for j in range(
            len(CLASSES)
        ):
            if normalized:
                text = (
                    f"{matrix[i, j]:.2f}"
                )
            else:
                text = (
                    f"{int(matrix[i, j])}"
                )

            ax.text(
                j,
                i,
                text,
                ha="center",
                va="center",
            )

    ax.set_xticks(
        np.arange(
            len(CLASSES)
        )
    )

    ax.set_yticks(
        np.arange(
            len(CLASSES)
        )
    )

    ax.set_xticklabels(
        CLASSES
    )

    ax.set_yticklabels(
        CLASSES
    )

    ax.set_xlabel(
        "Predicted class"
    )

    ax.set_ylabel(
        "Ground-truth class"
    )

    title_suffix = (
        "Normalized Confusion Matrix"
        if normalized
        else
        "Confusion Matrix"
    )

    ax.set_title(
        f"{method}\n{title_suffix}"
    )

    fig.colorbar(
        image,
        ax=ax,
        fraction=0.046,
        pad=0.04,
    )

    fig.tight_layout()

    safe_name = (
        method.lower()
        .replace(" ", "_")
        .replace("-", "_")
        .replace("(", "")
        .replace(")", "")
    )

    suffix = (
        "normalized"
        if normalized
        else "counts"
    )

    save_figure(
        fig,
        f"confusion_{safe_name}_{suffix}",
    )


# ============================================================
# Figure: SFT improvement over zero-shot
# ============================================================

def plot_improvement(pooled):
    frame = pooled.set_index(
        "method"
    )

    if (
        "Zero-shot"
        not in frame.index
        or
        "SFT"
        not in frame.index
    ):
        return

    metrics = [
        (
            "accuracy",
            "Accuracy",
        ),
        (
            "balanced_accuracy",
            "Balanced Accuracy",
        ),
        (
            "macro_f1",
            "Macro-F1",
        ),
    ]

    labels = []
    improvements = []

    for column, label in metrics:
        labels.append(
            label
        )

        improvements.append(
            frame.loc[
                "SFT",
                column,
            ]
            -
            frame.loc[
                "Zero-shot",
                column,
            ]
        )

    fig, ax = plt.subplots(
        figsize=(7.5, 4.5)
    )

    bars = ax.bar(
        labels,
        improvements,
    )

    for bar, value in zip(
        bars,
        improvements,
    ):
        ax.text(
            bar.get_x()
            + bar.get_width() / 2,
            value + 0.01,
            f"+{value:.3f}",
            ha="center",
            va="bottom",
            fontsize=10,
        )

    ax.axhline(
        0,
        linewidth=1,
    )

    ax.set_ylabel(
        "Absolute improvement"
    )

    ax.set_title(
        "Gain from Benchmark Supervision"
    )

    ax.grid(
        axis="y",
        alpha=0.25,
    )

    fig.tight_layout()

    save_figure(
        fig,
        "05_sft_improvement_over_zero",
    )


# ============================================================
# Main
# ============================================================

def main():

    print("=" * 80)
    print("FINAL ELEMENTWISE FIGURE GENERATOR")
    print("=" * 80)

    all_df = load_predictions()

    print()
    print("=" * 80)
    print("DATASET CHECK")
    print("=" * 80)

    print(
        "\nRows by method:"
    )

    print(
        all_df.groupby(
            "method_name"
        ).size()
    )

    print(
        "\nRows by method × fold:"
    )

    print(
        pd.crosstab(
            all_df["method_name"],
            all_df["fold_id"],
        )
    )

    (
        pooled,
        folds,
        per_class,
        confusion,
    ) = compute_results(
        all_df
    )

    order = method_order_present(
        pooled
    )

    pooled = (
        pooled
        .set_index("method")
        .loc[order]
        .reset_index()
    )

    print()
    print("=" * 80)
    print("POOLED RESULTS")
    print("=" * 80)

    print(
        pooled.to_string(
            index=False
        )
    )

    print()
    print("=" * 80)
    print("FOLD RESULTS")
    print("=" * 80)

    print(
        folds.sort_values(
            [
                "method",
                "fold",
            ]
        ).to_string(
            index=False
        )
    )

    print()
    print("=" * 80)
    print("PER-CLASS F1")
    print("=" * 80)

    print(
        per_class.to_string(
            index=False
        )
    )

    # Save numeric data backing every figure.
    pooled.to_csv(
        FIGURES
        / "pooled_metrics.csv",
        index=False,
    )

    folds.to_csv(
        FIGURES
        / "fold_metrics.csv",
        index=False,
    )

    per_class.to_csv(
        FIGURES
        / "per_class_f1.csv",
        index=False,
    )

    all_df.to_csv(
        FIGURES
        / "all_predictions_pooled.csv",
        index=False,
    )

    # Figures
    plot_overall_metrics(
        pooled
    )

    plot_fold_macro_f1(
        folds
    )

    plot_sft_vs_zero(
        folds
    )

    plot_per_class_f1(
        per_class
    )

    plot_improvement(
        pooled
    )

    # Confusion matrices
    for method in order:

        plot_confusion_matrix(
            confusion[
                method
            ],
            method,
            normalized=False,
        )

        plot_confusion_matrix(
            confusion[
                method
            ],
            method,
            normalized=True,
        )

    print()
    print("=" * 80)
    print("DONE")
    print("=" * 80)

    print(
        "Figures:",
        FIGURES,
    )


if __name__ == "__main__":
    main()