import json
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

SCAN = ROOT / "outputs" / "fusion_scan_results.csv"
PROGRAMS = ROOT / "data" / "unique_programs.csv"

OUT = ROOT / "data" / "fusion_dataset"
OUT.mkdir(parents=True, exist_ok=True)


LOW_MAX = 6
HIGH_MIN = 12


scan = pd.read_csv(SCAN)
programs = pd.read_csv(PROGRAMS)


# Only programs for which the real compiler fusion pass succeeded.
df = scan[
    scan["fusion_success"] == True
].copy()


df = df.merge(
    programs[
        [
            "dt1_id",
            "mlir_path",
            "mlir_hash",
        ]
    ],
    on="dt1_id",
    how="left",
    validate="one_to_one",
    suffixes=("", "_program"),
)


df["linalg_ops_removed"] = (
    df["linalg_ops_before"]
    - df["linalg_ops_after"]
)


def benefit_class(n):

    n = int(n)

    if n <= LOW_MAX:
        return "LOW"

    if n >= HIGH_MIN:
        return "HIGH"

    return "MEDIUM"


df["fusion_benefit"] = (
    df["linalg_ops_removed"]
    .map(benefit_class)
)


def optimization_label(cls):

    # The compiler pass is legal for all 693 programs.
    # We distinguish magnitude of opportunity rather than
    # fabricating a no-op/yes-op decision from an imbalanced target.
    if cls == "LOW":
        return "LOW_BENEFIT_FUSION"

    return "APPLY_ELEMENTWISE_FUSION"


df["optimization_label"] = (
    df["fusion_benefit"]
    .map(optimization_label)
)


# Materialize MLIR text for downstream baselines / LLM workers.
mlirs = []

for path in df["mlir_path"]:
    mlirs.append(
        Path(path).read_text()
    )

df["mlir"] = mlirs


columns = [
    "dt1_id",
    "program_id",
    "base_family",
    "semantic_label",
    "level",
    "mlir_hash",
    "mlir_path",
    "mlir",

    "linalg_ops_before",
    "linalg_ops_after",
    "linalg_ops_removed",

    "linalg_generic_before",
    "linalg_generic_after",

    "tensor_ops_before",
    "tensor_ops_after",

    "arith_ops_before",
    "arith_ops_after",

    "fusion_changed_ir",
    "fusion_benefit",
    "optimization_label",
]


df = df[
    [c for c in columns if c in df.columns]
].copy()


df.to_csv(
    OUT / "fusion_dataset.csv",
    index=False,
)

df.to_json(
    OUT / "fusion_dataset.json",
    orient="records",
    indent=2,
)


metadata = {
    "population":
        "compiler-valid unique MLIRBench linalg programs",

    "total":
        int(len(df)),

    "target":
        "elementwise fusion structural benefit",

    "compiler_ground_truth":
        "iree-opt --linalg-fuse-elementwise-ops",

    "benefit_definition": {
        "LOW":
            f"0 <= linalg_ops_removed <= {LOW_MAX}",

        "MEDIUM":
            f"{LOW_MAX + 1} <= linalg_ops_removed < {HIGH_MIN}",

        "HIGH":
            f"linalg_ops_removed >= {HIGH_MIN}",
    },

    "benefit_counts": {
        str(k): int(v)
        for k, v
        in df["fusion_benefit"]
        .value_counts()
        .to_dict()
        .items()
    },

    "families":
        int(
            df["base_family"]
            .nunique()
        ),

    "semantic_label_counts": {
        str(k): int(v)
        for k, v
        in df["semantic_label"]
        .value_counts()
        .to_dict()
        .items()
    },
}


with (
    OUT / "metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print("=" * 72)
print("FINAL ELEMENTWISE-FUSION DATASET")
print("=" * 72)

print("\nPrograms:", len(df))
print("Families:", df["base_family"].nunique())

print("\nFusion benefit:")
print(df["fusion_benefit"].value_counts())

print("\nSemantic labels:")
print(df["semantic_label"].value_counts())

print("\nLevel:")
print(
    df["level"]
    .value_counts()
    .sort_index()
)

print("\nOps removed:")
print(
    df["linalg_ops_removed"]
    .describe()
)

print("\nSaved:")
print(OUT / "fusion_dataset.csv")
print(OUT / "fusion_dataset.json")
print(OUT / "metadata.json")
