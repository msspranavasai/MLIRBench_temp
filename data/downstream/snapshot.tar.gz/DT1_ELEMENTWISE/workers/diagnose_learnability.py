import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.ensemble import (
    ExtraTreesClassifier,
    HistGradientBoostingClassifier,
    RandomForestClassifier,
)

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
)


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

FOLDS = ROOT / "data" / "folds"

CLASSES = [
    "LOW",
    "MEDIUM",
    "HIGH",
]


def static_features(mlir):

    text = str(mlir)

    patterns = {
        "chars":
            None,

        "lines":
            None,

        "linalg_ops":
            r"\blinalg\.[A-Za-z0-9_]+",

        "linalg_generic":
            r"\blinalg\.generic\b",

        "arith_ops":
            r"\barith\.[A-Za-z0-9_]+",

        "tensor_ops":
            r"\btensor\.[A-Za-z0-9_]+",

        "scf_ops":
            r"\bscf\.[A-Za-z0-9_]+",

        "math_ops":
            r"\bmath\.[A-Za-z0-9_]+",

        "fill_ops":
            r"\blinalg\.fill\b",

        "matmul_ops":
            r"\blinalg\.(?:matmul|batch_matmul)\b",

        "generic_ops":
            r"\blinalg\.generic\b",

        "reduce_tokens":
            r"reduction",

        "extract_slice":
            r"\btensor\.extract_slice\b",

        "insert_slice":
            r"\btensor\.insert_slice\b",

        "parallel_tokens":
            r"parallel",

        "iterator_parallel":
            r'"parallel"',

        "iterator_reduction":
            r'"reduction"',

        "yield_tokens":
            r"\blinalg\.yield\b",

        "f32_tokens":
            r"\bf32\b",

        "f64_tokens":
            r"\bf64\b",

        "i1_tokens":
            r"\bi1\b",

        "i32_tokens":
            r"\bi32\b",

        "i64_tokens":
            r"\bi64\b",
    }


    result = {}

    for name, pattern in patterns.items():

        if name == "chars":
            result[name] = len(text)

        elif name == "lines":
            result[name] = len(
                text.splitlines()
            )

        else:
            result[name] = len(
                re.findall(
                    pattern,
                    text,
                )
            )

    return result


def load(fold, split):

    with (
        FOLDS
        / f"fold_{fold}"
        / f"{split}.json"
    ).open() as f:

        return pd.DataFrame(
            json.load(f)
        )


def features(df):

    return pd.DataFrame(
        [
            static_features(x)
            for x in df["mlir"]
        ]
    )


models = {
    "RandomForest":
        lambda: RandomForestClassifier(
            n_estimators=1000,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
            max_features="sqrt",
        ),

    "ExtraTrees":
        lambda: ExtraTreesClassifier(
            n_estimators=1000,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
            max_features="sqrt",
        ),

    "HistGradientBoosting":
        lambda: HistGradientBoostingClassifier(
            max_iter=500,
            learning_rate=0.05,
            random_state=42,
        ),
}


records = []


for fold in range(5):

    train = load(
        fold,
        "train",
    )

    val = load(
        fold,
        "val",
    )


    X_train = features(
        train
    )

    X_val = features(
        val
    )

    X_val = X_val.reindex(
        columns=X_train.columns,
        fill_value=0,
    )


    y_train = train[
        "fusion_benefit"
    ]

    y_val = val[
        "fusion_benefit"
    ]


    print(
        "\n" + "=" * 80
    )

    print(
        f"FOLD {fold}"
    )

    print("=" * 80)


    for name, builder in (
        models.items()
    ):

        model = builder()

        model.fit(
            X_train,
            y_train,
        )


        pred = model.predict(
            X_val
        )


        record = {
            "fold":
                fold,

            "model":
                name,

            "n":
                len(val),

            "accuracy":
                accuracy_score(
                    y_val,
                    pred,
                ),

            "balanced_accuracy":
                balanced_accuracy_score(
                    y_val,
                    pred,
                ),

            "macro_f1":
                f1_score(
                    y_val,
                    pred,
                    labels=CLASSES,
                    average="macro",
                    zero_division=0,
                ),
        }


        records.append(
            record
        )


        print(
            f"{name:24s} "
            f"acc={record['accuracy']:.4f} "
            f"bal_acc={record['balanced_accuracy']:.4f} "
            f"macroF1={record['macro_f1']:.4f}"
        )


results = pd.DataFrame(
    records
)


print(
    "\n" + "=" * 80
)

print(
    "5-FOLD SUMMARY"
)

print("=" * 80)


summary = (
    results
    .groupby("model")[
        [
            "accuracy",
            "balanced_accuracy",
            "macro_f1",
        ]
    ]
    .agg(
        [
            "mean",
            "std",
        ]
    )
)


print(summary)


out = (
    ROOT
    / "outputs"
    / "learnability_results.csv"
)

results.to_csv(
    out,
    index=False,
)

print("\nSaved:", out)
