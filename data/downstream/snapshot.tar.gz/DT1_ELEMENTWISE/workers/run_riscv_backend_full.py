import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time

from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_ELEMENTWISE"
)

DATASET = (
    ROOT
    / "data"
    / "fusion_dataset"
    / "fusion_dataset.csv"
)

OUT = (
    ROOT
    / "outputs"
    / "riscv_backend_extension"
)

PER_PROGRAM = (
    OUT
    / "per_program"
)

OUT.mkdir(
    parents=True,
    exist_ok=True,
)

PER_PROGRAM.mkdir(
    parents=True,
    exist_ok=True,
)


IREE_OPT = shutil.which("iree-opt")
IREE_COMPILE = shutil.which("iree-compile")

if IREE_OPT is None:
    raise RuntimeError("iree-opt not found")

if IREE_COMPILE is None:
    raise RuntimeError("iree-compile not found")


parser = argparse.ArgumentParser()

parser.add_argument(
    "--num-shards",
    type=int,
    default=1,
)

parser.add_argument(
    "--shard-index",
    type=int,
    default=0,
)

parser.add_argument(
    "--workers",
    type=int,
    default=16,
)

parser.add_argument(
    "--limit",
    type=int,
    default=None,
)

parser.add_argument(
    "--timeout",
    type=int,
    default=180,
)

parser.add_argument(
    "--force",
    action="store_true",
)

parser.add_argument(
    "--aggregate-only",
    action="store_true",
)

args = parser.parse_args()


TARGET_FEATURES = (
    "+m,+a,+f,+d,+c,+zvl512b,+v"
)


# ============================================================
# Generic command runner
# ============================================================

def run_command(cmd):

    start = time.time()

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=args.timeout,
        )

        return {
            "success":
                proc.returncode == 0,

            "returncode":
                proc.returncode,

            "stdout":
                proc.stdout,

            "stderr":
                proc.stderr,

            "seconds":
                time.time() - start,

            "timeout":
                False,
        }

    except subprocess.TimeoutExpired as exc:

        stdout = (
            exc.stdout
            if isinstance(exc.stdout, str)
            else ""
        )

        stderr = (
            exc.stderr
            if isinstance(exc.stderr, str)
            else ""
        )

        return {
            "success":
                False,

            "returncode":
                -999,

            "stdout":
                stdout,

            "stderr":
                stderr,

            "seconds":
                time.time() - start,

            "timeout":
                True,
        }


# ============================================================
# Build baseline/fused IR
# ============================================================

def build_ir(
    source,
    destination,
    fused,
):

    cmd = [
        IREE_OPT,
        str(source),
    ]

    if fused:
        cmd.append(
            "--linalg-fuse-elementwise-ops"
        )

    result = run_command(
        cmd
    )

    if result["success"]:
        destination.write_text(
            result["stdout"]
        )

    return result


# ============================================================
# Assembly parsing
# ============================================================

def parse_instruction_stream(text):

    instructions = []

    for raw in text.splitlines():

        line = raw.strip()

        if not line:
            continue

        # Skip assembler directives and comments.
        if line.startswith(
            (
                ".",
                "#",
                "//",
                ";",
            )
        ):
            continue

        # Skip labels.
        if line.endswith(":"):
            continue

        # Remove comments following instructions.
        line = re.split(
            r"\s+#|\s+//",
            line,
            maxsplit=1,
        )[0].strip()

        if not line:
            continue

        # Instruction / pseudo-instruction.
        if re.match(
            r"^[A-Za-z][A-Za-z0-9_.]*(?:\s|$)",
            line,
        ):
            line = re.sub(
                r"\s+",
                " ",
                line,
            )

            instructions.append(
                line
            )

    return instructions


def assembly_metrics(directory):

    asm_files = sorted(
        directory.rglob("*.s")
    )

    all_instructions = []
    vector_opcodes = []
    assembly_bytes = 0

    for path in asm_files:

        text = path.read_text(
            errors="replace"
        )

        assembly_bytes += (
            path.stat().st_size
        )

        instructions = (
            parse_instruction_stream(
                text
            )
        )

        all_instructions.extend(
            instructions
        )

        for instruction in instructions:

            opcode = (
                instruction
                .split(None, 1)[0]
                .lower()
            )

            # RVV opcodes include vsetvli, vle*, vse*,
            # vf*, vm*, etc.
            if opcode.startswith("v"):
                vector_opcodes.append(
                    opcode
                )

    stream = "\n".join(
        all_instructions
    )

    stream_hash = (
        hashlib.sha256(
            stream.encode("utf-8")
        ).hexdigest()
        if stream
        else None
    )

    return {
        "assembly_files":
            len(asm_files),

        "instruction_count":
            len(all_instructions),

        "vector_instruction_count":
            len(vector_opcodes),

        "vector_unique_opcodes":
            ";".join(
                sorted(
                    set(vector_opcodes)
                )
            ),

        "assembly_bytes":
            assembly_bytes,

        "instruction_stream_hash":
            stream_hash,
    }


def total_suffix_bytes(
    directory,
    suffix,
):

    return sum(
        path.stat().st_size
        for path
        in directory.rglob(
            f"*{suffix}"
        )
    )


# ============================================================
# RISC-V compile
# ============================================================

def compile_riscv(
    mlir_path,
    output_dir,
):

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    vmfb = (
        output_dir
        / "program.vmfb"
    )

    cmd = [
        IREE_COMPILE,

        str(mlir_path),

        "-o",
        str(vmfb),

        "--iree-hal-target-device=local",

        "--iree-hal-local-target-device-backends=llvm-cpu",

        "--iree-llvmcpu-target-triple=riscv64",

        "--iree-llvmcpu-target-abi=lp64d",

        "--iree-opt-level=O3",

        (
            "--iree-llvmcpu-target-cpu-features="
            + TARGET_FEATURES
        ),

        (
            "--iree-hal-dump-executable-files-to="
            + str(output_dir)
        ),
    ]

    result = run_command(
        cmd
    )

    result.update(
        assembly_metrics(
            output_dir
        )
    )

    result["vmfb_exists"] = (
        vmfb.exists()
    )

    result["vmfb_bytes"] = (
        vmfb.stat().st_size
        if vmfb.exists()
        else 0
    )

    result["object_bytes"] = (
        total_suffix_bytes(
            output_dir,
            ".o",
        )
    )

    result["shared_object_bytes"] = (
        total_suffix_bytes(
            output_dir,
            ".so",
        )
    )

    return result


# ============================================================
# Atomic checkpointing
# ============================================================

def write_json_atomic(
    path,
    record,
):

    temp = path.with_suffix(
        ".json.tmp"
    )

    with temp.open("w") as handle:
        json.dump(
            record,
            handle,
            indent=2,
        )

    os.replace(
        temp,
        path,
    )


# ============================================================
# Process one program
# ============================================================

def process_program(row):

    dt1_id = str(
        row["dt1_id"]
    )

    result_path = (
        PER_PROGRAM
        / f"{dt1_id}.json"
    )

    # Resume support.
    if (
        result_path.exists()
        and not args.force
    ):

        with result_path.open() as handle:
            existing = json.load(
                handle
            )

        existing["_resumed"] = True

        return existing


    record = {
        "dt1_id":
            dt1_id,

        "program_id":
            str(
                row["program_id"]
            ),

        "base_family":
            str(
                row["base_family"]
            ),

        "semantic_label":
            str(
                row["semantic_label"]
            ),

        "level":
            int(
                row["level"]
            ),

        "fusion_benefit":
            str(
                row["fusion_benefit"]
            ),

        "linalg_ops_before":
            int(
                row["linalg_ops_before"]
            ),

        "linalg_ops_after":
            int(
                row["linalg_ops_after"]
            ),

        "linalg_ops_removed":
            int(
                row["linalg_ops_removed"]
            ),

        "target_triple":
            "riscv64",

        "target_abi":
            "lp64d",

        "target_cpu_features":
            TARGET_FEATURES,
    }


    source = Path(
        row["mlir_path"]
    )


    with tempfile.TemporaryDirectory(
        prefix=(
            f"riscv_{dt1_id}_"
        )
    ) as temp_string:

        temp = Path(
            temp_string
        )

        baseline_mlir = (
            temp / "baseline.mlir"
        )

        fused_mlir = (
            temp / "fused.mlir"
        )


        baseline_opt = build_ir(
            source,
            baseline_mlir,
            fused=False,
        )

        fusion_opt = build_ir(
            source,
            fused_mlir,
            fused=True,
        )


        record[
            "baseline_opt_success"
        ] = baseline_opt[
            "success"
        ]

        record[
            "fusion_opt_success"
        ] = fusion_opt[
            "success"
        ]


        if (
            not baseline_opt["success"]
            or
            not fusion_opt["success"]
        ):

            record[
                "baseline_opt_stderr"
            ] = (
                baseline_opt[
                    "stderr"
                ][-4000:]
            )

            record[
                "fusion_opt_stderr"
            ] = (
                fusion_opt[
                    "stderr"
                ][-4000:]
            )

            record[
                "both_compile"
            ] = False

            write_json_atomic(
                result_path,
                record,
            )

            return record


        baseline_dir = (
            temp
            / "baseline_codegen"
        )

        fused_dir = (
            temp
            / "fused_codegen"
        )


        baseline = compile_riscv(
            baseline_mlir,
            baseline_dir,
        )

        fused = compile_riscv(
            fused_mlir,
            fused_dir,
        )


        keys = [
            "success",
            "returncode",
            "seconds",
            "timeout",
            "assembly_files",
            "instruction_count",
            "vector_instruction_count",
            "vector_unique_opcodes",
            "assembly_bytes",
            "instruction_stream_hash",
            "vmfb_exists",
            "vmfb_bytes",
            "object_bytes",
            "shared_object_bytes",
        ]


        for prefix, result in [
            ("baseline", baseline),
            ("fused", fused),
        ]:

            for key in keys:

                record[
                    f"{prefix}_{key}"
                ] = result.get(key)

            record[
                f"{prefix}_stderr"
            ] = (
                result.get(
                    "stderr",
                    ""
                )[-4000:]
            )


        both_compile = (
            baseline["success"]
            and fused["success"]
        )

        record[
            "both_compile"
        ] = bool(
            both_compile
        )


        if both_compile:

            before = int(
                baseline[
                    "instruction_count"
                ]
            )

            after = int(
                fused[
                    "instruction_count"
                ]
            )


            record[
                "instruction_delta"
            ] = (
                after - before
            )

            record[
                "instructions_removed"
            ] = (
                before - after
            )


            if before > 0:

                record[
                    "instruction_reduction_pct"
                ] = (
                    (
                        before - after
                    )
                    / before
                    * 100.0
                )

            else:

                record[
                    "instruction_reduction_pct"
                ] = None


            if after < before:

                outcome = "IMPROVED"

            elif after == before:

                outcome = "TIED"

            else:

                outcome = "WORSENED"


            record[
                "instruction_outcome"
            ] = outcome


            record[
                "vector_instruction_delta"
            ] = (
                int(
                    fused[
                        "vector_instruction_count"
                    ]
                )
                -
                int(
                    baseline[
                        "vector_instruction_count"
                    ]
                )
            )


            record[
                "instruction_stream_identical"
            ] = (
                baseline[
                    "instruction_stream_hash"
                ]
                ==
                fused[
                    "instruction_stream_hash"
                ]
            )


            baseline_obj = int(
                baseline[
                    "object_bytes"
                ]
            )

            fused_obj = int(
                fused[
                    "object_bytes"
                ]
            )


            record[
                "object_size_delta"
            ] = (
                fused_obj
                - baseline_obj
            )


            if baseline_obj > 0:

                record[
                    "object_size_reduction_pct"
                ] = (
                    (
                        baseline_obj
                        - fused_obj
                    )
                    / baseline_obj
                    * 100.0
                )

            else:

                record[
                    "object_size_reduction_pct"
                ] = None


    write_json_atomic(
        result_path,
        record,
    )

    return record


# ============================================================
# Final aggregation
# ============================================================

def aggregate_all():

    dataset = pd.read_csv(
        DATASET
    )

    expected_ids = set(
        dataset[
            "dt1_id"
        ].astype(str)
    )


    records = []

    for path in sorted(
        PER_PROGRAM.glob(
            "*.json"
        )
    ):

        with path.open() as handle:
            record = json.load(
                handle
            )

        if (
            str(
                record.get(
                    "dt1_id"
                )
            )
            in expected_ids
        ):

            records.append(
                record
            )


    if not records:

        raise RuntimeError(
            "No per-program results found."
        )


    df = pd.DataFrame(
        records
    )

    df = (
        df
        .drop_duplicates(
            subset=[
                "dt1_id"
            ],
            keep="last",
        )
        .sort_values(
            "dt1_id"
        )
        .reset_index(
            drop=True
        )
    )


    full_csv = (
        OUT
        / "riscv_backend_results.csv"
    )

    df.to_csv(
        full_csv,
        index=False,
    )


    if "both_compile" in df.columns:

        both = df[
            df[
                "both_compile"
            ] == True
        ].copy()

    else:

        both = pd.DataFrame()


    summary = {
        "programs_expected":
            int(
                len(dataset)
            ),

        "programs_completed":
            int(
                len(df)
            ),

        "baseline_compile_success":
            int(
                (
                    df.get(
                        "baseline_success",
                        pd.Series(
                            False,
                            index=df.index,
                        )
                    )
                    == True
                ).sum()
            ),

        "fused_compile_success":
            int(
                (
                    df.get(
                        "fused_success",
                        pd.Series(
                            False,
                            index=df.index,
                        )
                    )
                    == True
                ).sum()
            ),

        "both_compile":
            int(
                len(both)
            ),

        "instruction_outcomes":
            {},

        "by_fusion_benefit":
            {},
    }


    if len(both):

        outcome_counts = (
            both[
                "instruction_outcome"
            ]
            .value_counts()
            .to_dict()
        )

        summary[
            "instruction_outcomes"
        ] = {
            str(key):
                int(value)

            for key, value
            in outcome_counts.items()
        }


        reduction = (
            both[
                "instruction_reduction_pct"
            ]
            .dropna()
        )


        summary[
            "instruction_reduction_pct"
        ] = {
            "mean":
                float(
                    reduction.mean()
                ),

            "median":
                float(
                    reduction.median()
                ),

            "std":
                float(
                    reduction.std()
                ),

            "min":
                float(
                    reduction.min()
                ),

            "q25":
                float(
                    reduction.quantile(
                        0.25
                    )
                ),

            "q75":
                float(
                    reduction.quantile(
                        0.75
                    )
                ),

            "max":
                float(
                    reduction.max()
                ),
        }


        summary[
            "instruction_stream_identical"
        ] = int(
            (
                both[
                    "instruction_stream_identical"
                ] == True
            ).sum()
        )


        pair = (
            both[
                [
                    "linalg_ops_removed",
                    "instruction_reduction_pct",
                ]
            ]
            .dropna()
        )


        if len(pair) >= 2:

            summary[
                "correlation"
            ] = {
                "pearson":
                    float(
                        pair[
                            "linalg_ops_removed"
                        ].corr(
                            pair[
                                "instruction_reduction_pct"
                            ],
                            method="pearson",
                        )
                    ),

                "spearman":
                    float(
                        pair[
                            "linalg_ops_removed"
                        ].corr(
                            pair[
                                "instruction_reduction_pct"
                            ],
                            method="spearman",
                        )
                    ),
            }


        for benefit in [
            "LOW",
            "MEDIUM",
            "HIGH",
        ]:

            part = both[
                both[
                    "fusion_benefit"
                ] == benefit
            ]


            if len(part):

                mean_reduction = float(
                    part[
                        "instruction_reduction_pct"
                    ].mean()
                )

                median_reduction = float(
                    part[
                        "instruction_reduction_pct"
                    ].median()
                )

                mean_vector_delta = float(
                    part[
                        "vector_instruction_delta"
                    ].mean()
                )

            else:

                mean_reduction = None
                median_reduction = None
                mean_vector_delta = None


            summary[
                "by_fusion_benefit"
            ][benefit] = {
                "n":
                    int(
                        len(part)
                    ),

                "improved":
                    int(
                        (
                            part[
                                "instruction_outcome"
                            ]
                            == "IMPROVED"
                        ).sum()
                    ),

                "tied":
                    int(
                        (
                            part[
                                "instruction_outcome"
                            ]
                            == "TIED"
                        ).sum()
                    ),

                "worsened":
                    int(
                        (
                            part[
                                "instruction_outcome"
                            ]
                            == "WORSENED"
                        ).sum()
                    ),

                "mean_instruction_reduction_pct":
                    mean_reduction,

                "median_instruction_reduction_pct":
                    median_reduction,

                "mean_vector_instruction_delta":
                    mean_vector_delta,
            }


    failures = df[
        df.get(
            "both_compile",
            pd.Series(
                False,
                index=df.index,
            )
        ) != True
    ]


    failures.to_csv(
        OUT
        / "riscv_backend_failures.csv",
        index=False,
    )


    with (
        OUT
        / "riscv_backend_summary.json"
    ).open("w") as handle:

        json.dump(
            summary,
            handle,
            indent=2,
        )


    print("=" * 80)
    print("FINAL RISC-V BACKEND SUMMARY")
    print("=" * 80)

    print(
        json.dumps(
            summary,
            indent=2,
        )
    )

    print()
    print("Saved:")
    print(full_csv)
    print(
        OUT
        / "riscv_backend_summary.json"
    )


# ============================================================
# Main
# ============================================================

def main():

    if args.aggregate_only:

        aggregate_all()
        return


    if args.num_shards < 1:

        raise ValueError(
            "--num-shards must be >= 1"
        )


    if not (
        0
        <= args.shard_index
        < args.num_shards
    ):

        raise ValueError(
            "Invalid shard index"
        )


    dataset = pd.read_csv(
        DATASET
    )

    dataset = (
        dataset
        .sort_values(
            "dt1_id"
        )
        .reset_index(
            drop=True
        )
    )


    if args.limit is not None:

        dataset = dataset.head(
            args.limit
        ).copy()

    else:

        dataset = dataset[
            dataset.index
            % args.num_shards
            == args.shard_index
        ].copy()


    print("=" * 80)
    print("DT1 RISC-V BACKEND EXTENSION")
    print("=" * 80)

    print(
        "Host:",
        os.uname().nodename,
    )

    print(
        "Programs in this run:",
        len(dataset),
    )

    print(
        "Shard:",
        f"{args.shard_index}/"
        f"{args.num_shards}",
    )

    print(
        "Workers:",
        args.workers,
    )

    print(
        "IREE opt:",
        IREE_OPT,
    )

    print(
        "IREE compile:",
        IREE_COMPILE,
    )

    print(
        "\nFusion benefit:"
    )

    print(
        dataset[
            "fusion_benefit"
        ].value_counts()
    )


    results = []


    with ThreadPoolExecutor(
        max_workers=args.workers
    ) as pool:

        future_map = {
            pool.submit(
                process_program,
                row,
            ):
                str(
                    row["dt1_id"]
                )

            for _, row
            in dataset.iterrows()
        }


        completed = 0


        for future in as_completed(
            future_map
        ):

            dt1_id = future_map[
                future
            ]

            try:

                result = (
                    future.result()
                )

            except Exception as exc:

                result = {
                    "dt1_id":
                        dt1_id,

                    "worker_exception":
                        repr(exc),

                    "both_compile":
                        False,
                }

            results.append(
                result
            )

            completed += 1


            if (
                completed % 10 == 0
                or completed
                == len(dataset)
            ):

                print(
                    f"{completed}/"
                    f"{len(dataset)}"
                )


    shard_csv = (
        OUT
        / (
            f"shard_{args.shard_index}"
            f"_of_{args.num_shards}.csv"
        )
    )


    pd.DataFrame(
        results
    ).to_csv(
        shard_csv,
        index=False,
    )


    print()
    print(
        "Saved shard:",
        shard_csv,
    )


if __name__ == "__main__":
    main()
