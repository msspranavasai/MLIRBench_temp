import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


# ============================================================
# PATHS
# ============================================================

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench"
)

PRED_DIR = ROOT / "outputs/dt2_all-dataset/predictions"
FIG_DIR = ROOT / "outputs/dt2_all-dataset/figures"

FIG_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# LOAD METRICS
# ============================================================

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)


zero = load_json(
    PRED_DIR / "all-dataset_zero_shot_metrics.json"
)

shot42 = load_json(
    PRED_DIR / "all-dataset_6shot_seed_42_metrics.json"
)

shot123 = load_json(
    PRED_DIR / "all-dataset_6shot_seed_123_metrics.json"
)

sft = load_json(
    PRED_DIR / "all-dataset_sft_test_metrics.json"
)


# ============================================================
# HELPERS
# ============================================================

def icl_mean(path, metric):
    """Mean metric across the two 6-shot demonstration seeds."""
    return np.mean([
        shot42[path][metric],
        shot123[path][metric],
    ])


def pct(x):
    return 100 * x


def label_bars(ax, bars, decimals=1):
    for bar in bars:
        height = bar.get_height()
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            height + 1.0,
            f"{height:.{decimals}f}%",
            ha="center",
            va="bottom",
            fontsize=9,
        )


# ============================================================
# FIGURE 1
#
# OVERALL ACCURACY + MACRO-F1
# ============================================================

methods = [
    "Zero-shot",
    "6-shot ICL\n(2-seed mean)",
    "MLIRBench SFT",
]

accuracy = [
    pct(zero["overall"]["accuracy"]),
    pct(np.mean([
        shot42["overall"]["accuracy"],
        shot123["overall"]["accuracy"],
    ])),
    pct(sft["overall"]["accuracy"]),
]

macro_f1 = [
    pct(zero["overall"]["macro_f1"]),
    pct(np.mean([
        shot42["overall"]["macro_f1"],
        shot123["overall"]["macro_f1"],
    ])),
    pct(sft["overall"]["macro_f1"]),
]

x = np.arange(len(methods))
width = 0.34

fig, ax = plt.subplots(figsize=(9, 5.5))

bars1 = ax.bar(
    x - width / 2,
    accuracy,
    width,
    label="Accuracy",
)

bars2 = ax.bar(
    x + width / 2,
    macro_f1,
    width,
    label="Macro-F1",
)

label_bars(ax, bars1)
label_bars(ax, bars2)

ax.set_ylabel("Score (%)")
ax.set_ylim(0, 100)

ax.set_xticks(x)
ax.set_xticklabels(methods)

ax.set_title(
    "DT2 Semantic Relationship Classification\n"
    "Family-Disjoint Held-Out Test Set (Linalg + Torch)"
)

ax.legend()
ax.grid(axis="y", alpha=0.25)

fig.tight_layout()

out = FIG_DIR / "dt2_overall_accuracy_macro_f1.png"
fig.savefig(out, dpi=300, bbox_inches="tight")
plt.close(fig)

print("Saved:", out)


# ============================================================
# FIGURE 2
#
# ACCURACY: OVERALL vs LINALG vs TORCH
# ============================================================

zero_accuracy = [
    pct(zero["overall"]["accuracy"]),
    pct(zero["by_dialect"]["linalg"]["accuracy"]),
    pct(zero["by_dialect"]["torch"]["accuracy"]),
]

icl_accuracy = [
    pct(np.mean([
        shot42["overall"]["accuracy"],
        shot123["overall"]["accuracy"],
    ])),
    pct(np.mean([
        shot42["by_dialect"]["linalg"]["accuracy"],
        shot123["by_dialect"]["linalg"]["accuracy"],
    ])),
    pct(np.mean([
        shot42["by_dialect"]["torch"]["accuracy"],
        shot123["by_dialect"]["torch"]["accuracy"],
    ])),
]

sft_accuracy = [
    pct(sft["overall"]["accuracy"]),
    pct(sft["by_dialect"]["linalg"]["accuracy"]),
    pct(sft["by_dialect"]["torch"]["accuracy"]),
]

categories = ["Overall", "Linalg", "Torch"]

x = np.arange(len(categories))
width = 0.25

fig, ax = plt.subplots(figsize=(9.5, 5.8))

b1 = ax.bar(
    x - width,
    zero_accuracy,
    width,
    label="Zero-shot",
)

b2 = ax.bar(
    x,
    icl_accuracy,
    width,
    label="6-shot ICL (2-seed mean)",
)

b3 = ax.bar(
    x + width,
    sft_accuracy,
    width,
    label="MLIRBench SFT",
)

label_bars(ax, b1)
label_bars(ax, b2)
label_bars(ax, b3)

ax.set_ylabel("Accuracy (%)")
ax.set_ylim(0, 100)

ax.set_xticks(x)
ax.set_xticklabels(categories)

ax.set_title(
    "DT2 Test Accuracy by MLIR Dialect\n"
    "Overall vs Linalg vs Torch on Family-Disjoint Programs"
)

ax.legend()
ax.grid(axis="y", alpha=0.25)

fig.tight_layout()

out = FIG_DIR / "dt2_accuracy_linalg_vs_torch.png"
fig.savefig(out, dpi=300, bbox_inches="tight")
plt.close(fig)

print("Saved:", out)


# ============================================================
# FIGURE 3
#
# MACRO-F1: OVERALL vs LINALG vs TORCH
# ============================================================

zero_f1 = [
    pct(zero["overall"]["macro_f1"]),
    pct(zero["by_dialect"]["linalg"]["macro_f1"]),
    pct(zero["by_dialect"]["torch"]["macro_f1"]),
]

icl_f1 = [
    pct(np.mean([
        shot42["overall"]["macro_f1"],
        shot123["overall"]["macro_f1"],
    ])),
    pct(np.mean([
        shot42["by_dialect"]["linalg"]["macro_f1"],
        shot123["by_dialect"]["linalg"]["macro_f1"],
    ])),
    pct(np.mean([
        shot42["by_dialect"]["torch"]["macro_f1"],
        shot123["by_dialect"]["torch"]["macro_f1"],
    ])),
]

sft_f1 = [
    pct(sft["overall"]["macro_f1"]),
    pct(sft["by_dialect"]["linalg"]["macro_f1"]),
    pct(sft["by_dialect"]["torch"]["macro_f1"]),
]

x = np.arange(len(categories))
width = 0.25

fig, ax = plt.subplots(figsize=(9.5, 5.8))

b1 = ax.bar(
    x - width,
    zero_f1,
    width,
    label="Zero-shot",
)

b2 = ax.bar(
    x,
    icl_f1,
    width,
    label="6-shot ICL (2-seed mean)",
)

b3 = ax.bar(
    x + width,
    sft_f1,
    width,
    label="MLIRBench SFT",
)

label_bars(ax, b1)
label_bars(ax, b2)
label_bars(ax, b3)

ax.set_ylabel("Macro-F1 (%)")
ax.set_ylim(0, 100)

ax.set_xticks(x)
ax.set_xticklabels(categories)

ax.set_title(
    "DT2 Test Macro-F1 by MLIR Dialect\n"
    "Overall vs Linalg vs Torch on Family-Disjoint Programs"
)

ax.legend()
ax.grid(axis="y", alpha=0.25)

fig.tight_layout()

out = FIG_DIR / "dt2_macro_f1_linalg_vs_torch.png"
fig.savefig(out, dpi=300, bbox_inches="tight")
plt.close(fig)

print("Saved:", out)


# ============================================================
# FIGURE 4
#
# SFT PER-CLASS F1: OVERALL vs LINALG vs TORCH
# ============================================================

classes = ["EQUIV", "DIVERGE", "ERROR"]

overall_class_f1 = [
    pct(sft["overall"]["per_class_f1"][c])
    for c in classes
]

linalg_class_f1 = [
    pct(sft["by_dialect"]["linalg"]["per_class_f1"][c])
    for c in classes
]

torch_class_f1 = [
    pct(sft["by_dialect"]["torch"]["per_class_f1"][c])
    for c in classes
]

x = np.arange(len(classes))
width = 0.25

fig, ax = plt.subplots(figsize=(9.5, 5.8))

b1 = ax.bar(
    x - width,
    overall_class_f1,
    width,
    label="Overall",
)

b2 = ax.bar(
    x,
    linalg_class_f1,
    width,
    label="Linalg",
)

b3 = ax.bar(
    x + width,
    torch_class_f1,
    width,
    label="Torch",
)

label_bars(ax, b1)
label_bars(ax, b2)
label_bars(ax, b3)

ax.set_ylabel("F1 Score (%)")
ax.set_ylim(0, 100)

ax.set_xticks(x)
ax.set_xticklabels(classes)

ax.set_title(
    "MLIRBench SFT Test Performance by Relationship Class\n"
    "Overall, Linalg, and Torch on Family-Disjoint Programs"
)

ax.legend()
ax.grid(axis="y", alpha=0.25)

fig.tight_layout()

out = FIG_DIR / "dt2_sft_per_class_f1_linalg_vs_torch.png"
fig.savefig(out, dpi=300, bbox_inches="tight")
plt.close(fig)

print("Saved:", out)


# ============================================================
# PRINT NUMBERS USED IN FIGURES
# ============================================================

print("\n" + "=" * 72)
print("FINAL DT2 RESULTS USED IN FIGURES")
print("=" * 72)

print("\nZero-shot")
print("Overall accuracy:", zero_accuracy[0])
print("Linalg accuracy:", zero_accuracy[1])
print("Torch accuracy:", zero_accuracy[2])

print("\n6-shot ICL, mean of seeds 42 and 123")
print("Overall accuracy:", icl_accuracy[0])
print("Linalg accuracy:", icl_accuracy[1])
print("Torch accuracy:", icl_accuracy[2])

print("\nMLIRBench SFT")
print("Overall accuracy:", sft_accuracy[0])
print("Linalg accuracy:", sft_accuracy[1])
print("Torch accuracy:", sft_accuracy[2])

print("\nSFT Macro-F1")
print("Overall:", sft_f1[0])
print("Linalg:", sft_f1[1])
print("Torch:", sft_f1[2])