import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_GENERIC_OPT"
)

DATA = (
    ROOT
    / "data"
    / "unique_programs.csv"
)

OUT = ROOT / "outputs"
PER_PROGRAM = OUT / "per_program"

OUT.mkdir(parents=True, exist_ok=True)
PER_PROGRAM.mkdir(parents=True, exist_ok=True)


IREE_OPT = shutil.which("iree-opt")

if IREE_OPT is None:
    raise RuntimeError(
        "iree-opt not found"
    )


parser = argparse.ArgumentParser()

parser.add_argument(
    "--num-shards",
    type=int,
    default=1,
)

parser.add_argument(
    "--shard-index",
    type=int,
    default=0,
)

parser.add_argument(
    "--workers",
    type=int,
    default=16,
)

parser.add_argument(
    "--limit",
    type=int,
    default=None,
)

parser.add_argument(
    "--force",
    action="store_true",
)

parser.add_argument(
    "--aggregate-only",
    action="store_true",
)

args = parser.parse_args()


PASSES = {
    "canonicalize": [
        "--canonicalize",
    ],

    "cse": [
        "--cse",
    ],

    "canonicalize_cse": [
        "--canonicalize",
        "--cse",
    ],
}


def run(cmd):
    start = time.time()

    p = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    return {
        "success": p.returncode == 0,
        "returncode": p.returncode,
        "stdout": p.stdout,
        "stderr": p.stderr,
        "seconds": time.time() - start,
    }


def generic_ir(path, passes=None):
    cmd = [
        IREE_OPT,
        str(path),
        "--mlir-print-op-generic",
    ]

    if passes:
        cmd.extend(passes)

    return run(cmd)


def normalize(text):
    # Ignore whitespace-only differences.
    return re.sub(
        r"\s+",
        " ",
        str(text),
    ).strip()


def count_ops(text):
    """
    Generic MLIR output prints operations in quotes:
      %0 = "arith.addf"(...)
      "func.return"(...)
    """

    pattern = re.compile(
        r'^\s*(?:%[^=]+=\s*)?"[^"]+"\(',
        re.MULTILINE,
    )

    return len(
        pattern.findall(text)
    )


def write_atomic(path, obj):
    tmp = path.with_suffix(
        ".json.tmp"
    )

    with tmp.open("w") as f:
        json.dump(
            obj,
            f,
            indent=2,
        )

    os.replace(
        tmp,
        path,
    )


def process(row):
    dt1_id = str(
        row["dt1_id"]
    )

    result_path = (
        PER_PROGRAM
        / f"{dt1_id}.json"
    )

    if (
        result_path.exists()
        and not args.force
    ):
        with result_path.open() as f:
            return json.load(f)


    source = Path(
        row["mlir_path"]
    )

    record = {
        "dt1_id":
            dt1_id,

        "mlir_hash":
            str(
                row["mlir_hash"]
            ),

        "dialect":
            str(
                row["dialect"]
            ),

        "base_families":
            str(
                row["base_families"]
            ),

        "semantic_labels":
            str(
                row["semantic_labels"]
            ),
    }


    baseline = generic_ir(
        source
    )

    record[
        "baseline_success"
    ] = baseline[
        "success"
    ]

    if not baseline["success"]:
        record[
            "baseline_stderr"
        ] = baseline[
            "stderr"
        ][-3000:]

        write_atomic(
            result_path,
            record,
        )

        return record


    baseline_text = baseline[
        "stdout"
    ]

    baseline_norm = normalize(
        baseline_text
    )

    before_ops = count_ops(
        baseline_text
    )


    record[
        "ops_before"
    ] = before_ops

    record[
        "chars_before"
    ] = len(
        baseline_text
    )


    for name, pass_args in (
        PASSES.items()
    ):
        result = generic_ir(
            source,
            passes=pass_args,
        )

        record[
            f"{name}_success"
        ] = result[
            "success"
        ]

        if not result["success"]:
            record[
                f"{name}_stderr"
            ] = result[
                "stderr"
            ][-3000:]

            continue


        text = result[
            "stdout"
        ]

        norm = normalize(
            text
        )

        after_ops = count_ops(
            text
        )

        ops_removed = (
            before_ops
            - after_ops
        )


        record[
            f"{name}_changed_ir"
        ] = (
            baseline_norm
            != norm
        )

        record[
            f"{name}_ops_after"
        ] = after_ops

        record[
            f"{name}_ops_removed"
        ] = ops_removed

        record[
            f"{name}_reduction_pct"
        ] = (
            ops_removed
            / before_ops
            * 100.0
            if before_ops > 0
            else 0.0
        )

        record[
            f"{name}_chars_after"
        ] = len(text)

        record[
            f"{name}_chars_removed"
        ] = (
            len(
                baseline_text
            )
            - len(text)
        )


    write_atomic(
        result_path,
        record,
    )

    return record


def aggregate():
    source = pd.read_csv(
        DATA
    )

    expected = set(
        source[
            "dt1_id"
        ].astype(str)
    )

    rows = []

    for path in sorted(
        PER_PROGRAM.glob(
            "*.json"
        )
    ):
        with path.open() as f:
            record = json.load(f)

        if (
            str(
                record.get(
                    "dt1_id"
                )
            )
            in expected
        ):
            rows.append(
                record
            )


    df = pd.DataFrame(
        rows
    )

    df = (
        df
        .drop_duplicates(
            "dt1_id"
        )
        .sort_values(
            "dt1_id"
        )
    )


    result_path = (
        OUT
        / "generic_opt_scan.csv"
    )

    df.to_csv(
        result_path,
        index=False,
    )


    print("=" * 90)
    print("GENERIC OPTIMIZATION COMPARISON")
    print("=" * 90)

    print(
        "\nPrograms expected:",
        len(source),
    )

    print(
        "Programs completed:",
        len(df),
    )


    summaries = {}


    for name in PASSES:

        good = df[
            df[
                f"{name}_success"
            ] == True
        ].copy()


        print()
        print("=" * 70)
        print(name.upper())
        print("=" * 70)

        print(
            "Success:",
            len(good),
        )

        changed = (
            good[
                f"{name}_changed_ir"
            ]
            .fillna(False)
        )

        print(
            "Changed IR:",
            int(
                changed.sum()
            ),
        )

        print(
            "Changed fraction:",
            float(
                changed.mean()
            )
            if len(good)
            else 0,
        )


        print(
            "\nOperations removed:"
        )

        print(
            good[
                f"{name}_ops_removed"
            ].describe(
                percentiles=[
                    .1,
                    .25,
                    .5,
                    .75,
                    .9,
                ]
            )
        )


        print(
            "\nBy dialect:"
        )

        print(
            good.groupby(
                "dialect"
            ).agg(
                programs=(
                    "dt1_id",
                    "count",
                ),

                changed=(
                    f"{name}_changed_ir",
                    "sum",
                ),

                mean_ops_removed=(
                    f"{name}_ops_removed",
                    "mean",
                ),

                median_ops_removed=(
                    f"{name}_ops_removed",
                    "median",
                ),

                mean_reduction_pct=(
                    f"{name}_reduction_pct",
                    "mean",
                ),
            )
        )


        summaries[name] = {
            "success":
                int(
                    len(good)
                ),

            "changed":
                int(
                    changed.sum()
                ),

            "changed_fraction":
                float(
                    changed.mean()
                )
                if len(good)
                else 0.0,

            "mean_ops_removed":
                float(
                    good[
                        f"{name}_ops_removed"
                    ].mean()
                )
                if len(good)
                else None,

            "median_ops_removed":
                float(
                    good[
                        f"{name}_ops_removed"
                    ].median()
                )
                if len(good)
                else None,
        }


    with (
        OUT
        / "generic_opt_summary.json"
    ).open("w") as f:
        json.dump(
            summaries,
            f,
            indent=2,
        )


    print()
    print("Saved:")
    print(result_path)
    print(
        OUT
        / "generic_opt_summary.json"
    )


def main():

    if args.aggregate_only:
        aggregate()
        return


    df = pd.read_csv(
        DATA
    )

    df = (
        df.sort_values(
            "dt1_id"
        )
        .reset_index(
            drop=True
        )
    )


    if args.limit is not None:
        df = df.head(
            args.limit
        )

    else:
        df = df[
            df.index
            % args.num_shards
            == args.shard_index
        ]


    print("=" * 72)
    print("GENERIC OPTIMIZATION SCAN")
    print("=" * 72)

    print(
        "Host:",
        os.uname().nodename,
    )

    print(
        "Programs:",
        len(df),
    )

    print(
        "Shard:",
        f"{args.shard_index}/"
        f"{args.num_shards}",
    )

    print(
        "Workers:",
        args.workers,
    )


    results = []


    with ThreadPoolExecutor(
        max_workers=args.workers
    ) as pool:

        futures = {
            pool.submit(
                process,
                row,
            ):
                row["dt1_id"]

            for _, row
            in df.iterrows()
        }


        done = 0

        for future in as_completed(
            futures
        ):
            results.append(
                future.result()
            )

            done += 1

            if (
                done % 25 == 0
                or done == len(df)
            ):
                print(
                    f"{done}/{len(df)}"
                )


    shard = (
        OUT
        / (
            f"shard_{args.shard_index}"
            f"_of_{args.num_shards}.csv"
        )
    )

    pd.DataFrame(
        results
    ).to_csv(
        shard,
        index=False,
    )

    print(
        "Saved:",
        shard,
    )


if __name__ == "__main__":
    main()
