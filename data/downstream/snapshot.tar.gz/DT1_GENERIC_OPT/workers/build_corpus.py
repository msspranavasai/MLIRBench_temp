import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1_GENERIC_OPT"
)

SOURCE = Path(
    "/home/pranava7/mlirbench/"
    "dt-2-all-dataset/data/dt2_all_dataset_source.json"
)

PROGRAMS = ROOT / "programs"
DATA = ROOT / "data"

PROGRAMS.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)


def usable_mlir(x):
    if x is None:
        return False

    text = str(x).strip()

    if not text:
        return False

    bad = {
        "none",
        "null",
        "n/a",
        "nan",
    }

    return text.lower() not in bad


def family_from_program_id(pid):
    pid = str(pid)

    m = re.search(
        r"(seed\d+)_(?:linalg|torch)_(prog\d+)",
        pid,
    )

    if m:
        return f"{m.group(1)}_{m.group(2)}"

    # fallback: strip level/replicate suffix
    return re.sub(
        r"_L\d+_R\d+$",
        "",
        pid,
    )


with SOURCE.open() as f:
    rows = json.load(f)


usable = [
    r
    for r in rows
    if usable_mlir(
        r.get("mutated_mlir")
    )
]


grouped = defaultdict(list)

for row in usable:
    mlir = str(
        row["mutated_mlir"]
    ).strip()

    digest = hashlib.sha256(
        mlir.encode("utf-8")
    ).hexdigest()

    grouped[digest].append(row)


records = []

for i, (
    digest,
    members,
) in enumerate(
    sorted(grouped.items())
):
    mlir = str(
        members[0]["mutated_mlir"]
    ).strip()

    dt1_id = f"gen_{i:04d}"

    path = (
        PROGRAMS
        / f"{dt1_id}.mlir"
    )

    path.write_text(
        mlir + "\n"
    )

    dialects = sorted({
        str(x.get("dialect", "")).lower()
        for x in members
    })

    labels = sorted({
        str(x.get("label", ""))
        for x in members
    })

    families = sorted({
        family_from_program_id(
            x.get("program_id", "")
        )
        for x in members
    })

    program_ids = sorted({
        str(x.get("program_id", ""))
        for x in members
    })

    levels = sorted({
        str(x.get("level", ""))
        for x in members
    })

    records.append({
        "dt1_id": dt1_id,
        "mlir_hash": digest,
        "mlir_path": str(path),
        "row_count": len(members),
        "dialect": ";".join(dialects),
        "semantic_labels": ";".join(labels),
        "base_families": ";".join(families),
        "program_ids": ";".join(program_ids),
        "levels": ";".join(levels),
    })


df = pd.DataFrame(records)

df.to_csv(
    DATA / "unique_programs.csv",
    index=False,
)


metadata = {
    "source_rows":
        len(rows),

    "usable_rows":
        len(usable),

    "unique_programs":
        len(df),

    "source_dialects":
        dict(
            Counter(
                str(r.get("dialect", "")).lower()
                for r in usable
            )
        ),

    "unique_program_dialects":
        df["dialect"]
        .value_counts()
        .to_dict(),
}


with (
    DATA / "corpus_metadata.json"
).open("w") as f:
    json.dump(
        metadata,
        f,
        indent=2,
    )


print("=" * 72)
print("GENERIC OPTIMIZATION CORPUS")
print("=" * 72)

print(json.dumps(
    metadata,
    indent=2,
))

print("\nSaved:")
print(DATA / "unique_programs.csv")
