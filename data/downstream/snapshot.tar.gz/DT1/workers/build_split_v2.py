import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

CODEGEN = ROOT / "outputs" / "riscv_codegen_results.csv"
CORPUS = ROOT / "data" / "corpus_rows.csv"

OUT = ROOT / "data" / "splits_v2"
OUT.mkdir(parents=True, exist_ok=True)

SEED = 42


# ============================================================
# Load unique-program compiler results
# ============================================================

df = pd.read_csv(CODEGEN)

for col in [
    "scalar_success",
    "rvv_success",
    "compiler_comparable",
    "rvv_vectorization_realized",
]:
    df[col] = (
        df[col]
        .astype(str)
        .str.lower()
        .eq("true")
    )


print("=" * 80)
print("DT1 FINAL ALL-PROGRAM RISC-V SPLIT")
print("=" * 80)

print("\nUnique MLIR programs:", len(df))


# ============================================================
# Resolve source family
# ============================================================

def get_family(text):
    families = [
        x.strip()
        for x in str(text).split(";")
        if x.strip()
    ]

    if len(families) != 1:
        raise RuntimeError(
            f"Expected exactly one source family: {families}"
        )

    return families[0]


df["base_family"] = (
    df["families"]
    .apply(get_family)
)


# ============================================================
# Recover representative MLIR + metadata
# ============================================================

corpus = pd.read_csv(CORPUS)

representative = (
    corpus
    .sort_values(
        ["mlir_hash", "program_id"]
    )
    .drop_duplicates(
        subset=["mlir_hash"],
        keep="first",
    )
    [
        [
            "mlir_hash",
            "program_id",
            "semantic_label",
            "level",
            "requirement_id",
            "requirement_description",
            "mutated_mlir",
        ]
    ]
)

df = df.merge(
    representative,
    on="mlir_hash",
    how="left",
    validate="one_to_one",
)

if df["mutated_mlir"].isna().any():
    raise RuntimeError(
        "Some compiler programs could not be mapped "
        "back to source MLIR."
    )

# Preserve all relationship labels associated with an exact
# MLIR body. This is descriptive metadata only.
df["semantic_label_set"] = (
    df["semantic_labels"]
)


# ============================================================
# Define FINAL compiler-grounded target
#
# Semantic relationship labels DO NOT participate here.
# ============================================================

def final_target(row):

    if not row["compiler_comparable"]:
        return "UNSUPPORTED"

    benefit = str(row["rvv_benefit"])

    if benefit not in {
        "LOW",
        "MEDIUM",
        "HIGH",
    }:
        raise RuntimeError(
            f"Comparable program has invalid benefit: "
            f"{benefit}"
        )

    return benefit


df["rvv_plan_class"] = df.apply(
    final_target,
    axis=1,
)


# ============================================================
# Map compiler outcome into original DT1 planning interface
# ============================================================

def optimization_label(plan_class):

    if plan_class == "UNSUPPORTED":
        return "AVOID_RVV"

    if plan_class == "LOW":
        return "KEEP_SCALAR"

    return "APPLY_RVV"


df["optimization_label"] = (
    df["rvv_plan_class"]
    .apply(optimization_label)
)


def target_json(row):

    plan_class = row["rvv_plan_class"]

    if plan_class in {"MEDIUM", "HIGH"}:
        passes = [
            "canonicalize",
            "cse",
            "enable-rvv-vectorization",
        ]

    else:
        passes = [
            "canonicalize",
            "cse",
        ]

    return json.dumps(
        {
            "optimization_label":
                row["optimization_label"],

            "recommended_passes":
                passes,

            "rvv_expected_benefit":
                plan_class,

            "reason":
                "",
        },
        separators=(",", ":"),
    )


df["target_json"] = df.apply(
    target_json,
    axis=1,
)


# ============================================================
# Overall distribution
# ============================================================

CLASS_ORDER = [
    "UNSUPPORTED",
    "LOW",
    "MEDIUM",
    "HIGH",
]

print("\nFinal target distribution:")

print(
    df["rvv_plan_class"]
    .value_counts()
    .reindex(
        CLASS_ORDER,
        fill_value=0,
    )
)

print("\nFamilies:", df["base_family"].nunique())


# ============================================================
# Stratified family-group split
#
# fold 0 = test
# fold 1 = validation
# folds 2-4 = training
# ============================================================

splitter = StratifiedGroupKFold(
    n_splits=5,
    shuffle=True,
    random_state=SEED,
)

folds = [None] * len(df)

for fold, (_, indices) in enumerate(
    splitter.split(
        X=df,
        y=df["rvv_plan_class"],
        groups=df["base_family"],
    )
):
    for idx in indices:
        folds[idx] = fold

df["fold"] = folds

if df["fold"].isna().any():
    raise RuntimeError(
        "Some programs did not receive a fold."
    )


test = df[
    df["fold"] == 0
].copy()

val = df[
    df["fold"] == 1
].copy()

train = df[
    df["fold"].isin([2, 3, 4])
].copy()


# ============================================================
# Leakage checks
# ============================================================

train_f = set(train["base_family"])
val_f = set(val["base_family"])
test_f = set(test["base_family"])

family_overlap = {
    "train_val":
        len(train_f & val_f),

    "train_test":
        len(train_f & test_f),

    "val_test":
        len(val_f & test_f),
}

if any(family_overlap.values()):
    raise RuntimeError(
        f"Family leakage: {family_overlap}"
    )


train_h = set(train["mlir_hash"])
val_h = set(val["mlir_hash"])
test_h = set(test["mlir_hash"])

hash_overlap = {
    "train_val":
        len(train_h & val_h),

    "train_test":
        len(train_h & test_h),

    "val_test":
        len(val_h & test_h),
}

if any(hash_overlap.values()):
    raise RuntimeError(
        f"Exact MLIR leakage: {hash_overlap}"
    )


# ============================================================
# Reporting
# ============================================================

def report(name, part):

    print("\n" + "=" * 80)

    print(
        f"{name}: "
        f"{len(part)} unique programs | "
        f"{part['base_family'].nunique()} families"
    )

    print("=" * 80)

    print("\nRVV plan class:")

    print(
        part["rvv_plan_class"]
        .value_counts()
        .reindex(
            CLASS_ORDER,
            fill_value=0,
        )
    )

    print("\nOptimization label:")

    print(
        part["optimization_label"]
        .value_counts()
    )

    print("\nRepresentative MLIRBench labels:")

    print(
        part["semantic_label"]
        .value_counts()
        .reindex(
            ["EQUIV", "DIVERGE", "ERROR"],
            fill_value=0,
        )
    )

    print("\nLevels:")

    print(
        part["level"]
        .value_counts()
        .sort_index()
    )

    comparable = part[
        part["compiler_comparable"]
    ]

    if len(comparable):

        print("\nRVV reduction among comparable programs:")

        print(
            comparable["reduction_pct"]
            .describe()
        )


report("TRAIN", train)
report("VALIDATION", val)
report("TEST", test)


print("\n" + "=" * 80)
print("LEAKAGE")
print("=" * 80)

print("Family:", family_overlap)
print("MLIR hash:", hash_overlap)


# ============================================================
# Save
# ============================================================

def save(name, part):

    part = (
        part
        .sort_values(
            ["base_family", "dt1_id"]
        )
        .reset_index(drop=True)
    )

    part.to_csv(
        OUT / f"{name}.csv",
        index=False,
    )

    records = (
        part
        .where(
            pd.notnull(part),
            None,
        )
        .to_dict(
            orient="records"
        )
    )

    with (
        OUT / f"{name}.json"
    ).open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            records,
            f,
            indent=2,
        )


save("train", train)
save("val", val)
save("test", test)
save("all", df)


metadata = {
    "seed":
        SEED,

    "population":
        "856 unique real linalg MLIR programs",

    "target":
        "compiler-grounded RVV plan class",

    "classes":
        CLASS_ORDER,

    "split_method":
        "StratifiedGroupKFold(n_splits=5, "
        "shuffle=True, random_state=42); "
        "fold0=test, fold1=val, folds2-4=train",

    "group":
        "base_family",

    "total":
        int(len(df)),

    "train":
        int(len(train)),

    "val":
        int(len(val)),

    "test":
        int(len(test)),

    "family_counts": {
        "all":
            int(df["base_family"].nunique()),

        "train":
            int(train["base_family"].nunique()),

        "val":
            int(val["base_family"].nunique()),

        "test":
            int(test["base_family"].nunique()),
    },

    "class_counts": {
        name: {
            str(k): int(v)
            for k, v in
            part["rvv_plan_class"]
            .value_counts()
            .to_dict()
            .items()
        }
        for name, part in [
            ("all", df),
            ("train", train),
            ("val", val),
            ("test", test),
        ]
    },

    "family_overlap":
        family_overlap,

    "mlir_hash_overlap":
        hash_overlap,

    "compiler_ground_truth": {
        "UNSUPPORTED":
            "scalar/RVV RISC-V comparison unavailable",

        "LOW":
            "reduction_pct < 5",

        "MEDIUM":
            "5 <= reduction_pct < 15",

        "HIGH":
            "reduction_pct >= 15",
    },

    "semantic_label_used_as_target":
        False,
}


with (
    OUT / "metadata.json"
).open(
    "w",
    encoding="utf-8",
) as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print("\nSaved:")
print(OUT)
print(OUT / "metadata.json")
