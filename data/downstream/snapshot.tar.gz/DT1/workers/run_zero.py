import json
import sys
from pathlib import Path

import pandas as pd
import torch
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

DATA = ROOT / "data" / "splits_v2"
OUT = ROOT / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(ROOT / "workers"))

from dt1_common import (
    extract_class,
    metrics_dict,
    zero_shot_prompt,
)

MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 256
BATCH_SIZE = 4


with (DATA / "test.json").open() as f:
    df = pd.DataFrame(json.load(f))


tokenizer = AutoTokenizer.from_pretrained(
    MODEL,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"


# ------------------------------------------------------------
# Preflight
# ------------------------------------------------------------

lengths = []

for _, row in df.iterrows():
    prompt = zero_shot_prompt(tokenizer, row)

    lengths.append(
        len(
            tokenizer(
                prompt,
                add_special_tokens=False,
            )["input_ids"]
        )
    )

print("Zero-shot lengths:")
print("min:", min(lengths))
print("mean:", sum(lengths) / len(lengths))
print("max:", max(lengths))

if max(lengths) + MAX_NEW_TOKENS > MAX_SEQ_LEN:
    raise RuntimeError("Context overflow")


# ------------------------------------------------------------
# Model
# ------------------------------------------------------------

model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model.eval()


predictions = []
raw_outputs = []


for start in tqdm(
    range(0, len(df), BATCH_SIZE),
    desc="DT1 zero-shot",
):

    batch = df.iloc[
        start:start + BATCH_SIZE
    ]

    prompts = [
        zero_shot_prompt(
            tokenizer,
            row,
        )
        for _, row in batch.iterrows()
    ]

    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to("cuda")

    with torch.inference_mode():

        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    input_len = inputs["input_ids"].shape[1]

    for output in outputs:

        raw = tokenizer.decode(
            output[input_len:],
            skip_special_tokens=True,
        ).strip()

        raw_outputs.append(raw)
        predictions.append(
            extract_class(raw)
        )


result = df.copy()

result["prediction"] = predictions
result["raw_output"] = raw_outputs
result["correct"] = (
    result["prediction"]
    == result["rvv_plan_class"]
)


metrics = metrics_dict(
    result["rvv_plan_class"],
    result["prediction"],
)

metrics["prompt_lengths"] = {
    "min": int(min(lengths)),
    "mean": float(sum(lengths) / len(lengths)),
    "max": int(max(lengths)),
}


result.to_csv(
    OUT / "zero_shot_predictions.csv",
    index=False,
)

with (
    OUT / "zero_shot_metrics.json"
).open("w") as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


print(json.dumps(metrics, indent=2))
print("Saved zero-shot outputs.")
