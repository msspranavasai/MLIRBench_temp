import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd


# ============================================================
# Paths
# ============================================================

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

SOURCE = Path(
    "/home/pranava7/mlirbench/"
    "dt-2-all-dataset/data/dt2_all_dataset_source.json"
)

DATA_DIR = ROOT / "data"
PROGRAM_DIR = ROOT / "programs"

DATA_DIR.mkdir(parents=True, exist_ok=True)
PROGRAM_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# Configuration
# ============================================================

SENTINELS = {
    "GENERATION_FAILED",
    "MUTATION_FAILED",
    "EXECUTION_FAILED",
    "COMPILATION_FAILED",
    "PARSE_FAILED",
    "VALIDATION_FAILED",
}


# ============================================================
# Helpers
# ============================================================

def normalize_mlir(text: str) -> str:
    """
    Normalize irrelevant trailing whitespace while preserving
    the MLIR program structure.
    """
    return "\n".join(
        line.rstrip()
        for line in str(text).strip().splitlines()
    )


def mlir_hash(text: str) -> str:
    normalized = normalize_mlir(text)

    return hashlib.sha256(
        normalized.encode("utf-8")
    ).hexdigest()


def is_real_mlir(text: str) -> bool:
    text = str(text).strip()

    if not text:
        return False

    upper = text.upper()

    if upper in SENTINELS:
        return False

    if any(s in upper for s in SENTINELS):
        return False

    return True


def base_family(program_id: str) -> str:
    """
    Expected input example:
      seed3_linalg_prog22_L5_R5

    Output:
      seed3_prog22

    This matches the source-program family definition used for
    family-disjoint evaluation.
    """

    text = str(program_id)

    match = re.search(
        r"seed(\d+)_linalg_prog(\d+)",
        text,
    )

    if match:
        return f"seed{match.group(1)}_prog{match.group(2)}"

    # Fallback, but this will be reported so it cannot silently
    # create incorrect family assignments.
    return f"UNPARSED::{text}"


# ============================================================
# Load source
# ============================================================

with SOURCE.open("r", encoding="utf-8") as f:
    rows = json.load(f)

print("=" * 80)
print("DT1: BUILD RISC-V RVV CORPUS")
print("=" * 80)

print("\nSource rows:", len(rows))


# ============================================================
# Keep linalg only
# ============================================================

linalg = [
    r for r in rows
    if str(r.get("dialect", "")).lower() == "linalg"
]

print("Linalg rows:", len(linalg))


# ============================================================
# Remove non-program sentinels / missing MLIR
# ============================================================

valid_rows = []
excluded_rows = []

for row in linalg:
    mlir = row.get("mutated_mlir", "")

    if is_real_mlir(mlir):
        valid_rows.append(row)
    else:
        excluded_rows.append(row)

print("Usable mutated MLIR rows:", len(valid_rows))
print("Excluded missing/sentinel rows:", len(excluded_rows))

print("\nExcluded labels:")
print(Counter(str(r.get("label")) for r in excluded_rows))


# ============================================================
# Build row-level table
# ============================================================

corpus_records = []

for row_index, row in enumerate(valid_rows):

    normalized = normalize_mlir(
        row["mutated_mlir"]
    )

    digest = mlir_hash(normalized)

    family = base_family(
        row["program_id"]
    )

    corpus_records.append(
        {
            "corpus_row_id": f"row_{row_index:04d}",
            "program_id": str(row["program_id"]),
            "base_family": family,
            "dialect": str(row["dialect"]),
            "semantic_label": str(row["label"]),
            "level": row.get("level"),
            "requirement_id": str(
                row.get("requirement_id", "")
            ),
            "requirement_description": str(
                row.get("requirement_description", "")
            ),
            "failure_category": str(
                row.get("failure_category", "")
            ),
            "failure_category_short": str(
                row.get("failure_category_short", "")
            ),
            "valid_status": str(
                row.get("valid_status", "")
            ),
            "seed": row.get("seed"),
            "mlir_hash": digest,
            "mutated_mlir": normalized,
        }
    )

corpus_df = pd.DataFrame(corpus_records)


# ============================================================
# Family validation
# ============================================================

unparsed = corpus_df[
    corpus_df["base_family"]
    .astype(str)
    .str.startswith("UNPARSED::")
]

print("\nUnderlying families:",
      corpus_df["base_family"].nunique())

print("Unparsed family IDs:", len(unparsed))

if len(unparsed):
    print(unparsed[
        ["program_id", "base_family"]
    ].head(20).to_string(index=False))

    raise RuntimeError(
        "Some program IDs could not be mapped to source families."
    )


# ============================================================
# Create unique-program compiler manifest
# ============================================================

grouped = defaultdict(list)

for record in corpus_records:
    grouped[record["mlir_hash"]].append(record)

unique_records = []

for index, digest in enumerate(sorted(grouped)):
    members = grouped[digest]

    dt1_id = f"dt1_{index:04d}"

    mlir_text = members[0]["mutated_mlir"]

    path = PROGRAM_DIR / f"{dt1_id}.mlir"

    path.write_text(
        mlir_text + "\n",
        encoding="utf-8",
    )

    families = sorted({
        x["base_family"]
        for x in members
    })

    labels = sorted({
        x["semantic_label"]
        for x in members
    })

    program_ids = sorted({
        x["program_id"]
        for x in members
    })

    unique_records.append(
        {
            "dt1_id": dt1_id,
            "mlir_hash": digest,
            "mlir_path": str(path),
            "row_count": len(members),
            "family_count": len(families),
            "families": ";".join(families),
            "semantic_labels": ";".join(labels),
            "program_ids": ";".join(program_ids),
        }
    )

unique_df = pd.DataFrame(unique_records)


# ============================================================
# Add dt1_id back to row-level table
# ============================================================

hash_to_id = {
    r["mlir_hash"]: r["dt1_id"]
    for r in unique_records
}

corpus_df["dt1_id"] = (
    corpus_df["mlir_hash"]
    .map(hash_to_id)
)


# ============================================================
# Duplicate diagnostics
# ============================================================

hash_stats = (
    corpus_df
    .groupby("mlir_hash")
    .agg(
        rows=("program_id", "size"),
        families=("base_family", "nunique"),
        labels=("semantic_label", "nunique"),
    )
    .reset_index()
)

multirow = hash_stats[
    hash_stats["rows"] > 1
]

multifamily = hash_stats[
    hash_stats["families"] > 1
]

multilabel = hash_stats[
    hash_stats["labels"] > 1
]


# ============================================================
# Save outputs
# ============================================================

corpus_path = DATA_DIR / "corpus_rows.csv"
unique_path = DATA_DIR / "unique_programs.csv"
excluded_path = DATA_DIR / "excluded_rows.csv"
metadata_path = DATA_DIR / "corpus_metadata.json"

corpus_df.to_csv(
    corpus_path,
    index=False,
)

unique_df.to_csv(
    unique_path,
    index=False,
)

pd.DataFrame(excluded_rows).to_csv(
    excluded_path,
    index=False,
)


metadata = {
    "source_file": str(SOURCE),

    "source_total": len(rows),

    "linalg_total": len(linalg),

    "usable_linalg_rows": len(corpus_df),

    "excluded_rows": len(excluded_rows),

    "semantic_label_counts": {
        str(k): int(v)
        for k, v in
        corpus_df["semantic_label"]
        .value_counts()
        .to_dict()
        .items()
    },

    "family_count": int(
        corpus_df["base_family"].nunique()
    ),

    "unique_mlir_programs": int(
        corpus_df["mlir_hash"].nunique()
    ),

    "duplicate_hashes": int(
        len(multirow)
    ),

    "duplicate_hashes_across_families": int(
        len(multifamily)
    ),

    "duplicate_hashes_across_semantic_labels": int(
        len(multilabel)
    ),
}

with metadata_path.open(
    "w",
    encoding="utf-8",
) as f:
    json.dump(
        metadata,
        f,
        indent=2,
    )


# ============================================================
# Summary
# ============================================================

print("\n" + "=" * 80)
print("CORPUS SUMMARY")
print("=" * 80)

print("\nRows retained:", len(corpus_df))
print("Unique MLIR programs:", len(unique_df))
print("Families:", corpus_df["base_family"].nunique())

print("\nSemantic labels:")
print(
    corpus_df["semantic_label"]
    .value_counts()
    .reindex(
        ["EQUIV", "DIVERGE", "ERROR"],
        fill_value=0,
    )
)

print("\nLevels:")
print(
    corpus_df["level"]
    .value_counts()
    .sort_index()
)

print("\nDuplicate MLIR hashes:")
print("  duplicate hashes:", len(multirow))
print(
    "  spanning multiple families:",
    len(multifamily),
)
print(
    "  spanning multiple semantic labels:",
    len(multilabel),
)

if len(multifamily):
    print(
        "\nWARNING: exact MLIR duplicates occur across "
        "different source families."
    )
    print(
        "We will account for this when constructing "
        "the final train/val/test split."
    )

if len(multilabel):
    print(
        "\nNOTE: exact MLIR programs occur under multiple "
        "MLIRBench semantic relationship labels."
    )
    print(
        "That is allowed for RISC-V compilation because "
        "the backend outcome is a property of the program, "
        "not of its relationship label."
    )

print("\nSaved:")
print(corpus_path)
print(unique_path)
print(excluded_path)
print(metadata_path)
print("MLIR programs:", PROGRAM_DIR)
