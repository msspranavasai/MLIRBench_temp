import re
import shutil
import subprocess
import time
from pathlib import Path

import pandas as pd


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

CORPUS = ROOT / "data" / "corpus_rows.csv"
CODEGEN = ROOT / "codegen" / "smoke"

IREE_COMPILE = shutil.which("iree-compile")

if IREE_COMPILE is None:
    raise RuntimeError("iree-compile not found")


SCALAR_FEATURES = "+m,+a,+f,+d,+c"
RVV_FEATURES = "+m,+a,+f,+d,+c,+zvl512b,+v"

COMMON_ARGS = [
    "--iree-hal-target-device=local",
    "--iree-hal-local-target-device-backends=llvm-cpu",
    "--iree-llvmcpu-target-triple=riscv64",
    "--iree-llvmcpu-target-abi=lp64d",
    "--iree-opt-level=O3",
]


# ============================================================
# Assembly parsing
# ============================================================

RVV_OPCODE = re.compile(r"^v[a-zA-Z0-9_.]+$")


def parse_assembly_files(directory: Path):
    """
    Parse every generated .s file in the output directory.

    We count final assembly instructions and separately count
    RISC-V vector instructions whose opcode begins with `v`.
    """

    asm_files = sorted(directory.glob("*.s"))

    total_instructions = 0
    rvv_instructions = 0
    rvv_ops = []

    per_file = []

    for path in asm_files:
        file_total = 0
        file_rvv = 0

        text = path.read_text(
            encoding="utf-8",
            errors="ignore",
        )

        for raw_line in text.splitlines():
            line = raw_line.strip()

            if not line:
                continue

            # Remove comments.
            line = line.split("#", 1)[0].strip()

            if not line:
                continue

            # Ignore assembler directives.
            if line.startswith("."):
                continue

            # Ignore labels.
            if line.endswith(":"):
                continue

            parts = line.split()

            if not parts:
                continue

            opcode = parts[0]

            if opcode.startswith("."):
                continue

            file_total += 1

            if (
                opcode.startswith("v")
                and RVV_OPCODE.fullmatch(opcode)
            ):
                file_rvv += 1
                rvv_ops.append(opcode)

        total_instructions += file_total
        rvv_instructions += file_rvv

        per_file.append(
            {
                "path": str(path),
                "instructions": file_total,
                "rvv_instructions": file_rvv,
            }
        )

    return {
        "assembly_file_count": len(asm_files),
        "total_instructions": total_instructions,
        "rvv_instructions": rvv_instructions,
        "rvv_opcodes": sorted(set(rvv_ops)),
        "per_file": per_file,
    }


# ============================================================
# Compile
# ============================================================

def compile_one(
    mlir_path: Path,
    output_dir: Path,
    cpu_features: str,
):
    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    vmfb = output_dir / "program.vmfb"

    cmd = [
        IREE_COMPILE,
        str(mlir_path),
        "-o",
        str(vmfb),
        *COMMON_ARGS,
        (
            "--iree-llvmcpu-target-cpu-features="
            + cpu_features
        ),
        (
            "--iree-hal-dump-executable-files-to="
            + str(output_dir)
        ),
    ]

    print("\nCOMMAND:")
    print(" ".join(cmd))

    start = time.time()

    proc = subprocess.run(
        cmd,
        text=True,
        capture_output=True,
    )

    elapsed = time.time() - start

    asm = parse_assembly_files(output_dir)

    return {
        "returncode": proc.returncode,
        "success": proc.returncode == 0,
        "seconds": elapsed,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "vmfb_exists": vmfb.exists(),
        **asm,
    }


# ============================================================
# Pick a simple, real EQUIV example for the smoke test
# ============================================================

df = pd.read_csv(CORPUS)

candidates = df[
    (df["semantic_label"] == "EQUIV")
    & (pd.to_numeric(df["level"], errors="coerce") <= 2)
].copy()

if candidates.empty:
    raise RuntimeError(
        "No EQUIV level 1/2 example available."
    )

# Prefer a shorter program for a fast, simple smoke test.
candidates["mlir_chars"] = (
    candidates["mutated_mlir"]
    .astype(str)
    .str.len()
)

row = candidates.sort_values(
    "mlir_chars"
).iloc[0]

dt1_id = row["dt1_id"]

manifest = pd.read_csv(
    ROOT / "data" / "unique_programs.csv"
)

match = manifest[
    manifest["dt1_id"] == dt1_id
]

if len(match) != 1:
    raise RuntimeError(
        f"Could not uniquely resolve {dt1_id}"
    )

mlir_path = Path(
    match.iloc[0]["mlir_path"]
)

print("=" * 80)
print("DT1 RISC-V SMOKE TEST")
print("=" * 80)

print("dt1_id:", dt1_id)
print("program_id:", row["program_id"])
print("family:", row["base_family"])
print("semantic label:", row["semantic_label"])
print("level:", row["level"])
print("MLIR:", mlir_path)


# ============================================================
# Scalar
# ============================================================

scalar_dir = CODEGEN / "scalar"

scalar = compile_one(
    mlir_path,
    scalar_dir,
    SCALAR_FEATURES,
)

print("\n" + "=" * 80)
print("SCALAR RESULT")
print("=" * 80)

print("success:", scalar["success"])
print("returncode:", scalar["returncode"])
print("seconds:", scalar["seconds"])
print("vmfb:", scalar["vmfb_exists"])
print(
    "assembly files:",
    scalar["assembly_file_count"],
)
print(
    "instructions:",
    scalar["total_instructions"],
)
print(
    "RVV instructions:",
    scalar["rvv_instructions"],
)

if not scalar["success"]:
    print("\nSTDERR:")
    print(scalar["stderr"][-8000:])


# ============================================================
# RVV
# ============================================================

rvv_dir = CODEGEN / "rvv"

rvv = compile_one(
    mlir_path,
    rvv_dir,
    RVV_FEATURES,
)

print("\n" + "=" * 80)
print("RVV RESULT")
print("=" * 80)

print("success:", rvv["success"])
print("returncode:", rvv["returncode"])
print("seconds:", rvv["seconds"])
print("vmfb:", rvv["vmfb_exists"])
print(
    "assembly files:",
    rvv["assembly_file_count"],
)
print(
    "instructions:",
    rvv["total_instructions"],
)
print(
    "RVV instructions:",
    rvv["rvv_instructions"],
)
print(
    "RVV opcodes:",
    rvv["rvv_opcodes"],
)

if not rvv["success"]:
    print("\nSTDERR:")
    print(rvv["stderr"][-8000:])


# ============================================================
# Comparison
# ============================================================

print("\n" + "=" * 80)
print("COMPARISON")
print("=" * 80)

if (
    scalar["success"]
    and rvv["success"]
    and scalar["total_instructions"] > 0
):
    reduction = (
        (
            scalar["total_instructions"]
            - rvv["total_instructions"]
        )
        / scalar["total_instructions"]
        * 100.0
    )

    print(
        "Scalar instructions:",
        scalar["total_instructions"],
    )

    print(
        "RVV instructions:",
        rvv["total_instructions"],
    )

    print(
        "Vector instructions emitted:",
        rvv["rvv_instructions"],
    )

    print(
        "Static instruction reduction:",
        f"{reduction:.6f}%",
    )

    if reduction < 5:
        benefit = "LOW"
    elif reduction < 15:
        benefit = "MEDIUM"
    else:
        benefit = "HIGH"

    print("RVV benefit:", benefit)

else:
    print(
        "Not compiler-comparable."
    )


print("\nGenerated files:")

for path in sorted(CODEGEN.rglob("*")):
    if path.is_file():
        print(path.relative_to(ROOT))
