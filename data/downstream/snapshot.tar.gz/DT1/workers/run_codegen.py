import json
import os
import re
import shutil
import subprocess
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import pandas as pd


# ============================================================
# Configuration
# ============================================================

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

MANIFEST_PATH = ROOT / "data" / "unique_programs.csv"

OUTPUT_PATH = (
    ROOT / "outputs" / "riscv_codegen_results.csv"
)

SUMMARY_PATH = (
    ROOT / "outputs" / "riscv_codegen_summary.json"
)

DUMP_ROOT = ROOT / "codegen" / "full"

IREE_COMPILE = shutil.which("iree-compile")

if IREE_COMPILE is None:
    raise RuntimeError("iree-compile not found")


MAX_WORKERS = int(
    os.environ.get("DT1_WORKERS", "28")
)

COMPILE_TIMEOUT = int(
    os.environ.get("DT1_COMPILE_TIMEOUT", "300")
)


SCALAR_FEATURES = "+m,+a,+f,+d,+c"

RVV_FEATURES = (
    "+m,+a,+f,+d,+c,+zvl512b,+v"
)


COMMON_ARGS = [
    "--iree-hal-target-device=local",
    "--iree-hal-local-target-device-backends=llvm-cpu",

    "--iree-llvmcpu-target-triple=riscv64",
    "--iree-llvmcpu-target-abi=lp64d",

    "--iree-opt-level=O3",
]


RVV_OPCODE = re.compile(
    r"^v[a-zA-Z0-9_.]+$"
)


# ============================================================
# Helpers
# ============================================================

def parse_assembly_files(directory: Path):

    # Use rglob so this keeps working even if a future IREE
    # version places the assembly one directory deeper.
    asm_files = sorted(
        directory.rglob("*.s")
    )

    total_instructions = 0
    rvv_instructions = 0

    all_rvv_ops = []
    assembly_bytes = 0

    for path in asm_files:

        assembly_bytes += path.stat().st_size

        text = path.read_text(
            encoding="utf-8",
            errors="ignore",
        )

        for raw_line in text.splitlines():

            line = raw_line.strip()

            if not line:
                continue

            # Remove RISC-V comments.
            line = line.split("#", 1)[0].strip()

            if not line:
                continue

            # Assembler directives.
            if line.startswith("."):
                continue

            # Labels.
            if line.endswith(":"):
                continue

            parts = line.split()

            if not parts:
                continue

            opcode = parts[0]

            if opcode.startswith("."):
                continue

            total_instructions += 1

            if (
                opcode.startswith("v")
                and RVV_OPCODE.fullmatch(opcode)
            ):
                rvv_instructions += 1
                all_rvv_ops.append(opcode)

    return {
        "assembly_file_count": len(asm_files),

        "total_instructions":
            int(total_instructions),

        "rvv_instructions":
            int(rvv_instructions),

        "rvv_opcodes":
            ";".join(sorted(set(all_rvv_ops))),

        "assembly_bytes":
            int(assembly_bytes),
    }


def compile_configuration(
    mlir_path: Path,
    output_dir: Path,
    cpu_features: str,
):

    # This is important for resume safety. If this program was
    # partially compiled before an interruption, stale .s files
    # must not contaminate the assembly counter.
    if output_dir.exists():
        shutil.rmtree(output_dir)

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    vmfb = output_dir / "program.vmfb"

    cmd = [
        IREE_COMPILE,
        str(mlir_path),

        "-o",
        str(vmfb),

        *COMMON_ARGS,

        (
            "--iree-llvmcpu-target-cpu-features="
            + cpu_features
        ),

        (
            "--iree-hal-dump-executable-files-to="
            + str(output_dir)
        ),
    ]


    # Prevent 28 compiler processes from each trying to use
    # many CPU threads internally.
    env = os.environ.copy()

    env["OMP_NUM_THREADS"] = "1"
    env["OPENBLAS_NUM_THREADS"] = "1"
    env["MKL_NUM_THREADS"] = "1"
    env["NUMEXPR_NUM_THREADS"] = "1"


    start = time.time()

    try:

        proc = subprocess.run(
            cmd,
            text=True,
            capture_output=True,
            timeout=COMPILE_TIMEOUT,
            env=env,
        )

        elapsed = time.time() - start

        returncode = proc.returncode
        stdout = proc.stdout
        stderr = proc.stderr
        timeout = False

    except subprocess.TimeoutExpired as e:

        elapsed = time.time() - start

        returncode = -999
        stdout = (
            e.stdout.decode(errors="ignore")
            if isinstance(e.stdout, bytes)
            else str(e.stdout or "")
        )
        stderr = (
            e.stderr.decode(errors="ignore")
            if isinstance(e.stderr, bytes)
            else str(e.stderr or "")
        )

        timeout = True


    asm = parse_assembly_files(
        output_dir
    )


    return {
        "success":
            returncode == 0,

        "returncode":
            int(returncode),

        "timed_out":
            bool(timeout),

        "compile_seconds":
            float(elapsed),

        "vmfb_exists":
            bool(vmfb.exists()),

        "vmfb_bytes":
            (
                int(vmfb.stat().st_size)
                if vmfb.exists()
                else 0
            ),

        "stdout_tail":
            stdout[-1000:],

        "stderr_tail":
            stderr[-4000:],

        **asm,
    }


# ============================================================
# One program worker
# ============================================================

def process_program(record):

    dt1_id = str(
        record["dt1_id"]
    )

    mlir_path = Path(
        record["mlir_path"]
    )

    program_root = (
        DUMP_ROOT / dt1_id
    )


    scalar = compile_configuration(
        mlir_path=mlir_path,

        output_dir=(
            program_root / "scalar"
        ),

        cpu_features=SCALAR_FEATURES,
    )


    rvv = compile_configuration(
        mlir_path=mlir_path,

        output_dir=(
            program_root / "rvv"
        ),

        cpu_features=RVV_FEATURES,
    )


    compiler_comparable = (
        scalar["success"]
        and rvv["success"]
        and scalar["total_instructions"] > 0
        and rvv["total_instructions"] > 0
    )


    reduction_pct = None
    reduction_abs = None
    rvv_benefit = None

    if compiler_comparable:

        reduction_abs = (
            scalar["total_instructions"]
            - rvv["total_instructions"]
        )

        reduction_pct = (
            reduction_abs
            / scalar["total_instructions"]
            * 100.0
        )

        # Frozen before final model evaluation.
        if reduction_pct < 5.0:
            rvv_benefit = "LOW"

        elif reduction_pct < 15.0:
            rvv_benefit = "MEDIUM"

        else:
            rvv_benefit = "HIGH"


    result = {
        "dt1_id": dt1_id,

        "mlir_hash":
            str(record["mlir_hash"]),

        "mlir_path":
            str(mlir_path),

        "row_count":
            int(record["row_count"]),

        "family_count":
            int(record["family_count"]),

        "families":
            str(record["families"]),

        "semantic_labels":
            str(record["semantic_labels"]),

        "program_ids":
            str(record["program_ids"]),


        # ---------------------------------------------
        # Scalar
        # ---------------------------------------------

        "scalar_success":
            scalar["success"],

        "scalar_returncode":
            scalar["returncode"],

        "scalar_timed_out":
            scalar["timed_out"],

        "scalar_compile_seconds":
            scalar["compile_seconds"],

        "scalar_instruction_count":
            scalar["total_instructions"],

        "scalar_assembly_file_count":
            scalar["assembly_file_count"],

        "scalar_assembly_bytes":
            scalar["assembly_bytes"],

        "scalar_vmfb_bytes":
            scalar["vmfb_bytes"],

        "scalar_stderr":
            scalar["stderr_tail"],


        # ---------------------------------------------
        # RVV
        # ---------------------------------------------

        "rvv_success":
            rvv["success"],

        "rvv_returncode":
            rvv["returncode"],

        "rvv_timed_out":
            rvv["timed_out"],

        "rvv_compile_seconds":
            rvv["compile_seconds"],

        "rvv_instruction_count":
            rvv["total_instructions"],

        "rvv_vector_instruction_count":
            rvv["rvv_instructions"],

        "rvv_opcodes":
            rvv["rvv_opcodes"],

        "rvv_assembly_file_count":
            rvv["assembly_file_count"],

        "rvv_assembly_bytes":
            rvv["assembly_bytes"],

        "rvv_vmfb_bytes":
            rvv["vmfb_bytes"],

        "rvv_stderr":
            rvv["stderr_tail"],


        # ---------------------------------------------
        # Comparison
        # ---------------------------------------------

        "compiler_comparable":
            bool(compiler_comparable),

        "instruction_reduction":
            reduction_abs,

        "reduction_pct":
            reduction_pct,

        "rvv_benefit":
            rvv_benefit,

        "rvv_vectorization_realized":
            bool(
                rvv["success"]
                and rvv["rvv_instructions"] > 0
            ),
    }

    return result


# ============================================================
# Atomic checkpoint save
# ============================================================

def save_results(results_by_id):

    rows = [
        results_by_id[k]
        for k in sorted(results_by_id)
    ]

    df = pd.DataFrame(rows)

    tmp = OUTPUT_PATH.with_suffix(
        ".csv.tmp"
    )

    df.to_csv(
        tmp,
        index=False,
    )

    tmp.replace(
        OUTPUT_PATH
    )


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":

    DUMP_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    OUTPUT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )


    manifest = pd.read_csv(
        MANIFEST_PATH
    )


    print("=" * 80)
    print("DT1 FULL RISC-V / RVV CODEGEN")
    print("=" * 80)

    print("Programs:", len(manifest))
    print("Workers:", MAX_WORKERS)
    print("Timeout/program/config:", COMPILE_TIMEOUT, "sec")
    print("Results:", OUTPUT_PATH)
    print("Codegen:", DUMP_ROOT)


    # --------------------------------------------------------
    # Resume support
    # --------------------------------------------------------

    results_by_id = {}

    if OUTPUT_PATH.exists():

        old = pd.read_csv(
            OUTPUT_PATH
        )

        for _, row in old.iterrows():

            results_by_id[
                str(row["dt1_id"])
            ] = row.to_dict()

        print(
            "\nExisting completed results:",
            len(results_by_id),
        )


    pending = []

    for _, row in manifest.iterrows():

        dt1_id = str(
            row["dt1_id"]
        )

        if dt1_id not in results_by_id:
            pending.append(
                row.to_dict()
            )


    print(
        "Pending programs:",
        len(pending),
    )


    if not pending:

        print("\nNothing to do.")

    else:

        start_all = time.time()

        with ProcessPoolExecutor(
            max_workers=MAX_WORKERS
        ) as executor:

            futures = {
                executor.submit(
                    process_program,
                    record,
                ):
                str(record["dt1_id"])

                for record in pending
            }


            completed_this_run = 0

            for future in as_completed(futures):

                dt1_id = futures[future]

                completed_this_run += 1

                try:

                    result = future.result()

                except Exception as e:

                    print(
                        f"\nERROR {dt1_id}: "
                        f"{type(e).__name__}: {e}",
                        flush=True,
                    )

                    continue


                results_by_id[
                    dt1_id
                ] = result


                # Save after EVERY completed program.
                save_results(
                    results_by_id
                )


                status = (
                    "OK"
                    if result["compiler_comparable"]
                    else "NOT-COMPARABLE"
                )

                reduction = (
                    f"{result['reduction_pct']:.3f}%"
                    if result["reduction_pct"]
                    is not None
                    else "n/a"
                )

                print(
                    f"[{completed_this_run:04d}/"
                    f"{len(pending):04d}] "
                    f"{dt1_id} "
                    f"{status} "
                    f"scalar="
                    f"{result['scalar_instruction_count']} "
                    f"rvv="
                    f"{result['rvv_instruction_count']} "
                    f"vec="
                    f"{result['rvv_vector_instruction_count']} "
                    f"reduction={reduction} "
                    f"class="
                    f"{result['rvv_benefit']}",
                    flush=True,
                )


        elapsed_all = (
            time.time() - start_all
        )

        print(
            "\nCompilation wall time:",
            f"{elapsed_all:.2f} sec",
        )


    # ========================================================
    # Final summary
    # ========================================================

    df = pd.read_csv(
        OUTPUT_PATH
    )

    comparable = df[
        df["compiler_comparable"]
        .astype(str)
        .str.lower()
        .eq("true")
    ].copy()


    summary = {
        "unique_programs":
            int(len(df)),

        "scalar_success":
            int(df["scalar_success"].sum()),

        "rvv_success":
            int(df["rvv_success"].sum()),

        "compiler_comparable":
            int(len(comparable)),

        "rvv_vectorization_realized":
            int(
                df[
                    "rvv_vectorization_realized"
                ].sum()
            ),

        "benefit_counts": {
            str(k): int(v)
            for k, v in
            comparable["rvv_benefit"]
            .value_counts()
            .to_dict()
            .items()
        },
    }


    if len(comparable):

        summary[
            "reduction_pct_statistics"
        ] = {
            str(k): float(v)

            for k, v in
            comparable["reduction_pct"]
            .describe()
            .to_dict()
            .items()
        }


    with SUMMARY_PATH.open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            summary,
            f,
            indent=2,
        )


    print("\n" + "=" * 80)
    print("FINAL SUMMARY")
    print("=" * 80)

    print(json.dumps(
        summary,
        indent=2,
    ))

    print("\nSaved:")
    print(OUTPUT_PATH)
    print(SUMMARY_PATH)
