import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from transformers import (
    AutoConfig,
    AutoTokenizer,
)

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

DATA = ROOT / "data" / "splits_v2"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from dt1_common import (
    CLASSES,
    few_shot_prompt,
    target_text,
    task_text,
    zero_shot_prompt,
)


MODEL = (
    "Qwen/Qwen2.5-Coder-14B-Instruct"
)

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 256


def load(name):

    with (
        DATA / f"{name}.json"
    ).open() as f:

        return pd.DataFrame(
            json.load(f)
        )


train = load("train")
val = load("val")
test = load("test")


tokenizer = (
    AutoTokenizer.from_pretrained(
        MODEL,
        trust_remote_code=True,
    )
)

config = (
    AutoConfig.from_pretrained(
        MODEL,
        trust_remote_code=True,
    )
)


def ntokens(text):

    return len(
        tokenizer(
            text,
            add_special_tokens=False,
        )["input_ids"]
    )


def report(
    name,
    values,
):

    a = np.asarray(values)

    print("\n" + name)

    print("  n:   ", len(a))
    print("  min: ", int(a.min()))
    print(
        "  mean:",
        round(float(a.mean()), 2),
    )
    print(
        "  p50: ",
        int(
            np.percentile(
                a,
                50,
            )
        ),
    )
    print(
        "  p95: ",
        int(
            np.percentile(
                a,
                95,
            )
        ),
    )
    print(
        "  max: ",
        int(a.max()),
    )


print("=" * 72)
print("DT1 MODEL PREFLIGHT")
print("=" * 72)

print("Model:", MODEL)

print(
    "max_position_embeddings:",
    getattr(
        config,
        "max_position_embeddings",
        "unknown",
    ),
)

print("Train:", len(train))
print("Val:", len(val))
print("Test:", len(test))


# ============================================================
# Zero-shot
# ============================================================

zero_lengths = [
    ntokens(
        zero_shot_prompt(
            tokenizer,
            row,
        )
    )
    for _, row
    in test.iterrows()
]

report(
    "ZERO-SHOT TEST PROMPTS",
    zero_lengths,
)

assert (
    max(zero_lengths)
    + MAX_NEW_TOKENS
    <= MAX_SEQ_LEN
)


# ============================================================
# Few-shot
#
# One demonstration per compiler-grounded class.
# ============================================================

def select_examples(seed):

    examples = []

    for label in CLASSES:

        subset = train[
            train["rvv_plan_class"]
            == label
        ].copy()

        if subset.empty:
            raise RuntimeError(
                f"No training example for {label}"
            )

        subset["mlir_chars"] = (
            subset["mutated_mlir"]
            .astype(str)
            .str.len()
        )

        pool = (
            subset
            .sort_values("mlir_chars")
            .head(
                min(
                    10,
                    len(subset),
                )
            )
        )

        examples.append(
            pool.sample(
                n=1,
                random_state=seed,
            ).iloc[0]
        )

    return examples


for seed in [42, 123]:

    examples = select_examples(
        seed
    )

    print(
        "\n"
        + "=" * 72
    )

    print(
        f"4-SHOT EXAMPLES, SEED {seed}"
    )

    print(
        "=" * 72
    )

    for ex in examples:

        print(
            ex["dt1_id"],
            ex["base_family"],
            ex["rvv_plan_class"],
        )


    lengths = [
        ntokens(
            few_shot_prompt(
                tokenizer,
                row,
                examples,
            )
        )
        for _, row
        in test.iterrows()
    ]

    report(
        f"4-SHOT TEST PROMPTS SEED {seed}",
        lengths,
    )

    assert (
        max(lengths)
        + MAX_NEW_TOKENS
        <= MAX_SEQ_LEN
    )


# ============================================================
# SFT full sequence
# ============================================================

combined = pd.concat(
    [
        train.assign(
            _split="train"
        ),
        val.assign(
            _split="val"
        ),
    ],
    ignore_index=True,
)


sft_lengths = []
prefix_failures = []


for _, row in combined.iterrows():

    prompt_messages = [
        {
            "role": "user",
            "content": task_text(row),
        }
    ]

    full_messages = (
        prompt_messages
        + [
            {
                "role": "assistant",
                "content":
                    target_text(row),
            }
        ]
    )


    prompt_text = (
        tokenizer.apply_chat_template(
            prompt_messages,
            tokenize=False,
            add_generation_prompt=True,
        )
    )

    full_text = (
        tokenizer.apply_chat_template(
            full_messages,
            tokenize=False,
            add_generation_prompt=False,
        )
    )


    prompt_ids = tokenizer(
        prompt_text,
        add_special_tokens=False,
    )["input_ids"]

    full_ids = tokenizer(
        full_text,
        add_special_tokens=False,
    )["input_ids"]


    sft_lengths.append(
        len(full_ids)
    )


    if (
        full_ids[
            :len(prompt_ids)
        ]
        != prompt_ids
    ):

        prefix_failures.append(
            (
                row["_split"],
                row["dt1_id"],
            )
        )


report(
    "SFT TRAIN + VALIDATION",
    sft_lengths,
)


print(
    "\nSFT prefix failures:",
    len(prefix_failures),
)


assert (
    max(sft_lengths)
    <= MAX_SEQ_LEN
)

assert (
    len(prefix_failures)
    == 0
)


print(
    "\n"
    + "=" * 72
)

print("PREFLIGHT PASSED")

print("=" * 72)
