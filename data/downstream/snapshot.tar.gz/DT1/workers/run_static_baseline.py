import json
import sys
from pathlib import Path

import pandas as pd
from sklearn.ensemble import RandomForestClassifier

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from dt1_common import (
    CLASSES,
    metrics_dict,
    static_features,
)


DATA = ROOT / "data" / "splits_v2"
OUT = ROOT / "outputs"

OUT.mkdir(
    parents=True,
    exist_ok=True,
)


def load(name):
    with (
        DATA / f"{name}.json"
    ).open() as f:
        return pd.DataFrame(
            json.load(f)
        )


train = load("train")
val = load("val")
test = load("test")


FEATURE_COLUMNS = sorted(
    static_features(
        train.iloc[0]["mutated_mlir"]
    ).keys()
)


def matrix(df):

    rows = [
        static_features(x)
        for x in df["mutated_mlir"]
    ]

    return pd.DataFrame(
        rows
    )[FEATURE_COLUMNS]


X_train = matrix(train)
X_val = matrix(val)
X_test = matrix(test)

y_train = train["rvv_plan_class"]
y_val = val["rvv_plan_class"]
y_test = test["rvv_plan_class"]


print("=" * 72)
print("DT1 STATIC STRUCTURAL BASELINE")
print("=" * 72)

print("Train:", len(train))
print("Validation:", len(val))
print("Test:", len(test))

print("\nFeatures:")
print(FEATURE_COLUMNS)


model = RandomForestClassifier(
    n_estimators=500,
    class_weight="balanced",
    random_state=42,
    n_jobs=-1,
)

model.fit(
    X_train,
    y_train,
)


val_pred = model.predict(
    X_val
)

test_pred = model.predict(
    X_test
)


val_metrics = metrics_dict(
    y_val,
    val_pred,
)

test_metrics = metrics_dict(
    y_test,
    test_pred,
)


print("\nVALIDATION")
print(
    json.dumps(
        val_metrics,
        indent=2,
    )
)

print("\nTEST")
print(
    json.dumps(
        test_metrics,
        indent=2,
    )
)


result = test.copy()

result[
    "prediction"
] = test_pred

result[
    "correct"
] = (
    result["prediction"]
    == result["rvv_plan_class"]
)

result.to_csv(
    OUT
    / "static_baseline_test_predictions.csv",
    index=False,
)


with (
    OUT
    / "static_baseline_metrics.json"
).open(
    "w",
    encoding="utf-8",
) as f:

    json.dump(
        {
            "model":
                "RandomForestClassifier",

            "features":
                FEATURE_COLUMNS,

            "validation":
                val_metrics,

            "test":
                test_metrics,
        },
        f,
        indent=2,
    )


importance = pd.DataFrame(
    {
        "feature":
            FEATURE_COLUMNS,

        "importance":
            model.feature_importances_,
    }
).sort_values(
    "importance",
    ascending=False,
)

importance.to_csv(
    OUT
    / "static_baseline_feature_importance.csv",
    index=False,
)

print("\nFeature importance:")
print(
    importance.head(15)
    .to_string(index=False)
)

print("\nSaved baseline outputs.")
