import json
import re

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
)

CLASSES = [
    "UNSUPPORTED",
    "LOW",
    "MEDIUM",
    "HIGH",
]

SUPPORTED_CLASSES = [
    "LOW",
    "MEDIUM",
    "HIGH",
]

ORDINAL = {
    "LOW": 0,
    "MEDIUM": 1,
    "HIGH": 2,
}


# ============================================================
# Static features
# ============================================================

def static_features(mlir):
    text = str(mlir)

    lines = [
        x for x in text.splitlines()
        if x.strip()
    ]

    lower = text.lower()

    features = {
        "chars": len(text),
        "lines": len(lines),

        "linalg_ops": lower.count("linalg."),
        "arith_ops": lower.count("arith."),
        "tensor_ops": lower.count("tensor."),
        "scf_ops": lower.count("scf."),
        "memref_ops": lower.count("memref."),
        "math_ops": lower.count("math."),
        "vector_ops": lower.count("vector."),

        "reduce_tokens":
            lower.count("reduce")
            + lower.count("reduction"),

        "generic_ops":
            lower.count("linalg.generic"),

        "fill_ops":
            lower.count("linalg.fill"),

        "matmul_ops":
            lower.count("matmul"),

        "extract_slice":
            lower.count("tensor.extract_slice"),

        "insert_slice":
            lower.count("tensor.insert_slice"),

        "extract_ops":
            lower.count("tensor.extract"),

        "insert_ops":
            lower.count("tensor.insert"),

        "affine_tokens":
            lower.count("affine."),

        "for_tokens":
            lower.count("scf.for"),

        "while_tokens":
            lower.count("scf.while"),

        "parallel_tokens":
            lower.count("parallel"),

        "index_cast":
            lower.count("index_cast"),

        "cmp_tokens":
            lower.count("cmp"),

        "select_tokens":
            lower.count("select"),

        "f32_tokens":
            lower.count("f32"),

        "f64_tokens":
            lower.count("f64"),

        "i1_tokens":
            lower.count("i1"),

        "i32_tokens":
            lower.count("i32"),

        "i64_tokens":
            lower.count("i64"),
    }

    return features


def feature_text(mlir):
    f = static_features(mlir)

    ordered = [
        "chars",
        "lines",
        "linalg_ops",
        "arith_ops",
        "tensor_ops",
        "scf_ops",
        "memref_ops",
        "reduce_tokens",
        "generic_ops",
        "extract_slice",
        "insert_slice",
        "for_tokens",
    ]

    return "\n".join(
        f"{key}: {f[key]}"
        for key in ordered
    )


# ============================================================
# Planner output
# ============================================================

def plan_for_class(plan_class):

    if plan_class == "UNSUPPORTED":
        return {
            "optimization_label":
                "AVOID_RVV",

            "recommended_passes":
                [
                    "canonicalize",
                    "cse",
                ],

            "rvv_expected_benefit":
                "UNSUPPORTED",

            "reason":
                (
                    "The static MLIR is predicted not to "
                    "produce a successful comparable scalar "
                    "and RVV RISC-V backend result."
                ),
        }

    if plan_class == "LOW":
        return {
            "optimization_label":
                "KEEP_SCALAR",

            "recommended_passes":
                [
                    "canonicalize",
                    "cse",
                ],

            "rvv_expected_benefit":
                "LOW",

            "reason":
                (
                    "The static structure is predicted to "
                    "provide less than 5% RVV static "
                    "instruction-count reduction."
                ),
        }

    if plan_class == "MEDIUM":
        return {
            "optimization_label":
                "APPLY_RVV",

            "recommended_passes":
                [
                    "canonicalize",
                    "cse",
                    "enable-rvv-vectorization",
                ],

            "rvv_expected_benefit":
                "MEDIUM",

            "reason":
                (
                    "The static structure is predicted to "
                    "provide moderate RVV code-generation "
                    "benefit."
                ),
        }

    if plan_class == "HIGH":
        return {
            "optimization_label":
                "APPLY_RVV",

            "recommended_passes":
                [
                    "canonicalize",
                    "cse",
                    "enable-rvv-vectorization",
                ],

            "rvv_expected_benefit":
                "HIGH",

            "reason":
                (
                    "The static structure is predicted to "
                    "provide substantial RVV code-generation "
                    "benefit."
                ),
        }

    raise ValueError(
        f"Unknown plan class: {plan_class}"
    )


def target_text(row):
    return json.dumps(
        plan_for_class(
            str(row["rvv_plan_class"])
        ),
        separators=(",", ":"),
    )


# ============================================================
# Prompt
# ============================================================

def task_text(row):

    mlir = str(row["mutated_mlir"])

    return (
        "You are a compiler optimization planner for a "
        "64-bit RISC-V target.\n\n"

        "The baseline target uses scalar RISC-V extensions:\n"
        "+m,+a,+f,+d,+c\n\n"

        "The alternative target enables the RISC-V Vector "
        "Extension:\n"
        "+m,+a,+f,+d,+c,+zvl512b,+v\n\n"

        "Using only the static MLIR program and the derived "
        "static features below, predict its compiler-grounded "
        "RVV planning class.\n\n"

        "Classes:\n"
        "UNSUPPORTED: a successful comparable scalar/RVV "
        "RISC-V backend result is unavailable.\n"
        "LOW: RVV static instruction-count reduction is "
        "less than 5%.\n"
        "MEDIUM: RVV reduction is at least 5% but less "
        "than 15%.\n"
        "HIGH: RVV reduction is at least 15%.\n\n"

        "Return valid JSON with exactly these fields:\n"
        "optimization_label\n"
        "recommended_passes\n"
        "rvv_expected_benefit\n"
        "reason\n\n"

        "optimization_label must be one of:\n"
        "AVOID_RVV, KEEP_SCALAR, APPLY_RVV\n\n"

        "rvv_expected_benefit must be one of:\n"
        "UNSUPPORTED, LOW, MEDIUM, HIGH\n\n"

        "Do not assume that vector instructions automatically "
        "reduce static instruction count.\n\n"

        "Static features:\n"
        f"{feature_text(mlir)}\n\n"

        "MLIR:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```"
    )


def zero_shot_prompt(tokenizer, row):
    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content": task_text(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


def few_shot_prompt(
    tokenizer,
    row,
    examples,
):
    messages = []

    for ex in examples:
        messages.append(
            {
                "role": "user",
                "content": task_text(ex),
            }
        )

        messages.append(
            {
                "role": "assistant",
                "content": target_text(ex),
            }
        )

    messages.append(
        {
            "role": "user",
            "content": task_text(row),
        }
    )

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


# ============================================================
# Prediction extraction
# ============================================================

def extract_class(output):

    if output is None:
        return "INVALID"

    text = str(output).strip()

    if not text:
        return "INVALID"

    # Prefer proper JSON.
    try:
        data = json.loads(text)

        value = str(
            data.get(
                "rvv_expected_benefit",
                "",
            )
        ).upper()

        if value in CLASSES:
            return value

    except Exception:
        pass

    # Try to recover JSON embedded around extra text.
    match = re.search(
        r"\{.*\}",
        text,
        flags=re.DOTALL,
    )

    if match:
        try:
            data = json.loads(
                match.group(0)
            )

            value = str(
                data.get(
                    "rvv_expected_benefit",
                    "",
                )
            ).upper()

            if value in CLASSES:
                return value

        except Exception:
            pass

    upper = text.upper()

    # Look for explicit class tokens.
    for label in CLASSES:
        if re.search(
            rf"\b{label}\b",
            upper,
        ):
            return label

    return "INVALID"


# ============================================================
# Metrics
# ============================================================

def metrics_dict(
    y_true,
    y_pred,
):

    y_true = list(y_true)
    y_pred = list(y_pred)

    overall_accuracy = accuracy_score(
        y_true,
        y_pred,
    )

    overall_macro_f1 = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average="macro",
        zero_division=0,
    )

    per_class = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average=None,
        zero_division=0,
    )

    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=CLASSES + ["INVALID"],
    )


    # --------------------------------------------------------
    # Supported-program metrics
    # --------------------------------------------------------

    supported_idx = [
        i
        for i, gold in enumerate(y_true)
        if gold in SUPPORTED_CLASSES
    ]

    supported_true = [
        y_true[i]
        for i in supported_idx
    ]

    supported_pred = [
        y_pred[i]
        for i in supported_idx
    ]


    if supported_true:

        supported_accuracy = (
            accuracy_score(
                supported_true,
                supported_pred,
            )
        )

        supported_macro_f1 = (
            f1_score(
                supported_true,
                supported_pred,
                labels=SUPPORTED_CLASSES,
                average="macro",
                zero_division=0,
            )
        )


        distances = []

        severe = 0
        within_one = 0
        predicted_unsupported = 0

        for gold, pred in zip(
            supported_true,
            supported_pred,
        ):

            if pred not in ORDINAL:
                # Conservative maximum ordinal penalty.
                distances.append(2)
                predicted_unsupported += 1
                continue

            distance = abs(
                ORDINAL[gold]
                - ORDINAL[pred]
            )

            distances.append(distance)

            if distance == 2:
                severe += 1

            if distance <= 1:
                within_one += 1


        ordinal_mae = float(
            np.mean(distances)
        )

        severe_rate = (
            severe
            / len(supported_true)
        )

        within_one_rate = (
            within_one
            / len(supported_true)
        )

        false_unsupported_rate = (
            predicted_unsupported
            / len(supported_true)
        )

    else:

        supported_accuracy = None
        supported_macro_f1 = None
        ordinal_mae = None
        severe_rate = None
        within_one_rate = None
        false_unsupported_rate = None


    unsupported_total = sum(
        x == "UNSUPPORTED"
        for x in y_true
    )

    unsupported_correct = sum(
        gold == "UNSUPPORTED"
        and pred == "UNSUPPORTED"
        for gold, pred in zip(
            y_true,
            y_pred,
        )
    )

    unsupported_recall = (
        unsupported_correct
        / unsupported_total
        if unsupported_total
        else None
    )


    return {
        "n":
            int(len(y_true)),

        "accuracy":
            float(overall_accuracy),

        "macro_f1":
            float(overall_macro_f1),

        "per_class_f1": {
            label: float(score)
            for label, score
            in zip(
                CLASSES,
                per_class,
            )
        },

        "invalid_count":
            int(
                sum(
                    x == "INVALID"
                    for x in y_pred
                )
            ),

        "unsupported_recall":
            (
                float(unsupported_recall)
                if unsupported_recall
                is not None
                else None
            ),

        "supported_n":
            int(len(supported_true)),

        "supported_accuracy":
            (
                float(supported_accuracy)
                if supported_accuracy
                is not None
                else None
            ),

        "supported_macro_f1":
            (
                float(supported_macro_f1)
                if supported_macro_f1
                is not None
                else None
            ),

        "supported_ordinal_mae":
            ordinal_mae,

        "supported_severe_error_rate":
            (
                float(severe_rate)
                if severe_rate
                is not None
                else None
            ),

        "supported_within_one_class":
            (
                float(within_one_rate)
                if within_one_rate
                is not None
                else None
            ),

        "false_unsupported_rate":
            (
                float(false_unsupported_rate)
                if false_unsupported_rate
                is not None
                else None
            ),

        "confusion_matrix_labels":
            CLASSES + ["INVALID"],

        "confusion_matrix":
            cm.tolist(),
    }
