import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

CODEGEN = ROOT / "outputs" / "riscv_codegen_results.csv"
CORPUS = ROOT / "data" / "corpus_rows.csv"

OUT = ROOT / "data" / "splits"
OUT.mkdir(parents=True, exist_ok=True)

SEED = 42


# ============================================================
# Load compiler results
# ============================================================

codegen = pd.read_csv(CODEGEN)

# Be robust to CSV boolean parsing.
codegen["compiler_comparable"] = (
    codegen["compiler_comparable"]
    .astype(str)
    .str.lower()
    .eq("true")
)

valid = codegen[
    codegen["compiler_comparable"]
].copy()

print("=" * 80)
print("DT1 FINAL FAMILY-DISJOINT SPLIT")
print("=" * 80)

print("\nCompiler results:", len(codegen))
print("Compiler-comparable:", len(valid))


# ============================================================
# Each unique MLIR belongs to exactly one family.
# We already verified there are no duplicate MLIR hashes
# spanning multiple source families.
# ============================================================

def get_family(text):
    families = [
        x.strip()
        for x in str(text).split(";")
        if x.strip()
    ]

    if len(families) != 1:
        raise RuntimeError(
            f"Expected exactly one family, got: {families}"
        )

    return families[0]


valid["base_family"] = (
    valid["families"]
    .apply(get_family)
)


# ============================================================
# Recover MLIR text + representative benchmark metadata
# ============================================================

corpus = pd.read_csv(CORPUS)

# All exact duplicates belong to the same family.
# Pick one representative row per unique MLIR hash for
# descriptive metadata only. The RISC-V target is attached
# to the unique MLIR program, not to the semantic label.
representative = (
    corpus
    .sort_values(["mlir_hash", "program_id"])
    .drop_duplicates(
        subset=["mlir_hash"],
        keep="first",
    )
    [
        [
            "mlir_hash",
            "program_id",
            "semantic_label",
            "level",
            "requirement_id",
            "requirement_description",
            "mutated_mlir",
        ]
    ]
)

df = valid.merge(
    representative,
    on="mlir_hash",
    how="left",
    validate="one_to_one",
)

if df["mutated_mlir"].isna().any():
    raise RuntimeError(
        "Some compiler results could not be mapped back "
        "to their source MLIR."
    )


# Preserve the full semantic-label set from unique_programs.
# Almost all programs have exactly one label. A rare exact
# duplicate can occur under multiple MLIRBench relationships.
df["semantic_label_set"] = df["semantic_labels"]


# ============================================================
# Freeze target fields
# ============================================================

allowed = {"LOW", "MEDIUM", "HIGH"}

bad = set(df["rvv_benefit"]) - allowed

if bad:
    raise RuntimeError(
        f"Unexpected RVV benefit labels: {bad}"
    )


def optimization_label(benefit):
    # A 5% minimum-benefit threshold is frozen before
    # model evaluation.
    if benefit == "LOW":
        return "KEEP_SCALAR"

    return "APPLY_RVV"


df["optimization_label"] = (
    df["rvv_benefit"]
    .apply(optimization_label)
)


# Same four-field interface as the original DT1.
#
# recommended_passes represents the planning interface.
# Actual evaluation maps APPLY_RVV to RVV-enabled compilation
# and KEEP_SCALAR to scalar RISC-V compilation.
def target_json(row):
    if row["optimization_label"] == "APPLY_RVV":
        passes = [
            "canonicalize",
            "cse",
            "enable-rvv-vectorization",
        ]
    else:
        passes = [
            "canonicalize",
            "cse",
        ]

    return json.dumps(
        {
            "optimization_label":
                row["optimization_label"],

            "recommended_passes":
                passes,

            "rvv_expected_benefit":
                row["rvv_benefit"],

            # Reason is intentionally not generated as part of
            # compiler ground truth. The model will produce an
            # explanatory reason from static structure.
            "reason":
                "",
        },
        separators=(",", ":"),
    )


df["target_json"] = df.apply(
    target_json,
    axis=1,
)


# ============================================================
# Stratified family-group split
#
# Same 5-fold design used for the revised DT2 experiment:
#
# fold 0 -> test
# fold 1 -> validation
# folds 2-4 -> train
#
# Stratify on compiler-grounded RVV benefit.
# Group by source-program family.
# ============================================================

splitter = StratifiedGroupKFold(
    n_splits=5,
    shuffle=True,
    random_state=SEED,
)

folds = [None] * len(df)

for fold, (_, fold_indices) in enumerate(
    splitter.split(
        X=df,
        y=df["rvv_benefit"],
        groups=df["base_family"],
    )
):
    for idx in fold_indices:
        folds[idx] = fold

df["fold"] = folds

if df["fold"].isna().any():
    raise RuntimeError(
        "Not every program received a fold."
    )


test = df[df["fold"] == 0].copy()
val = df[df["fold"] == 1].copy()
train = df[df["fold"].isin([2, 3, 4])].copy()


# ============================================================
# Verify family separation
# ============================================================

train_f = set(train["base_family"])
val_f = set(val["base_family"])
test_f = set(test["base_family"])

overlap = {
    "train_val": len(train_f & val_f),
    "train_test": len(train_f & test_f),
    "val_test": len(val_f & test_f),
}

if any(overlap.values()):
    raise RuntimeError(
        f"FAMILY LEAKAGE DETECTED: {overlap}"
    )


# Exact MLIR hash separation should follow automatically,
# but verify it explicitly.
train_h = set(train["mlir_hash"])
val_h = set(val["mlir_hash"])
test_h = set(test["mlir_hash"])

hash_overlap = {
    "train_val": len(train_h & val_h),
    "train_test": len(train_h & test_h),
    "val_test": len(val_h & test_h),
}

if any(hash_overlap.values()):
    raise RuntimeError(
        f"MLIR HASH LEAKAGE DETECTED: {hash_overlap}"
    )


# ============================================================
# Reporting
# ============================================================

def report(name, part):

    print("\n" + "=" * 80)
    print(
        f"{name}: {len(part)} programs | "
        f"{part['base_family'].nunique()} families"
    )
    print("=" * 80)

    print("\nBenefit distribution:")
    print(
        part["rvv_benefit"]
        .value_counts()
        .reindex(
            ["LOW", "MEDIUM", "HIGH"],
            fill_value=0,
        )
    )

    print("\nOptimization decision:")
    print(
        part["optimization_label"]
        .value_counts()
    )

    print("\nRepresentative semantic labels:")
    print(
        part["semantic_label"]
        .value_counts()
        .reindex(
            ["EQUIV", "DIVERGE", "ERROR"],
            fill_value=0,
        )
    )

    print("\nLevels:")
    print(
        part["level"]
        .value_counts()
        .sort_index()
    )

    print("\nReduction statistics:")
    print(
        part["reduction_pct"]
        .describe()
    )


report("TRAIN", train)
report("VALIDATION", val)
report("TEST", test)


print("\n" + "=" * 80)
print("LEAKAGE CHECKS")
print("=" * 80)

print("Family overlap:", overlap)
print("MLIR hash overlap:", hash_overlap)


# ============================================================
# Save JSON + CSV
# ============================================================

def save_split(name, part):

    # Stable ordering makes experiments reproducible.
    part = (
        part
        .sort_values(
            ["base_family", "dt1_id"]
        )
        .reset_index(drop=True)
    )

    part.to_csv(
        OUT / f"{name}.csv",
        index=False,
    )

    records = (
        part
        .where(
            pd.notnull(part),
            None,
        )
        .to_dict(orient="records")
    )

    with (
        OUT / f"{name}.json"
    ).open("w", encoding="utf-8") as f:
        json.dump(
            records,
            f,
            indent=2,
        )


save_split("train", train)
save_split("val", val)
save_split("test", test)


# Complete compiler-comparable population.
save_split("all", df)


metadata = {
    "seed": SEED,

    "split_method":
        "StratifiedGroupKFold(n_splits=5, "
        "shuffle=True, random_state=42); "
        "fold0=test, fold1=val, folds2-4=train",

    "stratification_target":
        "rvv_benefit",

    "group":
        "base_family",

    "total_compiler_comparable":
        int(len(df)),

    "train":
        int(len(train)),

    "val":
        int(len(val)),

    "test":
        int(len(test)),

    "family_counts": {
        "all":
            int(df["base_family"].nunique()),

        "train":
            int(train["base_family"].nunique()),

        "val":
            int(val["base_family"].nunique()),

        "test":
            int(test["base_family"].nunique()),
    },

    "benefit_counts": {
        split_name: {
            str(k): int(v)
            for k, v in
            part["rvv_benefit"]
            .value_counts()
            .to_dict()
            .items()
        }
        for split_name, part in [
            ("all", df),
            ("train", train),
            ("val", val),
            ("test", test),
        ]
    },

    "family_overlap":
        overlap,

    "mlir_hash_overlap":
        hash_overlap,

    "thresholds": {
        "LOW":
            "reduction_pct < 5",

        "MEDIUM":
            "5 <= reduction_pct < 15",

        "HIGH":
            "reduction_pct >= 15",
    },

    "optimization_decision": {
        "LOW":
            "KEEP_SCALAR",

        "MEDIUM":
            "APPLY_RVV",

        "HIGH":
            "APPLY_RVV",
    },
}

with (
    OUT / "metadata.json"
).open("w", encoding="utf-8") as f:
    json.dump(
        metadata,
        f,
        indent=2,
    )


print("\nSaved final splits to:")
print(OUT)
print("\nMetadata:")
print(OUT / "metadata.json")
