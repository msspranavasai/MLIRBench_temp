import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch
from peft import PeftModel
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer


ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

DATA = ROOT / "data" / "splits_v2"
ADAPTER = ROOT / "outputs" / "sft" / "adapter"
OUT = ROOT / "outputs"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from dt1_common import (
    extract_class,
    metrics_dict,
    zero_shot_prompt,
)


parser = argparse.ArgumentParser()
parser.add_argument(
    "--split",
    choices=["val", "test"],
    required=True,
)
parser.add_argument(
    "--batch-size",
    type=int,
    default=4,
)
args = parser.parse_args()

SPLIT = args.split
BATCH_SIZE = args.batch_size

MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 256


# ============================================================
# Load split
# ============================================================

with (
    DATA / f"{SPLIT}.json"
).open() as f:
    df = pd.DataFrame(
        json.load(f)
    )


print("=" * 72)
print(
    f"DT1 SFT {SPLIT.upper()} GENERATION"
)
print("=" * 72)

print("Examples:", len(df))

print("\nGold distribution:")
print(
    df["rvv_plan_class"]
    .value_counts()
)


# ============================================================
# Tokenizer
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    ADAPTER,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"


# ============================================================
# Preflight
# ============================================================

prompt_lengths = []

for _, row in df.iterrows():

    prompt = zero_shot_prompt(
        tokenizer,
        row,
    )

    n = len(
        tokenizer(
            prompt,
            add_special_tokens=False,
        )["input_ids"]
    )

    prompt_lengths.append(n)


print("\nPrompt lengths:")
print("Min:", min(prompt_lengths))
print(
    "Mean:",
    sum(prompt_lengths) / len(prompt_lengths),
)
print("Max:", max(prompt_lengths))


if (
    max(prompt_lengths)
    + MAX_NEW_TOKENS
    > MAX_SEQ_LEN
):
    raise RuntimeError(
        "Prompt + generation exceeds context limit."
    )


# ============================================================
# Load base + frozen best adapter
# ============================================================

print("\nLoading base model...")

base = AutoModelForCausalLM.from_pretrained(
    MODEL,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)


print(
    "Loading frozen SFT adapter:",
    ADAPTER,
)

model = PeftModel.from_pretrained(
    base,
    ADAPTER,
)

model.eval()


# ============================================================
# Generation
# ============================================================

predictions = []
raw_outputs = []


for start in tqdm(
    range(
        0,
        len(df),
        BATCH_SIZE,
    ),
    desc=f"DT1 SFT {SPLIT}",
):

    batch = df.iloc[
        start:start + BATCH_SIZE
    ]

    prompts = [
        zero_shot_prompt(
            tokenizer,
            row,
        )
        for _, row
        in batch.iterrows()
    ]


    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to("cuda")


    with torch.inference_mode():

        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )


    input_len = (
        inputs["input_ids"]
        .shape[1]
    )


    for output in outputs:

        raw = tokenizer.decode(
            output[input_len:],
            skip_special_tokens=True,
        ).strip()

        raw_outputs.append(raw)

        predictions.append(
            extract_class(raw)
        )


# ============================================================
# Metrics
# ============================================================

result = df.copy()

result["prediction"] = predictions
result["raw_output"] = raw_outputs

result["correct"] = (
    result["prediction"]
    == result["rvv_plan_class"]
)


metrics = metrics_dict(
    result["rvv_plan_class"],
    result["prediction"],
)

metrics["split"] = SPLIT

metrics["prompt_lengths"] = {
    "min":
        int(min(prompt_lengths)),

    "mean":
        float(
            sum(prompt_lengths)
            / len(prompt_lengths)
        ),

    "max":
        int(max(prompt_lengths)),
}


# ============================================================
# Save
# ============================================================

pred_path = (
    OUT
    / f"sft_{SPLIT}_predictions.csv"
)

metrics_path = (
    OUT
    / f"sft_{SPLIT}_metrics.json"
)


result.to_csv(
    pred_path,
    index=False,
)


with metrics_path.open(
    "w",
    encoding="utf-8",
) as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


# ============================================================
# Report
# ============================================================

print("\n" + "=" * 72)
print(
    f"SFT {SPLIT.upper()} RESULTS"
)
print("=" * 72)

print(
    json.dumps(
        metrics,
        indent=2,
    )
)


print("\nPrediction distribution:")

print(
    result["prediction"]
    .value_counts(
        dropna=False
    )
)


print("\nGold vs prediction:")

print(
    pd.crosstab(
        result["rvv_plan_class"],
        result["prediction"],
        margins=True,
    )
)


print("\nSample raw outputs:")

for _, row in (
    result
    .head(5)
    .iterrows()
):

    print("\n---")
    print(
        "Gold:",
        row["rvv_plan_class"],
    )

    print(
        "Pred:",
        row["prediction"],
    )

    print(
        "Raw:",
        row["raw_output"][:1000],
    )


print("\nSaved:")
print(pred_path)
print(metrics_path)
