import inspect
import json
import os
import sys
from pathlib import Path

import pandas as pd
import torch
from peft import LoraConfig, get_peft_model
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

DATA = ROOT / "data" / "splits_v2"

RUN = ROOT / "outputs" / "sft"
ADAPTER = RUN / "adapter"
CHECKPOINTS = RUN / "checkpoints"

RUN.mkdir(parents=True, exist_ok=True)
ADAPTER.mkdir(parents=True, exist_ok=True)
CHECKPOINTS.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(ROOT / "workers"))

from dt1_common import (
    target_text,
    task_text,
)

MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

MAX_SEQ_LEN = 32768
SEED = 42

NUM_EPOCHS = 3
LEARNING_RATE = 1e-4

PER_DEVICE_TRAIN_BATCH = 1
PER_DEVICE_EVAL_BATCH = 1

GRAD_ACCUM = int(
    os.environ.get(
        "DT1_GRAD_ACCUM_STEPS",
        "1",
    )
)


def load(name):

    with (
        DATA / f"{name}.json"
    ).open() as f:

        return pd.DataFrame(
            json.load(f)
        )


train_df = load("train")
val_df = load("val")


print("=" * 72)
print("DT1 LIGHT SFT")
print("=" * 72)

print("Train:", len(train_df))
print(train_df["rvv_plan_class"].value_counts())

print("\nValidation:", len(val_df))
print(val_df["rvv_plan_class"].value_counts())


tokenizer = AutoTokenizer.from_pretrained(
    MODEL,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "right"


def prompt_messages(row):

    return [
        {
            "role": "user",
            "content": task_text(row),
        }
    ]


def full_messages(row):

    return (
        prompt_messages(row)
        + [
            {
                "role": "assistant",
                "content": target_text(row),
            }
        ]
    )


class DT1Dataset(Dataset):

    def __init__(self, df):

        self.examples = []

        for _, row in df.iterrows():

            p_text = (
                tokenizer.apply_chat_template(
                    prompt_messages(row),
                    tokenize=False,
                    add_generation_prompt=True,
                )
            )

            f_text = (
                tokenizer.apply_chat_template(
                    full_messages(row),
                    tokenize=False,
                    add_generation_prompt=False,
                )
            )

            prompt_ids = tokenizer(
                p_text,
                add_special_tokens=False,
            )["input_ids"]

            encoded = tokenizer(
                f_text,
                add_special_tokens=False,
                truncation=False,
            )

            input_ids = encoded["input_ids"]

            if len(input_ids) > MAX_SEQ_LEN:
                raise RuntimeError(
                    f"Sequence overflow: {len(input_ids)}"
                )

            labels = input_ids.copy()

            if (
                input_ids[:len(prompt_ids)]
                != prompt_ids
            ):
                raise RuntimeError(
                    "Prompt/full token prefix mismatch"
                )

            labels[:len(prompt_ids)] = (
                [-100] * len(prompt_ids)
            )

            self.examples.append(
                {
                    "input_ids":
                        input_ids,

                    "attention_mask":
                        encoded["attention_mask"],

                    "labels":
                        labels,
                }
            )

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.examples[idx]


class Collator:

    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, features):

        max_len = max(
            len(x["input_ids"])
            for x in features
        )

        ids = []
        masks = []
        labels = []

        for x in features:

            pad = (
                max_len
                - len(x["input_ids"])
            )

            ids.append(
                x["input_ids"]
                + [
                    self.tokenizer.pad_token_id
                ] * pad
            )

            masks.append(
                x["attention_mask"]
                + [0] * pad
            )

            labels.append(
                x["labels"]
                + [-100] * pad
            )

        return {
            "input_ids":
                torch.tensor(
                    ids,
                    dtype=torch.long,
                ),

            "attention_mask":
                torch.tensor(
                    masks,
                    dtype=torch.long,
                ),

            "labels":
                torch.tensor(
                    labels,
                    dtype=torch.long,
                ),
        }


train_dataset = DT1Dataset(train_df)
val_dataset = DT1Dataset(val_df)

collator = Collator(tokenizer)


model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    dtype=torch.bfloat16,
    low_cpu_mem_usage=True,
    trust_remote_code=True,
)

model.config.use_cache = False

model.gradient_checkpointing_enable()


lora = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.0,
    bias="none",
    task_type="CAUSAL_LM",

    target_modules=[
        "q_proj",
        "v_proj",
    ],
)

model = get_peft_model(
    model,
    lora,
)

model.print_trainable_parameters()


params = (
    inspect.signature(
        TrainingArguments.__init__
    ).parameters
)


kwargs = {
    "output_dir":
        str(CHECKPOINTS),

    "num_train_epochs":
        NUM_EPOCHS,

    "per_device_train_batch_size":
        PER_DEVICE_TRAIN_BATCH,

    "per_device_eval_batch_size":
        PER_DEVICE_EVAL_BATCH,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "learning_rate":
        LEARNING_RATE,

    "bf16":
        True,

    "logging_steps":
        5,

    "save_strategy":
        "epoch",

    "save_total_limit":
        2,

    "report_to":
        "none",

    "seed":
        SEED,

    "ddp_find_unused_parameters":
        False,

    "remove_unused_columns":
        False,

    "gradient_checkpointing":
        True,
}


if "eval_strategy" in params:
    kwargs["eval_strategy"] = "epoch"

elif "evaluation_strategy" in params:
    kwargs["evaluation_strategy"] = "epoch"

else:
    raise RuntimeError(
        "Installed transformers has no evaluation strategy argument"
    )


kwargs["load_best_model_at_end"] = True
kwargs["metric_for_best_model"] = "eval_loss"
kwargs["greater_is_better"] = False


if "warmup_steps" in params:
    kwargs["warmup_steps"] = 20


training_args = TrainingArguments(
    **kwargs
)


trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    data_collator=collator,
)


trainer.train()


trainer.save_model(
    str(ADAPTER)
)


if trainer.is_world_process_zero():

    tokenizer.save_pretrained(
        str(ADAPTER)
    )

    metadata = {
        "model":
            MODEL,

        "train_examples":
            len(train_df),

        "val_examples":
            len(val_df),

        "epochs":
            NUM_EPOCHS,

        "learning_rate":
            LEARNING_RATE,

        "lora_r":
            16,

        "lora_alpha":
            32,

        "target_modules":
            ["q_proj", "v_proj"],

        "best_model_checkpoint":
            trainer.state.best_model_checkpoint,

        "best_eval_loss":
            trainer.state.best_metric,

        "gradient_accumulation_steps":
            GRAD_ACCUM,
    }

    with (
        RUN
        / "training_metadata.json"
    ).open("w") as f:

        json.dump(
            metadata,
            f,
            indent=2,
        )

    print(
        "Saved adapter:",
        ADAPTER,
    )
