import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

DATA = ROOT / "data" / "splits_v2"
OUT = ROOT / "outputs"

sys.path.insert(0, str(ROOT / "workers"))

from dt1_common import (
    CLASSES,
    extract_class,
    few_shot_prompt,
    metrics_dict,
)

parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, required=True)
args = parser.parse_args()

SEED = args.seed

MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 256
BATCH_SIZE = 2


def load(name):
    with (
        DATA / f"{name}.json"
    ).open() as f:

        return pd.DataFrame(
            json.load(f)
        )


train = load("train")
test = load("test")


# ------------------------------------------------------------
# Select one training example per class.
# Prefer short programs, then deterministically sample among
# the 10 shortest so different seeds produce different demos.
# ------------------------------------------------------------

examples = []

for label in CLASSES:

    subset = train[
        train["rvv_plan_class"] == label
    ].copy()

    if subset.empty:
        raise RuntimeError(
            f"No train example for {label}"
        )

    subset["mlir_chars"] = (
        subset["mutated_mlir"]
        .astype(str)
        .str.len()
    )

    pool = (
        subset
        .sort_values("mlir_chars")
        .head(min(10, len(subset)))
    )

    examples.append(
        pool.sample(
            n=1,
            random_state=SEED,
        ).iloc[0]
    )


print("4-shot demonstrations:")

for ex in examples:
    print(
        ex["dt1_id"],
        ex["base_family"],
        ex["rvv_plan_class"],
    )


tokenizer = AutoTokenizer.from_pretrained(
    MODEL,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"


# ------------------------------------------------------------
# Prompt preflight
# ------------------------------------------------------------

lengths = []

for _, row in test.iterrows():

    prompt = few_shot_prompt(
        tokenizer,
        row,
        examples,
    )

    lengths.append(
        len(
            tokenizer(
                prompt,
                add_special_tokens=False,
            )["input_ids"]
        )
    )


print("Prompt max:", max(lengths))

if max(lengths) + MAX_NEW_TOKENS > MAX_SEQ_LEN:
    raise RuntimeError("Context overflow")


# ------------------------------------------------------------
# Model
# ------------------------------------------------------------

model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model.eval()


predictions = []
raw_outputs = []


for start in tqdm(
    range(0, len(test), BATCH_SIZE),
    desc=f"DT1 4-shot seed {SEED}",
):

    batch = test.iloc[
        start:start + BATCH_SIZE
    ]

    prompts = [
        few_shot_prompt(
            tokenizer,
            row,
            examples,
        )
        for _, row in batch.iterrows()
    ]

    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to("cuda")

    with torch.inference_mode():

        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    input_len = (
        inputs["input_ids"].shape[1]
    )

    for output in outputs:

        raw = tokenizer.decode(
            output[input_len:],
            skip_special_tokens=True,
        ).strip()

        raw_outputs.append(raw)
        predictions.append(
            extract_class(raw)
        )


result = test.copy()

result["prediction"] = predictions
result["raw_output"] = raw_outputs
result["correct"] = (
    result["prediction"]
    == result["rvv_plan_class"]
)


metrics = metrics_dict(
    result["rvv_plan_class"],
    result["prediction"],
)

metrics["seed"] = SEED

metrics["prompt_lengths"] = {
    "min": int(min(lengths)),
    "mean": float(sum(lengths) / len(lengths)),
    "max": int(max(lengths)),
}


result.to_csv(
    OUT / f"four_shot_seed_{SEED}_predictions.csv",
    index=False,
)

with (
    OUT / f"four_shot_seed_{SEED}_metrics.json"
).open("w") as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


demo_records = [
    {
        "dt1_id": str(x["dt1_id"]),
        "base_family": str(x["base_family"]),
        "rvv_plan_class": str(x["rvv_plan_class"]),
    }
    for x in examples
]

with (
    OUT / f"four_shot_seed_{SEED}_examples.json"
).open("w") as f:

    json.dump(
        demo_records,
        f,
        indent=2,
    )


print(json.dumps(metrics, indent=2))
print("Saved outputs.")
