import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch

from peft import PeftModel
from tqdm.auto import tqdm
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
)

from sklearn.metrics import (
    balanced_accuracy_score,
    f1_score,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"
DATA = ROOT / "data" / "folds"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    feature_text,
    metrics_dict,
)


parser = argparse.ArgumentParser()

parser.add_argument(
    "--fold",
    type=int,
    required=True,
)

parser.add_argument(
    "--split",
    choices=[
        "train",
        "val",
        "test",
    ],
    default="val",
)

parser.add_argument(
    "--adapter-dir",
    type=str,
    default=None,
)

args = parser.parse_args()

FOLD = args.fold
SPLIT = args.split


MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

RUN = (
    ROOT
    / "outputs"
    / "abc"
    / f"fold_{FOLD}"
)

ADAPTER = (
    Path(args.adapter_dir)
    if args.adapter_dir
    else RUN / "adapter"
)


CLASS_TO_CODE = {
    "LOW": "A",
    "MEDIUM": "B",
    "HIGH": "C",
}

CODE_TO_CLASS = {
    "A": "LOW",
    "B": "MEDIUM",
    "C": "HIGH",
}


with (
    DATA
    / f"fold_{FOLD}"
    / f"{SPLIT}.json"
).open() as f:

    df = pd.DataFrame(
        json.load(f)
    )


tokenizer = AutoTokenizer.from_pretrained(
    ADAPTER,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )


def task_text_abc(row):

    mlir = str(
        row["mutated_mlir"]
    )

    return (
        "You are a compiler optimization planner for "
        "64-bit RISC-V.\n\n"

        "This MLIR program is known to successfully produce "
        "code under both scalar RISC-V and RISC-V with the "
        "Vector Extension enabled.\n\n"

        "Scalar target features:\n"
        "+m,+a,+f,+d,+c\n\n"

        "RVV target features:\n"
        "+m,+a,+f,+d,+c,+zvl512b,+v\n\n"

        "Predict the measured reduction in generated static "
        "RISC-V instruction count when using RVV instead of "
        "the scalar target.\n\n"

        "Benefit categories:\n"
        "LOW: less than 5% reduction\n"
        "MEDIUM: at least 5% but less than 15% reduction\n"
        "HIGH: at least 15% reduction\n\n"

        "Use the following output codes:\n"
        "A = LOW\n"
        "B = MEDIUM\n"
        "C = HIGH\n\n"

        "Do not assume that generating vector instructions "
        "automatically means high benefit.\n\n"

        "Static program features:\n"
        f"{feature_text(mlir)}\n\n"

        "MLIR:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```\n\n"

        "Return exactly one code: A, B, or C."
    )


def make_prompt(row):

    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content":
                    task_text_abc(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


print("=" * 72)

print(
    f"ABC DIRECT-LOGIT "
    f"{SPLIT.upper()} "
    f"FOLD {FOLD}"
)

print("=" * 72)

print("Examples:", len(df))


print("\nLoading base model...")

base = (
    AutoModelForCausalLM
    .from_pretrained(
        MODEL,
        dtype=torch.bfloat16,
        device_map={"": 0},
        trust_remote_code=True,
    )
)


print(
    "Loading adapter:",
    ADAPTER,
)

model = PeftModel.from_pretrained(
    base,
    ADAPTER,
)

model.eval()


device = next(
    model.parameters()
).device


# ============================================================
# Resolve candidate token IDs in context.
# ============================================================

sample_prompt = make_prompt(
    df.iloc[0]
)

sample_prompt_ids = tokenizer(
    sample_prompt,
    add_special_tokens=False,
)["input_ids"]


CODE_TOKEN_IDS = {}

for code in [
    "A",
    "B",
    "C",
]:

    full_ids = tokenizer(
        sample_prompt + code,
        add_special_tokens=False,
    )["input_ids"]


    if (
        full_ids[
            :len(sample_prompt_ids)
        ]
        != sample_prompt_ids
    ):
        raise RuntimeError(
            "Prompt prefix mismatch"
        )


    continuation = full_ids[
        len(sample_prompt_ids):
    ]


    if len(continuation) != 1:
        raise RuntimeError(
            f"{code} is not one token "
            f"in context: {continuation}"
        )


    CODE_TOKEN_IDS[
        code
    ] = continuation[0]


print(
    "\nCandidate token IDs:",
    CODE_TOKEN_IDS,
)


# ============================================================
# Evaluate
# ============================================================

records = []


for _, row in tqdm(
    df.iterrows(),
    total=len(df),
    desc=(
        f"ABC fold {FOLD} "
        f"{SPLIT}"
    ),
):

    prompt = make_prompt(
        row
    )


    ids = tokenizer(
        prompt,
        add_special_tokens=False,
    )["input_ids"]


    input_ids = torch.tensor(
        [ids],
        dtype=torch.long,
        device=device,
    )


    attention_mask = (
        torch.ones_like(
            input_ids
        )
    )


    with torch.inference_mode():

        output = model(
            input_ids=input_ids,
            attention_mask=
                attention_mask,
            use_cache=False,
        )


    logits = (
        output.logits[
            0,
            -1,
        ]
        .float()
    )


    code_logits = torch.tensor(
        [
            logits[
                CODE_TOKEN_IDS["A"]
            ].item(),

            logits[
                CODE_TOKEN_IDS["B"]
            ].item(),

            logits[
                CODE_TOKEN_IDS["C"]
            ].item(),
        ],
        dtype=torch.float32,
    )


    probs = torch.softmax(
        code_logits,
        dim=0,
    )


    best_index = int(
        torch.argmax(
            code_logits
        ).item()
    )


    predicted_code = [
        "A",
        "B",
        "C",
    ][best_index]


    prediction = (
        CODE_TO_CLASS[
            predicted_code
        ]
    )


    record = row.to_dict()

    record[
        "predicted_code"
    ] = predicted_code

    record[
        "prediction"
    ] = prediction

    record[
        "correct"
    ] = (
        prediction
        == row[
            "rvv_benefit_class"
        ]
    )


    record[
        "logit_A"
    ] = float(
        code_logits[0]
    )

    record[
        "logit_B"
    ] = float(
        code_logits[1]
    )

    record[
        "logit_C"
    ] = float(
        code_logits[2]
    )


    record[
        "prob_LOW"
    ] = float(
        probs[0]
    )

    record[
        "prob_MEDIUM"
    ] = float(
        probs[1]
    )

    record[
        "prob_HIGH"
    ] = float(
        probs[2]
    )


    records.append(
        record
    )


result = pd.DataFrame(
    records
)


metrics = metrics_dict(
    result[
        "rvv_benefit_class"
    ],
    result[
        "prediction"
    ],
)


metrics[
    "balanced_accuracy"
] = float(
    balanced_accuracy_score(
        result[
            "rvv_benefit_class"
        ],
        result[
            "prediction"
        ],
    )
)


# ============================================================
# Actual compiler decision:
#
# LOW    => KEEP_SCALAR
# MEDIUM => APPLY_RVV
# HIGH   => APPLY_RVV
# ============================================================

gold_apply = (
    result[
        "rvv_benefit_class"
    ]
    .isin(
        [
            "MEDIUM",
            "HIGH",
        ]
    )
)


pred_apply = (
    result[
        "prediction"
    ]
    .isin(
        [
            "MEDIUM",
            "HIGH",
        ]
    )
)


metrics[
    "plan_accuracy"
] = float(
    (
        gold_apply
        == pred_apply
    ).mean()
)


metrics[
    "plan_balanced_accuracy"
] = float(
    balanced_accuracy_score(
        gold_apply,
        pred_apply,
    )
)


metrics[
    "plan_macro_f1"
] = float(
    f1_score(
        gold_apply,
        pred_apply,
        average="macro",
        zero_division=0,
    )
)


metrics[
    "missed_profitable_rvv"
] = int(
    (
        gold_apply
        & ~pred_apply
    ).sum()
)


metrics[
    "unprofitable_rvv"
] = int(
    (
        ~gold_apply
        & pred_apply
    ).sum()
)


metrics[
    "fold"
] = FOLD

metrics[
    "split"
] = SPLIT

metrics[
    "target_encoding"
] = {
    "A": "LOW",
    "B": "MEDIUM",
    "C": "HIGH",
}


# ============================================================
# Save
# ============================================================

result.to_csv(
    RUN
    / f"{SPLIT}_predictions.csv",
    index=False,
)


with (
    RUN
    / f"{SPLIT}_metrics.json"
).open("w") as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


print("\n" + "=" * 72)
print("RESULT")
print("=" * 72)

print(
    json.dumps(
        metrics,
        indent=2,
    )
)


print(
    "\nPrediction distribution:"
)

print(
    result[
        "prediction"
    ].value_counts()
)


print(
    "\nGold vs prediction:"
)

print(
    pd.crosstab(
        result[
            "rvv_benefit_class"
        ],
        result[
            "prediction"
        ],
        margins=True,
    )
)


print(
    "\nMean probabilities by gold class:"
)

print(
    result.groupby(
        "rvv_benefit_class"
    )[
        [
            "prob_LOW",
            "prob_MEDIUM",
            "prob_HIGH",
        ]
    ].mean()
)
