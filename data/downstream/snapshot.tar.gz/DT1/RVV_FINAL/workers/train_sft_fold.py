import argparse
import gc
import inspect
import json
import os
import sys
from pathlib import Path

import pandas as pd
import torch

from peft import (
    LoraConfig,
    get_peft_model,
)

from torch.utils.data import Dataset

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"

DATA = ROOT / "data" / "folds"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    CLASSES,
    target_text,
    task_text,
)


parser = argparse.ArgumentParser()

parser.add_argument(
    "--fold",
    type=int,
    required=True,
)

args = parser.parse_args()

FOLD = args.fold

if FOLD not in range(5):
    raise ValueError(
        "fold must be 0..4"
    )


MODEL = (
    "Qwen/Qwen2.5-Coder-14B-Instruct"
)

SEED = 42

MAX_SEQ_LEN = 32768

NUM_EPOCHS = 3
LEARNING_RATE = 1e-4

PER_DEVICE_TRAIN_BATCH = 1
PER_DEVICE_EVAL_BATCH = 1

GRAD_ACCUM = 4


RUN = (
    ROOT
    / "outputs"
    / f"sft_fold_{FOLD}"
)

ADAPTER = RUN / "adapter"

CHECKPOINTS = (
    RUN / "checkpoints"
)

RUN.mkdir(
    parents=True,
    exist_ok=True,
)

ADAPTER.mkdir(
    parents=True,
    exist_ok=True,
)

CHECKPOINTS.mkdir(
    parents=True,
    exist_ok=True,
)


def load(split):

    with (
        DATA
        / f"fold_{FOLD}"
        / f"{split}.json"
    ).open() as f:

        return pd.DataFrame(
            json.load(f)
        )


train_df = load("train")
val_df = load("val")


# ============================================================
# Balance training classes only.
# Validation remains untouched.
# ============================================================

max_class = max(
    (
        train_df[
            "rvv_benefit_class"
        ] == label
    ).sum()

    for label in CLASSES
)


balanced_parts = []

for class_index, label in enumerate(
    CLASSES
):

    subset = train_df[
        train_df[
            "rvv_benefit_class"
        ] == label
    ]


    balanced_parts.append(
        subset.sample(
            n=max_class,
            replace=(
                len(subset)
                < max_class
            ),
            random_state=(
                SEED
                + FOLD * 100
                + class_index
            ),
        )
    )


balanced_train = (
    pd.concat(
        balanced_parts,
        ignore_index=True,
    )
    .sample(
        frac=1.0,
        random_state=(
            SEED + FOLD
        ),
    )
    .reset_index(drop=True)
)


print("=" * 72)
print(
    f"DT1 CLASS-ONLY SFT FOLD {FOLD}"
)
print("=" * 72)

print(
    "Original train:",
    len(train_df),
)

print(
    train_df[
        "rvv_benefit_class"
    ].value_counts()
)

print(
    "\nBalanced train:",
    len(balanced_train),
)

print(
    balanced_train[
        "rvv_benefit_class"
    ].value_counts()
)

print(
    "\nValidation:",
    len(val_df),
)

print(
    val_df[
        "rvv_benefit_class"
    ].value_counts()
)


# ============================================================
# Tokenizer
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    MODEL,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )

tokenizer.padding_side = "right"


def prompt_messages(row):

    return [
        {
            "role": "user",
            "content":
                task_text(row),
        }
    ]


def full_messages(row):

    return (
        prompt_messages(row)
        + [
            {
                "role": "assistant",
                "content":
                    target_text(row),
            }
        ]
    )


# ============================================================
# Dataset
# ============================================================

class RVVDataset(Dataset):

    def __init__(self, dataframe):

        self.examples = []

        for _, row in dataframe.iterrows():

            p_text = (
                tokenizer
                .apply_chat_template(
                    prompt_messages(row),
                    tokenize=False,
                    add_generation_prompt=True,
                )
            )

            f_text = (
                tokenizer
                .apply_chat_template(
                    full_messages(row),
                    tokenize=False,
                    add_generation_prompt=False,
                )
            )


            prompt_ids = tokenizer(
                p_text,
                add_special_tokens=False,
            )["input_ids"]


            encoded = tokenizer(
                f_text,
                add_special_tokens=False,
                truncation=False,
            )


            input_ids = (
                encoded["input_ids"]
            )


            if (
                len(input_ids)
                > MAX_SEQ_LEN
            ):
                raise RuntimeError(
                    "Sequence exceeds context "
                    f"limit: {len(input_ids)}"
                )


            if (
                input_ids[
                    :len(prompt_ids)
                ]
                != prompt_ids
            ):
                raise RuntimeError(
                    "Prompt prefix mismatch"
                )


            labels = (
                input_ids.copy()
            )


            labels[
                :len(prompt_ids)
            ] = (
                [-100]
                * len(prompt_ids)
            )


            self.examples.append(
                {
                    "input_ids":
                        input_ids,

                    "attention_mask":
                        encoded[
                            "attention_mask"
                        ],

                    "labels":
                        labels,
                }
            )


    def __len__(self):
        return len(self.examples)


    def __getitem__(self, index):
        return self.examples[index]


class Collator:

    def __init__(self, tokenizer):
        self.tokenizer = tokenizer


    def __call__(self, features):

        max_len = max(
            len(x["input_ids"])
            for x in features
        )


        ids = []
        masks = []
        labels = []


        for feature in features:

            pad = (
                max_len
                - len(
                    feature["input_ids"]
                )
            )


            ids.append(
                feature["input_ids"]
                + [
                    self.tokenizer
                    .pad_token_id
                ] * pad
            )


            masks.append(
                feature[
                    "attention_mask"
                ]
                + [0] * pad
            )


            labels.append(
                feature["labels"]
                + [-100] * pad
            )


        return {
            "input_ids":
                torch.tensor(
                    ids,
                    dtype=torch.long,
                ),

            "attention_mask":
                torch.tensor(
                    masks,
                    dtype=torch.long,
                ),

            "labels":
                torch.tensor(
                    labels,
                    dtype=torch.long,
                ),
        }


train_dataset = RVVDataset(
    balanced_train
)

val_dataset = RVVDataset(
    val_df
)

collator = Collator(
    tokenizer
)


# ============================================================
# Model
# ============================================================

model = (
    AutoModelForCausalLM
    .from_pretrained(
        MODEL,
        dtype=torch.bfloat16,
        low_cpu_mem_usage=True,
        trust_remote_code=True,
    )
)

model.config.use_cache = False

model.gradient_checkpointing_enable()


lora = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.0,
    bias="none",
    task_type="CAUSAL_LM",

    target_modules=[
        "q_proj",
        "v_proj",
    ],
)


model = get_peft_model(
    model,
    lora,
)

model.print_trainable_parameters()


# ============================================================
# Trainer
# ============================================================

params = inspect.signature(
    TrainingArguments.__init__
).parameters


kwargs = {
    "output_dir":
        str(CHECKPOINTS),

    "num_train_epochs":
        NUM_EPOCHS,

    "per_device_train_batch_size":
        PER_DEVICE_TRAIN_BATCH,

    "per_device_eval_batch_size":
        PER_DEVICE_EVAL_BATCH,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "learning_rate":
        LEARNING_RATE,

    "bf16":
        True,

    "logging_steps":
        10,

    "save_strategy":
        "epoch",

    "save_total_limit":
        1,

    "report_to":
        "none",

    "seed":
        SEED,

    "remove_unused_columns":
        False,

    "gradient_checkpointing":
        True,
}


if "eval_strategy" in params:

    kwargs[
        "eval_strategy"
    ] = "epoch"

elif (
    "evaluation_strategy"
    in params
):

    kwargs[
        "evaluation_strategy"
    ] = "epoch"

else:

    raise RuntimeError(
        "No evaluation strategy "
        "argument available."
    )


kwargs[
    "load_best_model_at_end"
] = True

kwargs[
    "metric_for_best_model"
] = "eval_loss"

kwargs[
    "greater_is_better"
] = False


if "warmup_steps" in params:
    kwargs["warmup_steps"] = 20


training_args = (
    TrainingArguments(
        **kwargs
    )
)


trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    data_collator=collator,
)


trainer.train()


# trainer.model is the restored best checkpoint
trainer.save_model(
    str(ADAPTER)
)

tokenizer.save_pretrained(
    str(ADAPTER)
)


metadata = {
    "fold":
        FOLD,

    "model":
        MODEL,

    "original_train_examples":
        len(train_df),

    "balanced_train_examples":
        len(balanced_train),

    "validation_examples":
        len(val_df),

    "epochs":
        NUM_EPOCHS,

    "learning_rate":
        LEARNING_RATE,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "lora_r":
        16,

    "lora_alpha":
        32,

    "target_modules":
        [
            "q_proj",
            "v_proj",
        ],

    "best_model_checkpoint":
        trainer.state
        .best_model_checkpoint,

    "best_eval_loss":
        trainer.state
        .best_metric,
}


with (
    RUN / "training_metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print(
    json.dumps(
        metadata,
        indent=2,
    )
)

print(
    "\nSaved adapter:",
    ADAPTER,
)
