import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch
import torch.nn.functional as F

from peft import PeftModel
from tqdm.auto import tqdm
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"
DATA = ROOT / "data" / "folds"
OUT = ROOT / "outputs"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    CLASSES,
    few_shot_prompt,
    metrics_dict,
    zero_shot_prompt,
)


parser = argparse.ArgumentParser()

parser.add_argument(
    "--mode",
    choices=[
        "zero",
        "three-shot",
        "sft",
    ],
    required=True,
)

parser.add_argument(
    "--fold",
    type=int,
    required=True,
)

parser.add_argument(
    "--split",
    choices=[
        "val",
        "test",
    ],
    default="test",
)

parser.add_argument(
    "--seed",
    type=int,
    default=None,
)

parser.add_argument(
    "--adapter-dir",
    type=str,
    default=None,
)

parser.add_argument(
    "--tag",
    type=str,
    default=None,
)

args = parser.parse_args()


MODE = args.mode
FOLD = args.fold
SPLIT = args.split
SEED = args.seed

MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"


if FOLD not in range(5):
    raise ValueError(
        "--fold must be 0..4"
    )

if (
    MODE == "three-shot"
    and SEED is None
):
    raise ValueError(
        "--seed is required for three-shot"
    )


def load(split):
    with (
        DATA
        / f"fold_{FOLD}"
        / f"{split}.json"
    ).open() as f:
        return pd.DataFrame(
            json.load(f)
        )


train = load("train")
eval_df = load(SPLIT)


# ============================================================
# Select exactly the same 3-shot demonstrations as before.
# ============================================================

examples = None

if MODE == "three-shot":

    examples_file = (
        OUT
        / f"three_shot_seed_{SEED}_examples.json"
    )

    if examples_file.exists():

        with examples_file.open() as f:
            saved = json.load(f)

        fold_records = saved[str(FOLD)]

        train_by_id = {
            str(row["dt1_id"]): row
            for _, row in train.iterrows()
        }

        examples = []

        for record in fold_records:

            dt1_id = str(
                record["dt1_id"]
            )

            if dt1_id not in train_by_id:
                raise RuntimeError(
                    f"Saved demo {dt1_id} "
                    f"not found in fold {FOLD} train."
                )

            examples.append(
                train_by_id[dt1_id]
            )

    else:

        examples = []

        for class_index, label in enumerate(
            CLASSES
        ):

            subset = train[
                train["rvv_benefit_class"]
                == label
            ].copy()

            subset["mlir_chars"] = (
                subset["mutated_mlir"]
                .astype(str)
                .str.len()
            )

            pool = (
                subset
                .sort_values("mlir_chars")
                .head(
                    min(
                        10,
                        len(subset),
                    )
                )
            )

            example = pool.sample(
                n=1,
                random_state=(
                    SEED
                    + FOLD * 100
                    + class_index
                ),
            ).iloc[0]

            examples.append(
                example
            )


# ============================================================
# Model/tokenizer
# ============================================================

adapter_dir = None

if MODE == "sft":

    if args.adapter_dir is not None:
        adapter_dir = Path(
            args.adapter_dir
        )

    else:
        adapter_dir = (
            OUT
            / f"sft_fold_{FOLD}"
            / "adapter"
        )

    if not adapter_dir.exists():
        raise RuntimeError(
            f"Adapter not found: {adapter_dir}"
        )


tokenizer_source = (
    adapter_dir
    if adapter_dir is not None
    else MODEL
)


tokenizer = AutoTokenizer.from_pretrained(
    tokenizer_source,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )


print("=" * 72)
print("LABEL-LIKELIHOOD SCORING")
print("=" * 72)

print("Mode:", MODE)
print("Fold:", FOLD)
print("Split:", SPLIT)
print("Examples:", len(eval_df))

if MODE == "three-shot":
    print("Seed:", SEED)

    print("\nDemonstrations:")

    for ex in examples:
        print(
            ex["dt1_id"],
            ex["base_family"],
            ex["rvv_benefit_class"],
        )


print("\nLoading base model...")

base_model = (
    AutoModelForCausalLM
    .from_pretrained(
        MODEL,
        dtype=torch.bfloat16,
        device_map={"": 0},
        trust_remote_code=True,
    )
)


if MODE == "sft":

    print(
        "Loading adapter:",
        adapter_dir,
    )

    model = PeftModel.from_pretrained(
        base_model,
        adapter_dir,
    )

else:
    model = base_model


model.eval()

device = next(
    model.parameters()
).device


# ============================================================
# Candidate tokenization
# ============================================================

def build_prompt(row):

    if MODE == "three-shot":
        return few_shot_prompt(
            tokenizer,
            row,
            examples,
        )

    return zero_shot_prompt(
        tokenizer,
        row,
    )


def candidate_ids(
    prompt_text,
    prompt_ids,
    label,
):

    full_ids = tokenizer(
        prompt_text + label,
        add_special_tokens=False,
    )["input_ids"]

    if (
        full_ids[:len(prompt_ids)]
        != prompt_ids
    ):
        raise RuntimeError(
            "Tokenizer prefix mismatch for "
            f"candidate {label}."
        )

    ids = full_ids[
        len(prompt_ids):
    ]

    if not ids:
        raise RuntimeError(
            f"No candidate tokens for {label}"
        )

    return ids


# ============================================================
# Score P(label | prompt)
#
# Fast path:
# If LOW/MEDIUM/HIGH are each one token in context,
# we need only one model forward pass.
#
# Fallback:
# If any label has multiple tokens, evaluate all three
# candidate continuations together and average their
# token log-likelihood.
# ============================================================

def score_labels(prompt_text):

    prompt_ids = tokenizer(
        prompt_text,
        add_special_tokens=False,
    )["input_ids"]

    candidates = {
        label: candidate_ids(
            prompt_text,
            prompt_ids,
            label,
        )
        for label in CLASSES
    }


    all_single_token = all(
        len(ids) == 1
        for ids in candidates.values()
    )


    if all_single_token:

        input_ids = torch.tensor(
            [prompt_ids],
            dtype=torch.long,
            device=device,
        )

        attention_mask = torch.ones_like(
            input_ids
        )

        with torch.inference_mode():

            output = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                use_cache=False,
            )

        next_logits = (
            output.logits[0, -1]
            .float()
        )

        next_log_probs = (
            F.log_softmax(
                next_logits,
                dim=-1,
            )
        )


        scores = {
            label:
                float(
                    next_log_probs[
                        ids[0]
                    ].item()
                )

            for label, ids
            in candidates.items()
        }


    else:

        sequences = []
        masks = []

        max_len = max(
            len(prompt_ids)
            + len(ids)

            for ids in candidates.values()
        )


        ordered_labels = list(
            CLASSES
        )


        for label in ordered_labels:

            seq = (
                prompt_ids
                + candidates[label]
            )

            pad = (
                max_len
                - len(seq)
            )

            sequences.append(
                seq
                + [
                    tokenizer.pad_token_id
                ] * pad
            )

            masks.append(
                [1] * len(seq)
                + [0] * pad
            )


        input_ids = torch.tensor(
            sequences,
            dtype=torch.long,
            device=device,
        )

        attention_mask = torch.tensor(
            masks,
            dtype=torch.long,
            device=device,
        )


        with torch.inference_mode():

            output = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                use_cache=False,
            )


        scores = {}


        for i, label in enumerate(
            ordered_labels
        ):

            ids = candidates[label]

            token_log_probs = []


            for j, token_id in enumerate(
                ids
            ):

                # token at absolute position:
                # len(prompt_ids) + j
                #
                # is predicted by logits at
                # previous position.
                logit_position = (
                    len(prompt_ids)
                    + j
                    - 1
                )


                logits = (
                    output.logits[
                        i,
                        logit_position,
                    ]
                    .float()
                )


                log_probs = F.log_softmax(
                    logits,
                    dim=-1,
                )


                token_log_probs.append(
                    float(
                        log_probs[
                            token_id
                        ].item()
                    )
                )


            # Score the probability of the complete label
            # sequence. Log probabilities add across tokens:
            #
            # log P(MEDIUM | prompt)
            #   = log P(M | prompt)
            #   + log P(EDIUM | prompt, M)
            #
            # Do NOT average here. MEDIUM uses two tokenizer
            # tokens whereas LOW/HIGH use one; averaging can
            # artificially favor a multi-token label when its
            # later token is nearly deterministic.
            scores[label] = float(
                sum(token_log_probs)
            )


    score_tensor = torch.tensor(
        [
            scores[label]
            for label in CLASSES
        ],
        dtype=torch.float32,
    )


    probabilities = torch.softmax(
        score_tensor,
        dim=0,
    ).tolist()


    probs = {
        label:
            float(prob)

        for label, prob
        in zip(
            CLASSES,
            probabilities,
        )
    }


    prediction = max(
        CLASSES,
        key=lambda label:
            scores[label],
    )


    return (
        prediction,
        scores,
        probs,
        {
            label:
                len(candidates[label])

            for label in CLASSES
        },
    )


# ============================================================
# Evaluate
# ============================================================

records = []


for _, row in tqdm(
    eval_df.iterrows(),
    total=len(eval_df),
    desc=(
        f"{MODE} fold {FOLD} "
        f"{SPLIT} likelihood"
    ),
):

    prompt_text = build_prompt(
        row
    )


    (
        prediction,
        scores,
        probs,
        token_counts,
    ) = score_labels(
        prompt_text
    )


    record = row.to_dict()

    record["prediction"] = (
        prediction
    )

    record["correct"] = (
        prediction
        == row["rvv_benefit_class"]
    )


    for label in CLASSES:

        record[
            f"score_{label}"
        ] = scores[label]

        record[
            f"prob_{label}"
        ] = probs[label]

        record[
            f"tokens_{label}"
        ] = token_counts[label]


    records.append(
        record
    )


result = pd.DataFrame(
    records
)


metrics = metrics_dict(
    result["rvv_benefit_class"],
    result["prediction"],
)


metrics["mode"] = MODE
metrics["fold"] = FOLD
metrics["split"] = SPLIT
metrics["scoring_rule"] = "sum_logprob_label_sequence"

if SEED is not None:
    metrics["seed"] = SEED


# ============================================================
# Save
# ============================================================

if args.tag:

    tag = args.tag

elif MODE == "zero":

    tag = "zero"

elif MODE == "three-shot":

    tag = (
        f"three_shot_seed_{SEED}"
    )

else:

    tag = "sft"


save_dir = (
    OUT
    / "likelihood"
    / tag
)

save_dir.mkdir(
    parents=True,
    exist_ok=True,
)


csv_path = (
    save_dir
    / f"fold_{FOLD}_{SPLIT}.csv"
)

json_path = (
    save_dir
    / f"fold_{FOLD}_{SPLIT}_metrics.json"
)


result.to_csv(
    csv_path,
    index=False,
)


with json_path.open(
    "w"
) as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


print("\n" + "=" * 72)
print("RESULT")
print("=" * 72)

print(
    json.dumps(
        metrics,
        indent=2,
    )
)


print("\nPrediction distribution:")

print(
    result["prediction"]
    .value_counts()
)


print("\nMean label probabilities:")

print(
    result[
        [
            "prob_LOW",
            "prob_MEDIUM",
            "prob_HIGH",
        ]
    ]
    .mean()
)


print("\nSaved:")
print(csv_path)
print(json_path)
