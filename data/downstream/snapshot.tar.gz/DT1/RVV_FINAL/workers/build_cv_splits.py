import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"

CODEGEN = BASE / "outputs" / "riscv_codegen_results.csv"
CORPUS = BASE / "data" / "corpus_rows.csv"

OUT = ROOT / "data" / "folds"
OUT.mkdir(parents=True, exist_ok=True)

SEED = 42
N_FOLDS = 5

CLASS_ORDER = [
    "LOW",
    "MEDIUM",
    "HIGH",
]


def as_bool(series):
    return (
        series
        .astype(str)
        .str.lower()
        .eq("true")
    )


def get_family(text):
    families = [
        x.strip()
        for x in str(text).split(";")
        if x.strip()
    ]

    if len(families) != 1:
        raise RuntimeError(
            f"Expected one family, got {families}"
        )

    return families[0]


def benefit_class(reduction):
    reduction = float(reduction)

    if reduction < 5.0:
        return "LOW"

    if reduction < 15.0:
        return "MEDIUM"

    return "HIGH"


# ============================================================
# Compiler results
# ============================================================

codegen = pd.read_csv(CODEGEN)

codegen["compiler_comparable"] = as_bool(
    codegen["compiler_comparable"]
)

df = codegen[
    codegen["compiler_comparable"]
].copy()

print("=" * 80)
print("FINAL DT1 RVV DATASET")
print("=" * 80)

print("Compiler-comparable unique programs:", len(df))

if len(df) != 675:
    raise RuntimeError(
        f"Expected 675 comparable programs, got {len(df)}"
    )


df["base_family"] = (
    df["families"]
    .apply(get_family)
)

df["rvv_benefit_class"] = (
    df["reduction_pct"]
    .apply(benefit_class)
)


# ============================================================
# Recover source MLIR
# ============================================================

corpus = pd.read_csv(CORPUS)

representative = (
    corpus
    .sort_values(
        ["mlir_hash", "program_id"]
    )
    .drop_duplicates(
        subset=["mlir_hash"],
        keep="first",
    )
    [
        [
            "mlir_hash",
            "program_id",
            "mutated_mlir",
            "semantic_label",
            "level",
            "requirement_id",
        ]
    ]
)

df = df.merge(
    representative,
    on="mlir_hash",
    how="left",
    validate="one_to_one",
)

if df["mutated_mlir"].isna().any():
    raise RuntimeError(
        "Failed to recover MLIR for some programs."
    )


# ============================================================
# Freeze five family-disjoint folds
# ============================================================

splitter = StratifiedGroupKFold(
    n_splits=N_FOLDS,
    shuffle=True,
    random_state=SEED,
)

fold_assignment = np.full(
    len(df),
    -1,
    dtype=int,
)

for fold, (_, test_indices) in enumerate(
    splitter.split(
        X=df,
        y=df["rvv_benefit_class"],
        groups=df["base_family"],
    )
):
    fold_assignment[test_indices] = fold

df["cv_fold"] = fold_assignment

if (df["cv_fold"] < 0).any():
    raise RuntimeError(
        "Some programs did not receive a CV fold."
    )


# ============================================================
# Global checks
# ============================================================

print("\nOverall classes:")

print(
    df["rvv_benefit_class"]
    .value_counts()
    .reindex(
        CLASS_ORDER,
        fill_value=0,
    )
)

print(
    "\nFamilies:",
    df["base_family"].nunique(),
)


# ============================================================
# Materialize each outer fold
# ============================================================

metadata = {
    "seed": SEED,
    "n_folds": N_FOLDS,
    "population": len(df),
    "family_count": int(
        df["base_family"].nunique()
    ),
    "classes": CLASS_ORDER,
    "thresholds": {
        "LOW": "reduction_pct < 5",
        "MEDIUM": "5 <= reduction_pct < 15",
        "HIGH": "reduction_pct >= 15",
    },
    "folds": {},
}


def save_json(path, frame):
    records = (
        frame
        .where(
            pd.notnull(frame),
            None,
        )
        .to_dict(orient="records")
    )

    with path.open(
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            records,
            f,
            indent=2,
        )


for test_fold in range(N_FOLDS):

    val_fold = (
        test_fold + 1
    ) % N_FOLDS

    train = df[
        ~df["cv_fold"].isin(
            [test_fold, val_fold]
        )
    ].copy()

    val = df[
        df["cv_fold"] == val_fold
    ].copy()

    test = df[
        df["cv_fold"] == test_fold
    ].copy()


    train_f = set(
        train["base_family"]
    )

    val_f = set(
        val["base_family"]
    )

    test_f = set(
        test["base_family"]
    )


    overlap = {
        "train_val":
            len(train_f & val_f),

        "train_test":
            len(train_f & test_f),

        "val_test":
            len(val_f & test_f),
    }

    if any(overlap.values()):
        raise RuntimeError(
            f"Family leakage in fold {test_fold}: "
            f"{overlap}"
        )


    train_h = set(
        train["mlir_hash"]
    )

    val_h = set(
        val["mlir_hash"]
    )

    test_h = set(
        test["mlir_hash"]
    )

    hash_overlap = {
        "train_val":
            len(train_h & val_h),

        "train_test":
            len(train_h & test_h),

        "val_test":
            len(val_h & test_h),
    }

    if any(hash_overlap.values()):
        raise RuntimeError(
            f"MLIR leakage in fold {test_fold}: "
            f"{hash_overlap}"
        )


    fold_dir = (
        OUT / f"fold_{test_fold}"
    )

    fold_dir.mkdir(
        parents=True,
        exist_ok=True,
    )


    for name, part in [
        ("train", train),
        ("val", val),
        ("test", test),
    ]:

        part = (
            part
            .sort_values(
                [
                    "base_family",
                    "dt1_id",
                ]
            )
            .reset_index(drop=True)
        )

        part.to_csv(
            fold_dir / f"{name}.csv",
            index=False,
        )

        save_json(
            fold_dir / f"{name}.json",
            part,
        )


    print("\n" + "=" * 80)

    print(
        f"OUTER FOLD {test_fold}"
    )

    print("=" * 80)

    for name, part in [
        ("TRAIN", train),
        ("VAL", val),
        ("TEST", test),
    ]:

        print(
            f"\n{name}: "
            f"{len(part)} programs | "
            f"{part['base_family'].nunique()} families"
        )

        print(
            part["rvv_benefit_class"]
            .value_counts()
            .reindex(
                CLASS_ORDER,
                fill_value=0,
            )
        )


    metadata["folds"][str(test_fold)] = {
        "test_fold":
            test_fold,

        "val_fold":
            val_fold,

        "train":
            len(train),

        "val":
            len(val),

        "test":
            len(test),

        "train_families":
            train["base_family"].nunique(),

        "val_families":
            val["base_family"].nunique(),

        "test_families":
            test["base_family"].nunique(),

        "family_overlap":
            overlap,

        "mlir_hash_overlap":
            hash_overlap,

        "train_classes":
            train[
                "rvv_benefit_class"
            ].value_counts().to_dict(),

        "val_classes":
            val[
                "rvv_benefit_class"
            ].value_counts().to_dict(),

        "test_classes":
            test[
                "rvv_benefit_class"
            ].value_counts().to_dict(),
    }


with (
    OUT / "metadata.json"
).open(
    "w",
    encoding="utf-8",
) as f:
    json.dump(
        metadata,
        f,
        indent=2,
    )


df.to_csv(
    ROOT / "data" / "all_supported.csv",
    index=False,
)

save_json(
    ROOT / "data" / "all_supported.json",
    df,
)


print("\n" + "=" * 80)
print("DONE")
print("=" * 80)

print("Saved folds:", OUT)
