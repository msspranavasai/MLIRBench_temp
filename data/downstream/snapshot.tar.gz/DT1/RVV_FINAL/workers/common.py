import json
import re

import numpy as np

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
)


CLASSES = [
    "LOW",
    "MEDIUM",
    "HIGH",
]

ORDINAL = {
    "LOW": 0,
    "MEDIUM": 1,
    "HIGH": 2,
}


# ============================================================
# Static MLIR features
# ============================================================

def static_features(mlir):

    text = str(mlir)

    lower = text.lower()

    lines = [
        line
        for line in text.splitlines()
        if line.strip()
    ]

    return {
        "chars":
            len(text),

        "lines":
            len(lines),

        "linalg_ops":
            lower.count("linalg."),

        "arith_ops":
            lower.count("arith."),

        "tensor_ops":
            lower.count("tensor."),

        "scf_ops":
            lower.count("scf."),

        "memref_ops":
            lower.count("memref."),

        "math_ops":
            lower.count("math."),

        "vector_ops":
            lower.count("vector."),

        "generic_ops":
            lower.count("linalg.generic"),

        "fill_ops":
            lower.count("linalg.fill"),

        "matmul_ops":
            lower.count("matmul"),

        "reduce_tokens":
            lower.count("reduce")
            + lower.count("reduction"),

        "extract_slice":
            lower.count(
                "tensor.extract_slice"
            ),

        "insert_slice":
            lower.count(
                "tensor.insert_slice"
            ),

        "extract_ops":
            lower.count(
                "tensor.extract"
            ),

        "insert_ops":
            lower.count(
                "tensor.insert"
            ),

        "for_tokens":
            lower.count("scf.for"),

        "while_tokens":
            lower.count("scf.while"),

        "parallel_tokens":
            lower.count("parallel"),

        "affine_tokens":
            lower.count("affine."),

        "cmp_tokens":
            lower.count("cmp"),

        "select_tokens":
            lower.count("select"),

        "index_cast":
            lower.count("index_cast"),

        "f32_tokens":
            lower.count("f32"),

        "f64_tokens":
            lower.count("f64"),

        "i1_tokens":
            lower.count("i1"),

        "i32_tokens":
            lower.count("i32"),

        "i64_tokens":
            lower.count("i64"),
    }


def feature_text(mlir):

    features = static_features(
        mlir
    )

    keys = [
        "chars",
        "lines",
        "linalg_ops",
        "arith_ops",
        "tensor_ops",
        "scf_ops",
        "memref_ops",
        "math_ops",
        "generic_ops",
        "reduce_tokens",
        "extract_slice",
        "insert_slice",
        "for_tokens",
        "parallel_tokens",
        "f32_tokens",
        "f64_tokens",
    ]

    return "\n".join(
        f"{key}: {features[key]}"
        for key in keys
    )


# ============================================================
# Core task
# ============================================================

def task_text(row):

    mlir = str(
        row["mutated_mlir"]
    )

    return (
        "You are a compiler optimization planner for "
        "64-bit RISC-V.\n\n"

        "This MLIR program is known to successfully produce "
        "code under both scalar RISC-V and RISC-V with the "
        "Vector Extension enabled.\n\n"

        "Scalar target features:\n"
        "+m,+a,+f,+d,+c\n\n"

        "RVV target features:\n"
        "+m,+a,+f,+d,+c,+zvl512b,+v\n\n"

        "Predict the measured reduction in generated static "
        "RISC-V instruction count when using RVV instead of "
        "the scalar target.\n\n"

        "Return exactly one label:\n\n"

        "LOW: less than 5% reduction\n"
        "MEDIUM: at least 5% but less than 15% reduction\n"
        "HIGH: at least 15% reduction\n\n"

        "Do not assume that generating vector instructions "
        "automatically means HIGH benefit.\n\n"

        "Static program features:\n"
        f"{feature_text(mlir)}\n\n"

        "MLIR:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```\n\n"

        "Return exactly one of: LOW, MEDIUM, HIGH."
    )


def target_text(row):
    return str(
        row["rvv_benefit_class"]
    )


def zero_shot_prompt(
    tokenizer,
    row,
):

    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content": task_text(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


def few_shot_prompt(
    tokenizer,
    row,
    examples,
):

    messages = []

    for example in examples:

        messages.append(
            {
                "role": "user",
                "content":
                    task_text(example),
            }
        )

        messages.append(
            {
                "role": "assistant",
                "content":
                    target_text(example),
            }
        )

    messages.append(
        {
            "role": "user",
            "content":
                task_text(row),
        }
    )

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


# ============================================================
# Label extraction
# ============================================================

def extract_label(output):

    if output is None:
        return "INVALID"

    text = str(output).strip()

    if not text:
        return "INVALID"

    first_line = (
        text
        .splitlines()[0]
        .strip()
        .upper()
    )

    for label in CLASSES:

        if re.search(
            rf"\b{label}\b",
            first_line,
        ):
            return label

    upper = text.upper()

    for label in CLASSES:

        if re.search(
            rf"\b{label}\b",
            upper,
        ):
            return label

    return "INVALID"


# ============================================================
# Metrics
# ============================================================

def metrics_dict(
    y_true,
    y_pred,
):

    y_true = list(y_true)
    y_pred = list(y_pred)

    accuracy = accuracy_score(
        y_true,
        y_pred,
    )

    macro_f1 = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average="macro",
        zero_division=0,
    )

    weighted_f1 = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average="weighted",
        zero_division=0,
    )

    per_class = f1_score(
        y_true,
        y_pred,
        labels=CLASSES,
        average=None,
        zero_division=0,
    )


    distances = []

    severe = 0
    within_one = 0

    for gold, pred in zip(
        y_true,
        y_pred,
    ):

        if pred not in ORDINAL:

            distances.append(2)

            continue

        d = abs(
            ORDINAL[gold]
            - ORDINAL[pred]
        )

        distances.append(d)

        if d == 2:
            severe += 1

        if d <= 1:
            within_one += 1


    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=CLASSES + ["INVALID"],
    )


    return {
        "n":
            len(y_true),

        "accuracy":
            float(accuracy),

        "macro_f1":
            float(macro_f1),

        "weighted_f1":
            float(weighted_f1),

        "per_class_f1": {
            label:
                float(score)

            for label, score in zip(
                CLASSES,
                per_class,
            )
        },

        "ordinal_mae":
            float(
                np.mean(distances)
            ),

        "severe_error_rate":
            float(
                severe
                / len(y_true)
            ),

        "within_one_class":
            float(
                within_one
                / len(y_true)
            ),

        "invalid_count":
            int(
                sum(
                    pred == "INVALID"
                    for pred in y_pred
                )
            ),

        "confusion_matrix_labels":
            CLASSES + ["INVALID"],

        "confusion_matrix":
            cm.tolist(),
    }


# ============================================================
# Executable planning
# ============================================================

def apply_rvv(label):
    return label in {
        "MEDIUM",
        "HIGH",
    }


def materialize_plan(label):

    if label == "LOW":

        return {
            "optimization_label":
                "KEEP_SCALAR",

            "recommended_passes":
                [
                    "canonicalize",
                    "cse",
                ],

            "rvv_expected_benefit":
                "LOW",

            "reason":
                (
                    "Predicted RVV benefit is below the "
                    "5% profitability threshold."
                ),
        }

    if label in {
        "MEDIUM",
        "HIGH",
    }:

        return {
            "optimization_label":
                "APPLY_RVV",

            "recommended_passes":
                [
                    "canonicalize",
                    "cse",
                ],

            "rvv_expected_benefit":
                label,

            "reason":
                (
                    f"Predicted {label.lower()} RVV "
                    "code-generation benefit."
                ),
        }

    return {
        "optimization_label":
            "INVALID",

        "recommended_passes":
            [],

        "rvv_expected_benefit":
            "INVALID",

        "reason":
            "No valid prediction.",
    }
