import argparse
import inspect
import json
import sys
from pathlib import Path

import pandas as pd
import torch
from peft import LoraConfig, get_peft_model
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"
DATA = ROOT / "data" / "folds"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    CLASSES,
    feature_text,
)


parser = argparse.ArgumentParser()
parser.add_argument(
    "--fold",
    type=int,
    required=True,
)
args = parser.parse_args()

FOLD = args.fold

if FOLD not in range(5):
    raise ValueError("fold must be 0..4")


MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

SEED = 42
NUM_EPOCHS = 3
LEARNING_RATE = 1e-4
GRAD_ACCUM = 4
MAX_SEQ_LEN = 32768


CLASS_TO_CODE = {
    "LOW": "A",
    "MEDIUM": "B",
    "HIGH": "C",
}

CODE_TO_CLASS = {
    v: k
    for k, v in CLASS_TO_CODE.items()
}


RUN = (
    ROOT
    / "outputs"
    / "abc"
    / f"fold_{FOLD}"
)

ADAPTER = RUN / "adapter"
CHECKPOINTS = RUN / "checkpoints"

RUN.mkdir(
    parents=True,
    exist_ok=True,
)

ADAPTER.mkdir(
    parents=True,
    exist_ok=True,
)

CHECKPOINTS.mkdir(
    parents=True,
    exist_ok=True,
)


def load(split):
    with (
        DATA
        / f"fold_{FOLD}"
        / f"{split}.json"
    ).open() as f:
        return pd.DataFrame(
            json.load(f)
        )


train_df = load("train")
val_df = load("val")


# ============================================================
# Keep the SAME training balancing as our previous SFT.
# This isolates the effect of changing the target objective.
# ============================================================

largest_class = max(
    (
        train_df["rvv_benefit_class"]
        == label
    ).sum()
    for label in CLASSES
)

balanced_parts = []

for class_index, label in enumerate(
    CLASSES
):

    subset = train_df[
        train_df["rvv_benefit_class"]
        == label
    ]

    balanced_parts.append(
        subset.sample(
            n=largest_class,
            replace=(
                len(subset)
                < largest_class
            ),
            random_state=(
                SEED
                + FOLD * 100
                + class_index
            ),
        )
    )


balanced_train = (
    pd.concat(
        balanced_parts,
        ignore_index=True,
    )
    .sample(
        frac=1.0,
        random_state=SEED + FOLD,
    )
    .reset_index(drop=True)
)


print("=" * 72)
print(
    f"DT1 SINGLE-TOKEN ABC SFT FOLD {FOLD}"
)
print("=" * 72)

print("\nOriginal train:")
print(
    train_df[
        "rvv_benefit_class"
    ].value_counts()
)

print("\nBalanced train:")
print(
    balanced_train[
        "rvv_benefit_class"
    ].value_counts()
)

print("\nValidation:")
print(
    val_df[
        "rvv_benefit_class"
    ].value_counts()
)


# ============================================================
# Tokenizer
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    MODEL,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )

tokenizer.padding_side = "right"


# Verify A/B/C are one token.
CODE_TOKEN_IDS = {}

for code in ["A", "B", "C"]:

    ids = tokenizer(
        code,
        add_special_tokens=False,
    )["input_ids"]

    if len(ids) != 1:
        raise RuntimeError(
            f"{code} is not one token: {ids}"
        )

    CODE_TOKEN_IDS[code] = ids[0]


print("\nCode token IDs:")
print(CODE_TOKEN_IDS)


# ============================================================
# Prompt
# ============================================================

def task_text_abc(row):

    mlir = str(
        row["mutated_mlir"]
    )

    return (
        "You are a compiler optimization planner for "
        "64-bit RISC-V.\n\n"

        "This MLIR program is known to successfully produce "
        "code under both scalar RISC-V and RISC-V with the "
        "Vector Extension enabled.\n\n"

        "Scalar target features:\n"
        "+m,+a,+f,+d,+c\n\n"

        "RVV target features:\n"
        "+m,+a,+f,+d,+c,+zvl512b,+v\n\n"

        "Predict the measured reduction in generated static "
        "RISC-V instruction count when using RVV instead of "
        "the scalar target.\n\n"

        "Benefit categories:\n"
        "LOW: less than 5% reduction\n"
        "MEDIUM: at least 5% but less than 15% reduction\n"
        "HIGH: at least 15% reduction\n\n"

        "Use the following output codes:\n"
        "A = LOW\n"
        "B = MEDIUM\n"
        "C = HIGH\n\n"

        "Do not assume that generating vector instructions "
        "automatically means high benefit.\n\n"

        "Static program features:\n"
        f"{feature_text(mlir)}\n\n"

        "MLIR:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```\n\n"

        "Return exactly one code: A, B, or C."
    )


def prompt_text(row):

    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content":
                    task_text_abc(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


# ============================================================
# Important:
#
# The training sequence is:
#
#     PROMPT + ONE CLASS TOKEN
#
# Labels:
#
#     -100 ... -100, CLASS_TOKEN
#
# No EOS/chat-template suffix contributes to training loss.
# ============================================================

class ABCDataset(Dataset):

    def __init__(
        self,
        dataframe,
    ):

        self.examples = []


        for _, row in dataframe.iterrows():

            p_text = prompt_text(
                row
            )

            p_ids = tokenizer(
                p_text,
                add_special_tokens=False,
            )["input_ids"]


            gold_class = str(
                row[
                    "rvv_benefit_class"
                ]
            )

            code = CLASS_TO_CODE[
                gold_class
            ]


            # Tokenize in context, rather than assuming
            # standalone tokenization is identical.
            full_ids = tokenizer(
                p_text + code,
                add_special_tokens=False,
            )["input_ids"]


            if (
                full_ids[
                    :len(p_ids)
                ]
                != p_ids
            ):
                raise RuntimeError(
                    "Prompt prefix mismatch"
                )


            continuation = full_ids[
                len(p_ids):
            ]


            if len(continuation) != 1:
                raise RuntimeError(
                    f"Expected one class token, "
                    f"got {continuation} "
                    f"for {code}"
                )


            class_token_id = (
                continuation[0]
            )


            input_ids = (
                p_ids
                + [class_token_id]
            )


            if (
                len(input_ids)
                > MAX_SEQ_LEN
            ):
                raise RuntimeError(
                    f"Context overflow: "
                    f"{len(input_ids)}"
                )


            labels = (
                [-100] * len(p_ids)
                + [class_token_id]
            )


            attention_mask = (
                [1] * len(input_ids)
            )


            self.examples.append(
                {
                    "input_ids":
                        input_ids,

                    "attention_mask":
                        attention_mask,

                    "labels":
                        labels,
                }
            )


    def __len__(self):
        return len(
            self.examples
        )


    def __getitem__(
        self,
        idx,
    ):
        return self.examples[
            idx
        ]


class Collator:

    def __init__(
        self,
        tokenizer,
    ):
        self.tokenizer = tokenizer


    def __call__(
        self,
        features,
    ):

        max_len = max(
            len(
                x["input_ids"]
            )
            for x in features
        )


        ids = []
        masks = []
        labels = []


        for x in features:

            pad = (
                max_len
                - len(
                    x["input_ids"]
                )
            )


            ids.append(
                x["input_ids"]
                + [
                    self.tokenizer
                    .pad_token_id
                ] * pad
            )


            masks.append(
                x["attention_mask"]
                + [0] * pad
            )


            labels.append(
                x["labels"]
                + [-100] * pad
            )


        return {
            "input_ids":
                torch.tensor(
                    ids,
                    dtype=torch.long,
                ),

            "attention_mask":
                torch.tensor(
                    masks,
                    dtype=torch.long,
                ),

            "labels":
                torch.tensor(
                    labels,
                    dtype=torch.long,
                ),
        }


train_dataset = ABCDataset(
    balanced_train
)

val_dataset = ABCDataset(
    val_df
)

collator = Collator(
    tokenizer
)


# ============================================================
# Model
#
# SAME light LoRA configuration as before.
# ============================================================

model = (
    AutoModelForCausalLM
    .from_pretrained(
        MODEL,
        dtype=torch.bfloat16,
        low_cpu_mem_usage=True,
        trust_remote_code=True,
    )
)

model.config.use_cache = False

model.gradient_checkpointing_enable()


lora = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.0,
    bias="none",
    task_type="CAUSAL_LM",

    target_modules=[
        "q_proj",
        "v_proj",
    ],
)


model = get_peft_model(
    model,
    lora,
)

model.print_trainable_parameters()


# ============================================================
# Trainer
# ============================================================

params = inspect.signature(
    TrainingArguments.__init__
).parameters


kwargs = {
    "output_dir":
        str(CHECKPOINTS),

    "num_train_epochs":
        NUM_EPOCHS,

    "per_device_train_batch_size":
        1,

    "per_device_eval_batch_size":
        1,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "learning_rate":
        LEARNING_RATE,

    "bf16":
        True,

    "logging_steps":
        10,

    "save_strategy":
        "epoch",

    "save_total_limit":
        3,

    "report_to":
        "none",

    "seed":
        SEED,

    "remove_unused_columns":
        False,

    "gradient_checkpointing":
        True,
}


if "eval_strategy" in params:

    kwargs[
        "eval_strategy"
    ] = "epoch"

elif (
    "evaluation_strategy"
    in params
):

    kwargs[
        "evaluation_strategy"
    ] = "epoch"

else:

    raise RuntimeError(
        "No evaluation strategy argument"
    )


kwargs[
    "load_best_model_at_end"
] = True

kwargs[
    "metric_for_best_model"
] = "eval_loss"

kwargs[
    "greater_is_better"
] = False


if "warmup_steps" in params:
    kwargs[
        "warmup_steps"
    ] = 20


trainer = Trainer(
    model=model,
    args=TrainingArguments(
        **kwargs
    ),
    train_dataset=
        train_dataset,
    eval_dataset=
        val_dataset,
    data_collator=
        collator,
)


trainer.train()


# Trainer has restored the lowest validation-loss checkpoint.
trainer.save_model(
    str(ADAPTER)
)

tokenizer.save_pretrained(
    str(ADAPTER)
)


metadata = {
    "fold":
        FOLD,

    "model":
        MODEL,

    "target_encoding": {
        "A": "LOW",
        "B": "MEDIUM",
        "C": "HIGH",
    },

    "loss":
        "single class token only",

    "train_examples_original":
        len(train_df),

    "train_examples_balanced":
        len(balanced_train),

    "val_examples":
        len(val_df),

    "epochs":
        NUM_EPOCHS,

    "learning_rate":
        LEARNING_RATE,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "lora_r":
        16,

    "lora_alpha":
        32,

    "target_modules":
        [
            "q_proj",
            "v_proj",
        ],

    "best_model_checkpoint":
        trainer.state
        .best_model_checkpoint,

    "best_eval_loss":
        trainer.state
        .best_metric,
}


with (
    RUN
    / "training_metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print("\n" + "=" * 72)
print("TRAINING COMPLETE")
print("=" * 72)

print(
    json.dumps(
        metadata,
        indent=2,
    )
)

print(
    "\nSaved adapter:",
    ADAPTER,
)
