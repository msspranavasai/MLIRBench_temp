import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch

from peft import PeftModel

from tqdm.auto import tqdm

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"

DATA = ROOT / "data" / "folds"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    extract_label,
    metrics_dict,
    zero_shot_prompt,
)


parser = argparse.ArgumentParser()

parser.add_argument(
    "--fold",
    type=int,
    required=True,
)

args = parser.parse_args()

FOLD = args.fold


MODEL = (
    "Qwen/Qwen2.5-Coder-14B-Instruct"
)

RUN = (
    ROOT
    / "outputs"
    / f"sft_fold_{FOLD}"
)

ADAPTER = RUN / "adapter"

MAX_NEW_TOKENS = 16
BATCH_SIZE = 4


with (
    DATA
    / f"fold_{FOLD}"
    / "test.json"
).open() as f:

    df = pd.DataFrame(
        json.load(f)
    )


tokenizer = (
    AutoTokenizer
    .from_pretrained(
        ADAPTER,
        trust_remote_code=True,
    )
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )

tokenizer.padding_side = "left"


base = (
    AutoModelForCausalLM
    .from_pretrained(
        MODEL,
        dtype=torch.bfloat16,
        device_map={"": 0},
        trust_remote_code=True,
    )
)


model = PeftModel.from_pretrained(
    base,
    ADAPTER,
)

model.eval()


predictions = []
raw_outputs = []


for start in tqdm(
    range(
        0,
        len(df),
        BATCH_SIZE,
    ),
    desc=f"SFT fold {FOLD}",
):

    batch = df.iloc[
        start:
        start + BATCH_SIZE
    ]


    prompts = [
        zero_shot_prompt(
            tokenizer,
            row,
        )

        for _, row
        in batch.iterrows()
    ]


    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to("cuda")


    with torch.inference_mode():

        outputs = model.generate(
            **inputs,
            max_new_tokens=
                MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=
                tokenizer.pad_token_id,
            eos_token_id=
                tokenizer.eos_token_id,
        )


    input_len = (
        inputs["input_ids"]
        .shape[1]
    )


    for output in outputs:

        raw = tokenizer.decode(
            output[input_len:],
            skip_special_tokens=True,
        ).strip()


        raw_outputs.append(raw)

        predictions.append(
            extract_label(raw)
        )


result = df.copy()

result["prediction"] = (
    predictions
)

result["raw_output"] = (
    raw_outputs
)

result["outer_fold"] = FOLD


result.to_csv(
    RUN
    / "test_predictions.csv",
    index=False,
)


metrics = metrics_dict(
    result["rvv_benefit_class"],
    result["prediction"],
)


with (
    RUN
    / "test_metrics.json"
).open("w") as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


print(
    json.dumps(
        metrics,
        indent=2,
    )
)
