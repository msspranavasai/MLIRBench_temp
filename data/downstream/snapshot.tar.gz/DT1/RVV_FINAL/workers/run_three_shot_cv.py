import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"
DATA = ROOT / "data" / "folds"
OUT = ROOT / "outputs"

OUT.mkdir(parents=True, exist_ok=True)

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    CLASSES,
    extract_label,
    few_shot_prompt,
    metrics_dict,
)


parser = argparse.ArgumentParser()

parser.add_argument(
    "--seed",
    type=int,
    required=True,
)

args = parser.parse_args()
SEED = args.seed


MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 16
BATCH_SIZE = 2


def load(fold, split):
    with (
        DATA
        / f"fold_{fold}"
        / f"{split}.json"
    ).open() as f:
        return pd.DataFrame(
            json.load(f)
        )


# ============================================================
# Tokenizer + model
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    MODEL,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"


model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model.eval()


all_results = []
all_examples = {}


# ============================================================
# Evaluate all five held-out folds
# ============================================================

for fold in range(5):

    train = load(
        fold,
        "train",
    )

    test = load(
        fold,
        "test",
    )


    # --------------------------------------------------------
    # One training demonstration per benefit class.
    #
    # Prefer short demonstrations for context efficiency.
    # Sample deterministically among the 10 shortest.
    # --------------------------------------------------------

    examples = []

    for class_index, label in enumerate(
        CLASSES
    ):

        subset = train[
            train["rvv_benefit_class"]
            == label
        ].copy()

        if subset.empty:
            raise RuntimeError(
                f"No {label} training example "
                f"in fold {fold}"
            )

        subset["mlir_chars"] = (
            subset["mutated_mlir"]
            .astype(str)
            .str.len()
        )

        pool = (
            subset
            .sort_values("mlir_chars")
            .head(
                min(
                    10,
                    len(subset),
                )
            )
        )

        example = pool.sample(
            n=1,
            random_state=(
                SEED
                + fold * 100
                + class_index
            ),
        ).iloc[0]

        examples.append(
            example
        )


    print(
        "\n"
        + "=" * 72
    )

    print(
        f"3-SHOT SEED {SEED} "
        f"FOLD {fold}"
    )

    print(
        "=" * 72
    )

    for ex in examples:
        print(
            ex["dt1_id"],
            "family=",
            ex["base_family"],
            "class=",
            ex["rvv_benefit_class"],
        )


    all_examples[str(fold)] = [
        {
            "dt1_id":
                str(ex["dt1_id"]),

            "base_family":
                str(ex["base_family"]),

            "rvv_benefit_class":
                str(
                    ex[
                        "rvv_benefit_class"
                    ]
                ),
        }

        for ex in examples
    ]


    # --------------------------------------------------------
    # Context-length preflight
    # --------------------------------------------------------

    prompt_lengths = []

    for _, row in test.iterrows():

        prompt = few_shot_prompt(
            tokenizer,
            row,
            examples,
        )

        length = len(
            tokenizer(
                prompt,
                add_special_tokens=False,
            )["input_ids"]
        )

        prompt_lengths.append(
            length
        )


    print(
        "Prompt lengths:",
        "min=",
        min(prompt_lengths),
        "mean=",
        sum(prompt_lengths)
        / len(prompt_lengths),
        "max=",
        max(prompt_lengths),
    )


    if (
        max(prompt_lengths)
        + MAX_NEW_TOKENS
        > MAX_SEQ_LEN
    ):
        raise RuntimeError(
            f"Context overflow in fold {fold}"
        )


    # --------------------------------------------------------
    # Generation
    # --------------------------------------------------------

    predictions = []
    raw_outputs = []


    for start in tqdm(
        range(
            0,
            len(test),
            BATCH_SIZE,
        ),
        desc=(
            f"3-shot seed {SEED} "
            f"fold {fold}"
        ),
    ):

        batch = test.iloc[
            start:
            start + BATCH_SIZE
        ]

        prompts = [
            few_shot_prompt(
                tokenizer,
                row,
                examples,
            )
            for _, row
            in batch.iterrows()
        ]


        inputs = tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=False,
        ).to("cuda")


        with torch.inference_mode():

            outputs = model.generate(
                **inputs,
                max_new_tokens=
                    MAX_NEW_TOKENS,
                do_sample=False,
                pad_token_id=
                    tokenizer.pad_token_id,
                eos_token_id=
                    tokenizer.eos_token_id,
            )


        input_len = (
            inputs["input_ids"]
            .shape[1]
        )


        for output in outputs:

            raw = tokenizer.decode(
                output[input_len:],
                skip_special_tokens=True,
            ).strip()

            raw_outputs.append(
                raw
            )

            predictions.append(
                extract_label(raw)
            )


    # --------------------------------------------------------
    # Per-fold output
    # --------------------------------------------------------

    result = test.copy()

    result["prediction"] = (
        predictions
    )

    result["raw_output"] = (
        raw_outputs
    )

    result["outer_fold"] = (
        fold
    )

    result["correct"] = (
        result["prediction"]
        == result[
            "rvv_benefit_class"
        ]
    )


    fold_metrics = metrics_dict(
        result[
            "rvv_benefit_class"
        ],
        result["prediction"],
    )


    print(
        "\nFold metrics:"
    )

    print(
        json.dumps(
            fold_metrics,
            indent=2,
        )
    )


    result.to_csv(
        OUT
        / (
            f"three_shot_seed_{SEED}"
            f"_fold_{fold}_predictions.csv"
        ),
        index=False,
    )


    with (
        OUT
        / (
            f"three_shot_seed_{SEED}"
            f"_fold_{fold}_metrics.json"
        )
    ).open("w") as f:

        json.dump(
            fold_metrics,
            f,
            indent=2,
        )


    all_results.append(
        result
    )


# ============================================================
# Aggregate across all five held-out folds
# ============================================================

combined = pd.concat(
    all_results,
    ignore_index=True,
)


if len(combined) != 675:
    raise RuntimeError(
        f"Expected 675 total predictions, "
        f"got {len(combined)}"
    )


if (
    combined["dt1_id"].nunique()
    != 675
):
    raise RuntimeError(
        "Duplicate or missing programs "
        "across outer folds."
    )


combined.to_csv(
    OUT
    / (
        f"three_shot_seed_{SEED}"
        "_cv_predictions.csv"
    ),
    index=False,
)


metrics = metrics_dict(
    combined[
        "rvv_benefit_class"
    ],
    combined["prediction"],
)


with (
    OUT
    / (
        f"three_shot_seed_{SEED}"
        "_cv_metrics.json"
    )
).open("w") as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


with (
    OUT
    / (
        f"three_shot_seed_{SEED}"
        "_examples.json"
    )
).open("w") as f:

    json.dump(
        all_examples,
        f,
        indent=2,
    )


print(
    "\n"
    + "=" * 72
)

print(
    f"FINAL 3-SHOT SEED {SEED}"
)

print(
    "=" * 72
)

print(
    json.dumps(
        metrics,
        indent=2,
    )
)

print(
    "\nSaved:"
)

print(
    OUT
    / (
        f"three_shot_seed_{SEED}"
        "_cv_predictions.csv"
    )
)

print(
    OUT
    / (
        f"three_shot_seed_{SEED}"
        "_cv_metrics.json"
    )
)
