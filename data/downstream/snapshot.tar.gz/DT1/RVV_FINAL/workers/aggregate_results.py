import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"

OUT = ROOT / "outputs"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    apply_rvv,
    metrics_dict,
    materialize_plan,
)


# ============================================================
# Helpers
# ============================================================

def plan_metrics(df):

    frame = df.copy()


    frame[
        "oracle_apply_rvv"
    ] = (
        frame[
            "rvv_benefit_class"
        ]
        .isin(
            ["MEDIUM", "HIGH"]
        )
    )


    frame[
        "predicted_apply_rvv"
    ] = (
        frame["prediction"]
        .isin(
            ["MEDIUM", "HIGH"]
        )
    )


    frame[
        "plan_correct"
    ] = (
        frame[
            "oracle_apply_rvv"
        ]
        == frame[
            "predicted_apply_rvv"
        ]
    )


    missed = (
        frame[
            "oracle_apply_rvv"
        ]
        & ~frame[
            "predicted_apply_rvv"
        ]
    )


    unnecessary = (
        ~frame[
            "oracle_apply_rvv"
        ]
        & frame[
            "predicted_apply_rvv"
        ]
    )


    harmful = (
        frame[
            "predicted_apply_rvv"
        ]
        & (
            frame[
                "reduction_pct"
            ] <= 0
        )
    )


    # If model selects scalar:
    # realized reduction = 0.
    #
    # If model selects RVV:
    # realized reduction = measured RVV reduction.
    frame[
        "realized_reduction_pct"
    ] = np.where(
        frame[
            "predicted_apply_rvv"
        ],
        frame[
            "reduction_pct"
        ],
        0.0,
    )


    frame[
        "oracle_reduction_pct"
    ] = np.where(
        frame[
            "oracle_apply_rvv"
        ],
        frame[
            "reduction_pct"
        ],
        0.0,
    )


    # Utility relative to the frozen 5% profitability threshold.
    frame[
        "threshold_utility"
    ] = np.where(
        frame[
            "predicted_apply_rvv"
        ],
        frame[
            "reduction_pct"
        ] - 5.0,
        0.0,
    )


    frame[
        "oracle_threshold_utility"
    ] = np.maximum(
        frame[
            "reduction_pct"
        ] - 5.0,
        0.0,
    )


    return {
        "plan_accuracy":
            float(
                frame[
                    "plan_correct"
                ].mean()
            ),

        "missed_profitable_rvv":
            int(missed.sum()),

        "unprofitable_rvv_applications":
            int(
                unnecessary.sum()
            ),

        "harmful_rvv_applications":
            int(
                harmful.sum()
            ),

        "mean_realized_reduction_pct":
            float(
                frame[
                    "realized_reduction_pct"
                ].mean()
            ),

        "median_realized_reduction_pct":
            float(
                frame[
                    "realized_reduction_pct"
                ].median()
            ),

        "oracle_mean_reduction_pct":
            float(
                frame[
                    "oracle_reduction_pct"
                ].mean()
            ),

        "mean_threshold_utility":
            float(
                frame[
                    "threshold_utility"
                ].mean()
            ),

        "oracle_mean_threshold_utility":
            float(
                frame[
                    "oracle_threshold_utility"
                ].mean()
            ),
    }


def load_sft():

    pieces = []

    for fold in range(5):

        path = (
            OUT
            / f"sft_fold_{fold}"
            / "test_predictions.csv"
        )

        part = pd.read_csv(path)

        pieces.append(part)

    return pd.concat(
        pieces,
        ignore_index=True,
    )


methods = {
    "Static RF":
        pd.read_csv(
            OUT
            / "static_cv_predictions.csv"
        ),

    "Zero-shot":
        pd.read_csv(
            OUT
            / "zero_cv_predictions.csv"
        ),

    "3-shot seed 42":
        pd.read_csv(
            OUT
            / (
                "three_shot_seed_42"
                "_cv_predictions.csv"
            )
        ),

    "3-shot seed 123":
        pd.read_csv(
            OUT
            / (
                "three_shot_seed_123"
                "_cv_predictions.csv"
            )
        ),

    "MLIRBench SFT":
        load_sft(),
}


summary_rows = []
full_summary = {}


for method, df in methods.items():

    if len(df) != 675:
        raise RuntimeError(
            f"{method}: expected 675 test "
            f"predictions, got {len(df)}"
        )


    if df["dt1_id"].nunique() != 675:
        raise RuntimeError(
            f"{method}: duplicate or missing "
            "test programs."
        )


    classification = metrics_dict(
        df["rvv_benefit_class"],
        df["prediction"],
    )


    planning = plan_metrics(
        df
    )


    full_summary[method] = {
        "classification":
            classification,

        "planning":
            planning,
    }


    summary_rows.append(
        {
            "method":
                method,

            "accuracy":
                classification[
                    "accuracy"
                ],

            "macro_f1":
                classification[
                    "macro_f1"
                ],

            "ordinal_mae":
                classification[
                    "ordinal_mae"
                ],

            "severe_error_rate":
                classification[
                    "severe_error_rate"
                ],

            "plan_accuracy":
                planning[
                    "plan_accuracy"
                ],

            "mean_realized_reduction_pct":
                planning[
                    "mean_realized_reduction_pct"
                ],

            "missed_profitable_rvv":
                planning[
                    "missed_profitable_rvv"
                ],

            "unprofitable_rvv":
                planning[
                    "unprofitable_rvv_applications"
                ],
        }
    )


summary = pd.DataFrame(
    summary_rows
)


summary.to_csv(
    OUT / "FINAL_SUMMARY.csv",
    index=False,
)


with (
    OUT / "FINAL_SUMMARY.json"
).open("w") as f:

    json.dump(
        full_summary,
        f,
        indent=2,
    )


print("\n" + "=" * 100)

print(
    "FINAL MLIRBENCH RISC-V RESULTS"
)

print("=" * 100)

print(
    summary.to_string(
        index=False
    )
)


# ============================================================
# MLIRBench improvement over same pretrained model
# ============================================================

zero = full_summary[
    "Zero-shot"
]["classification"]

sft = full_summary[
    "MLIRBench SFT"
]["classification"]


print("\n" + "=" * 100)

print(
    "MLIRBENCH SUPERVISION GAIN"
)

print("=" * 100)

print(
    "Accuracy gain:",
    (
        sft["accuracy"]
        - zero["accuracy"]
    ),
)

print(
    "Macro-F1 gain:",
    (
        sft["macro_f1"]
        - zero["macro_f1"]
    ),
)

print(
    "Ordinal MAE reduction:",
    (
        zero["ordinal_mae"]
        - sft["ordinal_mae"]
    ),
)
