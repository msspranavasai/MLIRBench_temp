import json
import sys
from pathlib import Path

import pandas as pd

from sklearn.ensemble import (
    RandomForestClassifier,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"

DATA = ROOT / "data" / "folds"
OUT = ROOT / "outputs"

OUT.mkdir(
    parents=True,
    exist_ok=True,
)

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import (
    metrics_dict,
    static_features,
)


def load(fold, split):

    with (
        DATA
        / f"fold_{fold}"
        / f"{split}.json"
    ).open() as f:

        return pd.DataFrame(
            json.load(f)
        )


def matrix(df):

    rows = [
        static_features(x)
        for x in df["mutated_mlir"]
    ]

    return pd.DataFrame(rows)


all_predictions = []


for fold in range(5):

    train = load(
        fold,
        "train",
    )

    test = load(
        fold,
        "test",
    )

    X_train = matrix(train)
    X_test = matrix(test)

    X_test = X_test[
        X_train.columns
    ]


    model = RandomForestClassifier(
        n_estimators=500,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )

    model.fit(
        X_train,
        train["rvv_benefit_class"],
    )


    prediction = model.predict(
        X_test
    )


    result = test.copy()

    result["prediction"] = prediction
    result["outer_fold"] = fold

    all_predictions.append(
        result
    )


    metrics = metrics_dict(
        result["rvv_benefit_class"],
        result["prediction"],
    )

    print(
        f"\nFOLD {fold}"
    )

    print(
        json.dumps(
            metrics,
            indent=2,
        )
    )


combined = pd.concat(
    all_predictions,
    ignore_index=True,
)


combined.to_csv(
    OUT
    / "static_cv_predictions.csv",
    index=False,
)


metrics = metrics_dict(
    combined["rvv_benefit_class"],
    combined["prediction"],
)


with (
    OUT
    / "static_cv_metrics.json"
).open("w") as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


print("\n" + "=" * 72)
print("STATIC 5-FOLD CV")
print("=" * 72)

print(
    json.dumps(
        metrics,
        indent=2,
    )
)
