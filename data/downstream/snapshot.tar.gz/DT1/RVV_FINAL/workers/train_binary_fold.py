import argparse
import inspect
import json
import sys
from pathlib import Path

import pandas as pd
import torch
from peft import LoraConfig, get_peft_model
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"
DATA = ROOT / "data" / "folds"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import feature_text


parser = argparse.ArgumentParser()

parser.add_argument(
    "--fold",
    type=int,
    required=True,
)

args = parser.parse_args()

FOLD = args.fold

MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

SEED = 42
NUM_EPOCHS = 3
LEARNING_RATE = 1e-4
GRAD_ACCUM = 4

MAX_SEQ_LEN = 32768


RUN = (
    ROOT
    / "outputs"
    / "binary"
    / f"fold_{FOLD}"
)

ADAPTER = RUN / "adapter"
CHECKPOINTS = RUN / "checkpoints"

ADAPTER.mkdir(
    parents=True,
    exist_ok=True,
)

CHECKPOINTS.mkdir(
    parents=True,
    exist_ok=True,
)


def load(split):
    with (
        DATA
        / f"fold_{FOLD}"
        / f"{split}.json"
    ).open() as f:
        return pd.DataFrame(
            json.load(f)
        )


train_df = load("train")
val_df = load("val")


def add_binary_target(df):
    df = df.copy()

    df["binary_target"] = (
        df["rvv_benefit_class"]
        .map(
            {
                "LOW":
                    "KEEP_SCALAR",

                "MEDIUM":
                    "APPLY_RVV",

                "HIGH":
                    "APPLY_RVV",
            }
        )
    )

    return df


train_df = add_binary_target(
    train_df
)

val_df = add_binary_target(
    val_df
)


# ============================================================
# Balance the two compiler decisions in TRAIN only.
# ============================================================

largest = (
    train_df["binary_target"]
    .value_counts()
    .max()
)


balanced = []

for index, target in enumerate(
    [
        "KEEP_SCALAR",
        "APPLY_RVV",
    ]
):

    subset = train_df[
        train_df["binary_target"]
        == target
    ]

    balanced.append(
        subset.sample(
            n=largest,
            replace=(
                len(subset)
                < largest
            ),
            random_state=(
                SEED
                + FOLD * 100
                + index
            ),
        )
    )


train_balanced = (
    pd.concat(
        balanced,
        ignore_index=True,
    )
    .sample(
        frac=1.0,
        random_state=
            SEED + FOLD,
    )
    .reset_index(
        drop=True
    )
)


print("=" * 72)
print(
    f"BINARY RVV PLAN SFT FOLD {FOLD}"
)
print("=" * 72)

print("\nOriginal train:")
print(
    train_df[
        "binary_target"
    ].value_counts()
)

print("\nBalanced train:")
print(
    train_balanced[
        "binary_target"
    ].value_counts()
)

print("\nValidation:")
print(
    val_df[
        "binary_target"
    ].value_counts()
)


tokenizer = AutoTokenizer.from_pretrained(
    MODEL,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )

tokenizer.padding_side = "right"


TARGET_TO_CODE = {
    "KEEP_SCALAR": "A",
    "APPLY_RVV": "B",
}


for code in ["A", "B"]:

    ids = tokenizer(
        code,
        add_special_tokens=False,
    )["input_ids"]

    if len(ids) != 1:
        raise RuntimeError(
            f"{code} is not one token: {ids}"
        )


def task_text_binary(row):

    mlir = str(
        row["mutated_mlir"]
    )

    return (
        "You are a compiler optimization planner for "
        "64-bit RISC-V.\n\n"

        "This MLIR program successfully produces code under "
        "both scalar RISC-V and RVV-enabled RISC-V.\n\n"

        "Your task is to decide whether enabling the "
        "RISC-V Vector Extension is sufficiently profitable "
        "for this program.\n\n"

        "Decision rule:\n"
        "KEEP_SCALAR: measured static instruction-count "
        "reduction from RVV is less than 5%.\n"

        "APPLY_RVV: measured static instruction-count "
        "reduction from RVV is at least 5%.\n\n"

        "Use exactly one output code:\n"
        "A = KEEP_SCALAR\n"
        "B = APPLY_RVV\n\n"

        "Static program features:\n"
        f"{feature_text(mlir)}\n\n"

        "MLIR:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```\n\n"

        "Return exactly one code: A or B."
    )


def prompt_text(row):

    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content":
                    task_text_binary(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


class BinaryDataset(Dataset):

    def __init__(
        self,
        dataframe,
    ):

        self.examples = []


        for _, row in dataframe.iterrows():

            prompt = prompt_text(
                row
            )

            prompt_ids = tokenizer(
                prompt,
                add_special_tokens=False,
            )["input_ids"]


            code = TARGET_TO_CODE[
                row["binary_target"]
            ]


            full_ids = tokenizer(
                prompt + code,
                add_special_tokens=False,
            )["input_ids"]


            if (
                full_ids[
                    :len(prompt_ids)
                ]
                != prompt_ids
            ):
                raise RuntimeError(
                    "Prompt prefix mismatch"
                )


            continuation = full_ids[
                len(prompt_ids):
            ]


            if len(continuation) != 1:
                raise RuntimeError(
                    f"Expected one class token, "
                    f"got {continuation}"
                )


            token_id = continuation[0]


            input_ids = (
                prompt_ids
                + [token_id]
            )


            if len(input_ids) > MAX_SEQ_LEN:
                raise RuntimeError(
                    "Context overflow"
                )


            self.examples.append(
                {
                    "input_ids":
                        input_ids,

                    "attention_mask":
                        [1]
                        * len(input_ids),

                    "labels":
                        [-100]
                        * len(prompt_ids)
                        + [token_id],
                }
            )


    def __len__(self):
        return len(
            self.examples
        )


    def __getitem__(
        self,
        idx,
    ):
        return self.examples[
            idx
        ]


class Collator:

    def __init__(
        self,
        tokenizer,
    ):
        self.tokenizer = tokenizer


    def __call__(
        self,
        features,
    ):

        max_len = max(
            len(
                x["input_ids"]
            )
            for x in features
        )


        ids = []
        masks = []
        labels = []


        for x in features:

            pad = (
                max_len
                - len(
                    x["input_ids"]
                )
            )


            ids.append(
                x["input_ids"]
                + [
                    self.tokenizer
                    .pad_token_id
                ] * pad
            )


            masks.append(
                x["attention_mask"]
                + [0] * pad
            )


            labels.append(
                x["labels"]
                + [-100] * pad
            )


        return {
            "input_ids":
                torch.tensor(
                    ids,
                    dtype=torch.long,
                ),

            "attention_mask":
                torch.tensor(
                    masks,
                    dtype=torch.long,
                ),

            "labels":
                torch.tensor(
                    labels,
                    dtype=torch.long,
                ),
        }


train_dataset = BinaryDataset(
    train_balanced
)

val_dataset = BinaryDataset(
    val_df
)

collator = Collator(
    tokenizer
)


model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    dtype=torch.bfloat16,
    low_cpu_mem_usage=True,
    trust_remote_code=True,
)

model.config.use_cache = False

model.gradient_checkpointing_enable()


lora = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.0,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=[
        "q_proj",
        "v_proj",
    ],
)


model = get_peft_model(
    model,
    lora,
)

model.print_trainable_parameters()


params = inspect.signature(
    TrainingArguments.__init__
).parameters


kwargs = {
    "output_dir":
        str(CHECKPOINTS),

    "num_train_epochs":
        NUM_EPOCHS,

    "per_device_train_batch_size":
        1,

    "per_device_eval_batch_size":
        1,

    "gradient_accumulation_steps":
        GRAD_ACCUM,

    "learning_rate":
        LEARNING_RATE,

    "bf16":
        True,

    "logging_steps":
        10,

    "save_strategy":
        "epoch",

    "save_total_limit":
        3,

    "report_to":
        "none",

    "seed":
        SEED,

    "remove_unused_columns":
        False,

    "gradient_checkpointing":
        True,
}


if "eval_strategy" in params:
    kwargs[
        "eval_strategy"
    ] = "epoch"

else:
    kwargs[
        "evaluation_strategy"
    ] = "epoch"


kwargs[
    "load_best_model_at_end"
] = True

kwargs[
    "metric_for_best_model"
] = "eval_loss"

kwargs[
    "greater_is_better"
] = False


if "warmup_steps" in params:
    kwargs[
        "warmup_steps"
    ] = 20


trainer = Trainer(
    model=model,
    args=TrainingArguments(
        **kwargs
    ),
    train_dataset=
        train_dataset,
    eval_dataset=
        val_dataset,
    data_collator=
        collator,
)


trainer.train()


trainer.save_model(
    str(ADAPTER)
)

tokenizer.save_pretrained(
    str(ADAPTER)
)


metadata = {
    "fold":
        FOLD,

    "target":
        "RISC-V optimization decision",

    "encoding": {
        "A":
            "KEEP_SCALAR",

        "B":
            "APPLY_RVV",
    },

    "profitability_threshold":
        5.0,

    "train_original":
        len(train_df),

    "train_balanced":
        len(train_balanced),

    "val":
        len(val_df),

    "best_model_checkpoint":
        trainer.state
        .best_model_checkpoint,

    "best_eval_loss":
        trainer.state
        .best_metric,
}


with (
    RUN
    / "training_metadata.json"
).open("w") as f:

    json.dump(
        metadata,
        f,
        indent=2,
    )


print(
    json.dumps(
        metadata,
        indent=2,
    )
)
