import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import torch

from peft import PeftModel
from tqdm.auto import tqdm
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
)

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"
DATA = ROOT / "data" / "folds"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import feature_text


parser = argparse.ArgumentParser()

parser.add_argument(
    "--fold",
    type=int,
    required=True,
)

parser.add_argument(
    "--split",
    choices=[
        "train",
        "val",
        "test",
    ],
    default="val",
)

parser.add_argument(
    "--adapter-dir",
    type=str,
    default=None,
)

args = parser.parse_args()

FOLD = args.fold
SPLIT = args.split


MODEL = "Qwen/Qwen2.5-Coder-14B-Instruct"

RUN = (
    ROOT
    / "outputs"
    / "binary"
    / f"fold_{FOLD}"
)

ADAPTER = (
    Path(args.adapter_dir)
    if args.adapter_dir
    else RUN / "adapter"
)


with (
    DATA
    / f"fold_{FOLD}"
    / f"{SPLIT}.json"
).open() as f:

    df = pd.DataFrame(
        json.load(f)
    )


# ============================================================
# Gold compiler decision
# ============================================================

df["gold_decision"] = (
    df["rvv_benefit_class"]
    .map(
        {
            "LOW":
                "KEEP_SCALAR",

            "MEDIUM":
                "APPLY_RVV",

            "HIGH":
                "APPLY_RVV",
        }
    )
)


# ============================================================
# Tokenizer
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    ADAPTER,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = (
        tokenizer.eos_token
    )


def task_text_binary(row):

    mlir = str(
        row["mutated_mlir"]
    )

    return (
        "You are a compiler optimization planner for "
        "64-bit RISC-V.\n\n"

        "This MLIR program successfully produces code under "
        "both scalar RISC-V and RVV-enabled RISC-V.\n\n"

        "Your task is to decide whether enabling the "
        "RISC-V Vector Extension is sufficiently profitable "
        "for this program.\n\n"

        "Decision rule:\n"

        "KEEP_SCALAR: measured static instruction-count "
        "reduction from RVV is less than 5%.\n"

        "APPLY_RVV: measured static instruction-count "
        "reduction from RVV is at least 5%.\n\n"

        "Use exactly one output code:\n"
        "A = KEEP_SCALAR\n"
        "B = APPLY_RVV\n\n"

        "Static program features:\n"
        f"{feature_text(mlir)}\n\n"

        "MLIR:\n"
        "```mlir\n"
        f"{mlir}\n"
        "```\n\n"

        "Return exactly one code: A or B."
    )


def make_prompt(row):

    return tokenizer.apply_chat_template(
        [
            {
                "role": "user",
                "content":
                    task_text_binary(row),
            }
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


# ============================================================
# Resolve A/B token IDs in context
# ============================================================

sample_prompt = make_prompt(
    df.iloc[0]
)

sample_prompt_ids = tokenizer(
    sample_prompt,
    add_special_tokens=False,
)["input_ids"]


CODE_TOKEN_IDS = {}

for code in ["A", "B"]:

    full_ids = tokenizer(
        sample_prompt + code,
        add_special_tokens=False,
    )["input_ids"]

    if (
        full_ids[
            :len(sample_prompt_ids)
        ]
        != sample_prompt_ids
    ):
        raise RuntimeError(
            "Prompt prefix mismatch"
        )

    continuation = full_ids[
        len(sample_prompt_ids):
    ]

    if len(continuation) != 1:
        raise RuntimeError(
            f"{code} is not one token "
            f"in context: {continuation}"
        )

    CODE_TOKEN_IDS[
        code
    ] = continuation[0]


print("=" * 72)

print(
    f"BINARY DIRECT-LOGIT "
    f"{SPLIT.upper()} "
    f"FOLD {FOLD}"
)

print("=" * 72)

print("Examples:", len(df))

print(
    "Gold decisions:"
)

print(
    df["gold_decision"]
    .value_counts()
)

print(
    "\nCandidate token IDs:",
    CODE_TOKEN_IDS,
)


# ============================================================
# Load model
# ============================================================

print("\nLoading base model...")

base = AutoModelForCausalLM.from_pretrained(
    MODEL,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)


print(
    "Loading adapter:",
    ADAPTER,
)

model = PeftModel.from_pretrained(
    base,
    ADAPTER,
)

model.eval()

device = next(
    model.parameters()
).device


# ============================================================
# Direct A/B scoring
# ============================================================

records = []


for _, row in tqdm(
    df.iterrows(),
    total=len(df),
    desc=(
        f"Binary fold {FOLD} "
        f"{SPLIT}"
    ),
):

    prompt = make_prompt(
        row
    )

    ids = tokenizer(
        prompt,
        add_special_tokens=False,
    )["input_ids"]


    input_ids = torch.tensor(
        [ids],
        dtype=torch.long,
        device=device,
    )

    attention_mask = (
        torch.ones_like(
            input_ids
        )
    )


    with torch.inference_mode():

        output = model(
            input_ids=input_ids,
            attention_mask=
                attention_mask,
            use_cache=False,
        )


    logits = (
        output.logits[
            0,
            -1,
        ]
        .float()
    )


    logit_a = float(
        logits[
            CODE_TOKEN_IDS["A"]
        ].item()
    )

    logit_b = float(
        logits[
            CODE_TOKEN_IDS["B"]
        ].item()
    )


    pair_logits = torch.tensor(
        [
            logit_a,
            logit_b,
        ],
        dtype=torch.float32,
    )


    probs = torch.softmax(
        pair_logits,
        dim=0,
    )


    if logit_b > logit_a:

        predicted_code = "B"
        prediction = "APPLY_RVV"

    else:

        predicted_code = "A"
        prediction = "KEEP_SCALAR"


    record = row.to_dict()

    record[
        "gold_decision"
    ] = row["gold_decision"]

    record[
        "predicted_code"
    ] = predicted_code

    record[
        "prediction"
    ] = prediction

    record[
        "correct"
    ] = (
        prediction
        == row["gold_decision"]
    )

    record[
        "logit_A"
    ] = logit_a

    record[
        "logit_B"
    ] = logit_b

    record[
        "margin_B_minus_A"
    ] = (
        logit_b
        - logit_a
    )

    record[
        "prob_KEEP_SCALAR"
    ] = float(
        probs[0]
    )

    record[
        "prob_APPLY_RVV"
    ] = float(
        probs[1]
    )

    records.append(
        record
    )


result = pd.DataFrame(
    records
)


# ============================================================
# Metrics
# ============================================================

LABELS = [
    "KEEP_SCALAR",
    "APPLY_RVV",
]


y_true = result[
    "gold_decision"
]

y_pred = result[
    "prediction"
]


accuracy = accuracy_score(
    y_true,
    y_pred,
)

balanced_accuracy = (
    balanced_accuracy_score(
        y_true,
        y_pred,
    )
)

macro_f1 = f1_score(
    y_true,
    y_pred,
    labels=LABELS,
    average="macro",
    zero_division=0,
)

per_class_f1 = f1_score(
    y_true,
    y_pred,
    labels=LABELS,
    average=None,
    zero_division=0,
)

per_class_recall = recall_score(
    y_true,
    y_pred,
    labels=LABELS,
    average=None,
    zero_division=0,
)

per_class_precision = precision_score(
    y_true,
    y_pred,
    labels=LABELS,
    average=None,
    zero_division=0,
)


cm = confusion_matrix(
    y_true,
    y_pred,
    labels=LABELS,
)


gold_apply = (
    y_true
    == "APPLY_RVV"
)

pred_apply = (
    y_pred
    == "APPLY_RVV"
)


missed_profitable = (
    gold_apply
    & ~pred_apply
)

unprofitable_apply = (
    ~gold_apply
    & pred_apply
)


metrics = {
    "n":
        int(len(result)),

    "accuracy":
        float(accuracy),

    "balanced_accuracy":
        float(
            balanced_accuracy
        ),

    "macro_f1":
        float(macro_f1),

    "per_class_f1": {
        label:
            float(score)

        for label, score
        in zip(
            LABELS,
            per_class_f1,
        )
    },

    "per_class_recall": {
        label:
            float(score)

        for label, score
        in zip(
            LABELS,
            per_class_recall,
        )
    },

    "per_class_precision": {
        label:
            float(score)

        for label, score
        in zip(
            LABELS,
            per_class_precision,
        )
    },

    "missed_profitable_rvv":
        int(
            missed_profitable.sum()
        ),

    "missed_profitable_rvv_rate":
        float(
            missed_profitable.sum()
            / gold_apply.sum()
        ),

    "unprofitable_rvv":
        int(
            unprofitable_apply.sum()
        ),

    "unprofitable_rvv_rate":
        float(
            unprofitable_apply.sum()
            / (~gold_apply).sum()
        ),

    "confusion_matrix_labels":
        LABELS,

    "confusion_matrix":
        cm.tolist(),

    "fold":
        FOLD,

    "split":
        SPLIT,

    "adapter":
        str(ADAPTER),
}


# ============================================================
# Save
# ============================================================

suffix = (
    ADAPTER.name
    if args.adapter_dir
    else "best"
)


pred_path = (
    RUN
    / (
        f"{SPLIT}_predictions_"
        f"{suffix}.csv"
    )
)

metrics_path = (
    RUN
    / (
        f"{SPLIT}_metrics_"
        f"{suffix}.json"
    )
)


result.to_csv(
    pred_path,
    index=False,
)


with metrics_path.open(
    "w"
) as f:

    json.dump(
        metrics,
        f,
        indent=2,
    )


print("\n" + "=" * 72)
print("RESULT")
print("=" * 72)

print(
    json.dumps(
        metrics,
        indent=2,
    )
)


print(
    "\nPrediction distribution:"
)

print(
    result[
        "prediction"
    ].value_counts()
)


print(
    "\nGold vs prediction:"
)

print(
    pd.crosstab(
        result[
            "gold_decision"
        ],
        result[
            "prediction"
        ],
        margins=True,
    )
)


print(
    "\nMean probabilities by GOLD decision:"
)

print(
    result.groupby(
        "gold_decision"
    )[
        [
            "prob_KEEP_SCALAR",
            "prob_APPLY_RVV",
        ]
    ].mean()
)


print(
    "\nMean B-A margin by GOLD decision:"
)

print(
    result.groupby(
        "gold_decision"
    )[
        "margin_B_minus_A"
    ].mean()
)


print("\nSaved:")
print(pred_path)
print(metrics_path)
