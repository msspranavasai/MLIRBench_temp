import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.ensemble import (
    ExtraTreesClassifier,
    HistGradientBoostingClassifier,
    RandomForestClassifier,
)
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)


BASE = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/DT1"
)

ROOT = BASE / "RVV_FINAL"
DATA = ROOT / "data" / "folds"

sys.path.insert(
    0,
    str(ROOT / "workers"),
)

from common import static_features


FOLD = 0

LABELS = [
    "KEEP_SCALAR",
    "APPLY_RVV",
]


def load(split):

    with (
        DATA
        / f"fold_{FOLD}"
        / f"{split}.json"
    ).open() as f:

        df = pd.DataFrame(
            json.load(f)
        )

    df["binary_target"] = (
        df["rvv_benefit_class"]
        .map(
            {
                "LOW":
                    "KEEP_SCALAR",

                "MEDIUM":
                    "APPLY_RVV",

                "HIGH":
                    "APPLY_RVV",
            }
        )
    )

    return df


train = load("train")
val = load("val")


# ============================================================
# Extract exactly the static features available from MLIR.
# ============================================================

def feature_frame(df):

    rows = []

    for _, row in df.iterrows():

        features = static_features(
            str(
                row["mutated_mlir"]
            )
        )

        rows.append(
            features
        )

    return pd.DataFrame(
        rows
    )


X_train = feature_frame(
    train
)

X_val = feature_frame(
    val
)

# Ensure identical columns/order.
X_val = X_val.reindex(
    columns=X_train.columns,
    fill_value=0,
)

y_train = train[
    "binary_target"
]

y_val = val[
    "binary_target"
]


print("=" * 80)
print("BINARY TARGET LEARNABILITY DIAGNOSTIC")
print("=" * 80)

print("\nTrain:", len(train))
print(y_train.value_counts())

print("\nValidation:", len(val))
print(y_val.value_counts())

print("\nFeatures:", len(X_train.columns))
print(list(X_train.columns))


models = {
    "RandomForest": (
        RandomForestClassifier(
            n_estimators=1000,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
            max_features="sqrt",
        )
    ),

    "ExtraTrees": (
        ExtraTreesClassifier(
            n_estimators=1000,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
            max_features="sqrt",
        )
    ),

    "HistGradientBoosting": (
        HistGradientBoostingClassifier(
            max_iter=500,
            learning_rate=0.05,
            random_state=42,
        )
    ),
}


for name, model in models.items():

    print("\n" + "=" * 80)
    print(name)
    print("=" * 80)

    model.fit(
        X_train,
        y_train,
    )

    pred_train = model.predict(
        X_train
    )

    pred_val = model.predict(
        X_val
    )


    print("\nTRAIN")

    print(
        "Accuracy:",
        accuracy_score(
            y_train,
            pred_train,
        )
    )

    print(
        "Balanced accuracy:",
        balanced_accuracy_score(
            y_train,
            pred_train,
        )
    )

    print(
        "Macro-F1:",
        f1_score(
            y_train,
            pred_train,
            average="macro",
            zero_division=0,
        )
    )


    print("\nVALIDATION")

    print(
        "Accuracy:",
        accuracy_score(
            y_val,
            pred_val,
        )
    )

    print(
        "Balanced accuracy:",
        balanced_accuracy_score(
            y_val,
            pred_val,
        )
    )

    print(
        "Macro-F1:",
        f1_score(
            y_val,
            pred_val,
            average="macro",
            zero_division=0,
        )
    )


    print("\nConfusion matrix:")
    print(
        confusion_matrix(
            y_val,
            pred_val,
            labels=LABELS,
        )
    )


    print("\nClassification report:")

    print(
        classification_report(
            y_val,
            pred_val,
            labels=LABELS,
            zero_division=0,
        )
    )


    if hasattr(
        model,
        "feature_importances_",
    ):

        importance = (
            pd.DataFrame(
                {
                    "feature":
                        X_train.columns,

                    "importance":
                        model
                        .feature_importances_,
                }
            )
            .sort_values(
                "importance",
                ascending=False,
            )
        )

        print(
            "\nTop features:"
        )

        print(
            importance.head(15)
            .to_string(
                index=False
            )
        )
