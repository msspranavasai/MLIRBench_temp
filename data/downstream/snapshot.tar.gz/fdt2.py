import json
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# ============================================================
# CONFIG
# ============================================================

ROOT = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench"
)

# Source results from the full all-dataset run
SRC_BASE = ROOT / "outputs" / "dt2_all-dataset"
PRED_DIR = SRC_BASE / "predictions"
LOG_DIR = SRC_BASE / "logs"

# Output folder for the final figures package
OUT_BASE = ROOT / "outputs" / "dt2_all-dataset" / "outputs"
FIG_DIR = OUT_BASE / "figures2"
FIG_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# INPUT FILES
# ============================================================

ZERO_PATH = PRED_DIR / "all-dataset_zero_shot_metrics.json"
SHOT42_PATH = PRED_DIR / "all-dataset_6shot_seed_42_metrics.json"
SHOT123_PATH = PRED_DIR / "all-dataset_6shot_seed_123_metrics.json"
SFT_TEST_PATH = PRED_DIR / "all-dataset_sft_test_metrics.json"
SFT_LOG_PATH = LOG_DIR / "sft_ddp.log"

required = [
    ZERO_PATH,
    SHOT42_PATH,
    SHOT123_PATH,
    SFT_TEST_PATH,
    SFT_LOG_PATH,
]

missing = [str(p) for p in required if not p.exists()]
if missing:
    raise FileNotFoundError(
        "Missing required input files:\n" + "\n".join(missing)
    )


# ============================================================
# HELPERS
# ============================================================

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)


def pct(x):
    return 100.0 * float(x)


def add_value_labels(ax, bars, decimals=1, y_offset=0.8):
    for bar in bars:
        h = bar.get_height()
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            h + y_offset,
            f"{h:.{decimals}f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )


def mean_metric(m1, m2, top_key, metric_name):
    return (m1[top_key][metric_name] + m2[top_key][metric_name]) / 2.0


def mean_nested_metric(m1, m2, top_key, nested_key, metric_name):
    return (
        m1[top_key][nested_key][metric_name]
        + m2[top_key][nested_key][metric_name]
    ) / 2.0


# ============================================================
# LOAD METRICS
# ============================================================

zero = load_json(ZERO_PATH)
shot42 = load_json(SHOT42_PATH)
shot123 = load_json(SHOT123_PATH)
sft = load_json(SFT_TEST_PATH)


# ============================================================
# BUILD METRICS SUMMARY CSV
# ============================================================

rows = []

def append_rows(method_name, metrics):
    for scope_name, scope_key in [
        ("overall", "overall"),
        ("linalg", ("by_dialect", "linalg")),
        ("torch", ("by_dialect", "torch")),
    ]:
        if scope_name == "overall":
            m = metrics["overall"]
        else:
            m = metrics["by_dialect"][scope_name]

        row = {
            "method": method_name,
            "scope": scope_name,
            "n": m["n"],
            "accuracy": m["accuracy"],
            "macro_f1": m["macro_f1"],
            "weighted_f1": m["weighted_f1"],
            "false_equiv_rate": m["false_equiv_rate"],
            "unsafe_recall": m["unsafe_recall"],
            "invalid_count": m["invalid_count"],
            "f1_equiv": m["per_class_f1"]["EQUIV"],
            "f1_diverge": m["per_class_f1"]["DIVERGE"],
            "f1_error": m["per_class_f1"]["ERROR"],
        }
        rows.append(row)


append_rows("Zero-shot", zero)
append_rows("6-shot seed 42", shot42)
append_rows("6-shot seed 123", shot123)

# 6-shot mean
shot_mean = {
    "overall": {
        "n": shot42["overall"]["n"],
        "accuracy": mean_metric(shot42, shot123, "overall", "accuracy"),
        "macro_f1": mean_metric(shot42, shot123, "overall", "macro_f1"),
        "weighted_f1": mean_metric(shot42, shot123, "overall", "weighted_f1"),
        "false_equiv_rate": mean_metric(shot42, shot123, "overall", "false_equiv_rate"),
        "unsafe_recall": mean_metric(shot42, shot123, "overall", "unsafe_recall"),
        "invalid_count": (shot42["overall"]["invalid_count"] + shot123["overall"]["invalid_count"]) / 2.0,
        "per_class_f1": {
            "EQUIV": (shot42["overall"]["per_class_f1"]["EQUIV"] + shot123["overall"]["per_class_f1"]["EQUIV"]) / 2.0,
            "DIVERGE": (shot42["overall"]["per_class_f1"]["DIVERGE"] + shot123["overall"]["per_class_f1"]["DIVERGE"]) / 2.0,
            "ERROR": (shot42["overall"]["per_class_f1"]["ERROR"] + shot123["overall"]["per_class_f1"]["ERROR"]) / 2.0,
        },
    },
    "by_dialect": {
        "linalg": {
            "n": shot42["by_dialect"]["linalg"]["n"],
            "accuracy": mean_nested_metric(shot42, shot123, "by_dialect", "linalg", "accuracy"),
            "macro_f1": mean_nested_metric(shot42, shot123, "by_dialect", "linalg", "macro_f1"),
            "weighted_f1": mean_nested_metric(shot42, shot123, "by_dialect", "linalg", "weighted_f1"),
            "false_equiv_rate": mean_nested_metric(shot42, shot123, "by_dialect", "linalg", "false_equiv_rate"),
            "unsafe_recall": mean_nested_metric(shot42, shot123, "by_dialect", "linalg", "unsafe_recall"),
            "invalid_count": (shot42["by_dialect"]["linalg"]["invalid_count"] + shot123["by_dialect"]["linalg"]["invalid_count"]) / 2.0,
            "per_class_f1": {
                "EQUIV": (shot42["by_dialect"]["linalg"]["per_class_f1"]["EQUIV"] + shot123["by_dialect"]["linalg"]["per_class_f1"]["EQUIV"]) / 2.0,
                "DIVERGE": (shot42["by_dialect"]["linalg"]["per_class_f1"]["DIVERGE"] + shot123["by_dialect"]["linalg"]["per_class_f1"]["DIVERGE"]) / 2.0,
                "ERROR": (shot42["by_dialect"]["linalg"]["per_class_f1"]["ERROR"] + shot123["by_dialect"]["linalg"]["per_class_f1"]["ERROR"]) / 2.0,
            },
        },
        "torch": {
            "n": shot42["by_dialect"]["torch"]["n"],
            "accuracy": mean_nested_metric(shot42, shot123, "by_dialect", "torch", "accuracy"),
            "macro_f1": mean_nested_metric(shot42, shot123, "by_dialect", "torch", "macro_f1"),
            "weighted_f1": mean_nested_metric(shot42, shot123, "by_dialect", "torch", "weighted_f1"),
            "false_equiv_rate": mean_nested_metric(shot42, shot123, "by_dialect", "torch", "false_equiv_rate"),
            "unsafe_recall": mean_nested_metric(shot42, shot123, "by_dialect", "torch", "unsafe_recall"),
            "invalid_count": (shot42["by_dialect"]["torch"]["invalid_count"] + shot123["by_dialect"]["torch"]["invalid_count"]) / 2.0,
            "per_class_f1": {
                "EQUIV": (shot42["by_dialect"]["torch"]["per_class_f1"]["EQUIV"] + shot123["by_dialect"]["torch"]["per_class_f1"]["EQUIV"]) / 2.0,
                "DIVERGE": (shot42["by_dialect"]["torch"]["per_class_f1"]["DIVERGE"] + shot123["by_dialect"]["torch"]["per_class_f1"]["DIVERGE"]) / 2.0,
                "ERROR": (shot42["by_dialect"]["torch"]["per_class_f1"]["ERROR"] + shot123["by_dialect"]["torch"]["per_class_f1"]["ERROR"]) / 2.0,
            },
        },
    },
}

append_rows("6-shot mean", shot_mean)
append_rows("MLIRBench SFT", sft)

summary_df = pd.DataFrame(rows)
summary_csv = FIG_DIR / "dt2_metrics_summary.csv"
summary_df.to_csv(summary_csv, index=False)


# ============================================================
# CHART 1: OVERALL PERFORMANCE
#   Accuracy and Macro-F1
#   Overall vs Linalg vs Torch
# ============================================================

methods = ["Zero-shot", "6-shot mean", "MLIRBench SFT"]

categories = [
    "Accuracy\nOverall",
    "Accuracy\nLinalg",
    "Accuracy\nTorch",
    "Macro-F1\nOverall",
    "Macro-F1\nLinalg",
    "Macro-F1\nTorch",
]

zero_vals = [
    pct(zero["overall"]["accuracy"]),
    pct(zero["by_dialect"]["linalg"]["accuracy"]),
    pct(zero["by_dialect"]["torch"]["accuracy"]),
    pct(zero["overall"]["macro_f1"]),
    pct(zero["by_dialect"]["linalg"]["macro_f1"]),
    pct(zero["by_dialect"]["torch"]["macro_f1"]),
]

mean_vals = [
    pct(shot_mean["overall"]["accuracy"]),
    pct(shot_mean["by_dialect"]["linalg"]["accuracy"]),
    pct(shot_mean["by_dialect"]["torch"]["accuracy"]),
    pct(shot_mean["overall"]["macro_f1"]),
    pct(shot_mean["by_dialect"]["linalg"]["macro_f1"]),
    pct(shot_mean["by_dialect"]["torch"]["macro_f1"]),
]

sft_vals = [
    pct(sft["overall"]["accuracy"]),
    pct(sft["by_dialect"]["linalg"]["accuracy"]),
    pct(sft["by_dialect"]["torch"]["accuracy"]),
    pct(sft["overall"]["macro_f1"]),
    pct(sft["by_dialect"]["linalg"]["macro_f1"]),
    pct(sft["by_dialect"]["torch"]["macro_f1"]),
]

x = np.arange(len(categories))
width = 0.24

fig, ax = plt.subplots(figsize=(12, 6.5))

b1 = ax.bar(x - width, zero_vals, width, label="Zero-shot")
b2 = ax.bar(x, mean_vals, width, label="6-shot ICL (mean of 2 seeds)")
b3 = ax.bar(x + width, sft_vals, width, label="MLIRBench SFT")

add_value_labels(ax, b1, decimals=1)
add_value_labels(ax, b2, decimals=1)
add_value_labels(ax, b3, decimals=1)

ax.set_xticks(x)
ax.set_xticklabels(categories)
ax.set_ylabel("Score (%)")
ax.set_ylim(0, 100)
ax.set_title(
    "DT2 All-Dataset Test Performance\n"
    "Family-Disjoint Held-Out Evaluation Across Overall, Linalg, and Torch"
)
ax.legend()
ax.grid(axis="y", alpha=0.25)

fig.tight_layout()

overall_png = FIG_DIR / "dt2_overall_performance.png"
overall_pdf = FIG_DIR / "dt2_overall_performance.pdf"
fig.savefig(overall_png, dpi=300, bbox_inches="tight")
fig.savefig(overall_pdf, bbox_inches="tight")
plt.close(fig)


# ============================================================
# CHART 2: FALSE-EQUIV RATE
#   Overall vs Linalg vs Torch
# ============================================================

categories = [
    "Overall",
    "Linalg",
    "Torch",
]

zero_fe = [
    pct(zero["overall"]["false_equiv_rate"]),
    pct(zero["by_dialect"]["linalg"]["false_equiv_rate"]),
    pct(zero["by_dialect"]["torch"]["false_equiv_rate"]),
]

mean_fe = [
    pct(shot_mean["overall"]["false_equiv_rate"]),
    pct(shot_mean["by_dialect"]["linalg"]["false_equiv_rate"]),
    pct(shot_mean["by_dialect"]["torch"]["false_equiv_rate"]),
]

sft_fe = [
    pct(sft["overall"]["false_equiv_rate"]),
    pct(sft["by_dialect"]["linalg"]["false_equiv_rate"]),
    pct(sft["by_dialect"]["torch"]["false_equiv_rate"]),
]

x = np.arange(len(categories))
width = 0.24

fig, ax = plt.subplots(figsize=(9.5, 5.8))

b1 = ax.bar(x - width, zero_fe, width, label="Zero-shot")
b2 = ax.bar(x, mean_fe, width, label="6-shot ICL (mean of 2 seeds)")
b3 = ax.bar(x + width, sft_fe, width, label="MLIRBench SFT")

add_value_labels(ax, b1, decimals=1)
add_value_labels(ax, b2, decimals=1)
add_value_labels(ax, b3, decimals=1)

ax.set_xticks(x)
ax.set_xticklabels(categories)
ax.set_ylabel("False-EQUIV Rate (%)")
ax.set_ylim(0, 100)
ax.set_title(
    "DT2 False-EQUIV Rate on the All-Dataset Test Set\n"
    "Overall vs Linalg vs Torch"
)
ax.legend()
ax.grid(axis="y", alpha=0.25)

fig.tight_layout()

fe_png = FIG_DIR / "dt2_false_equiv_rate.png"
fe_pdf = FIG_DIR / "dt2_false_equiv_rate.pdf"
fig.savefig(fe_png, dpi=300, bbox_inches="tight")
fig.savefig(fe_pdf, bbox_inches="tight")
plt.close(fig)


# ============================================================
# TRAINING CURVE PARSING
# ============================================================

ansi_re = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
text = SFT_LOG_PATH.read_text(errors="ignore")
text = ansi_re.sub("", text)

train_pattern = re.compile(
    r"\{'loss': '([^']+)', 'grad_norm': '([^']+)', "
    r"'learning_rate': '([^']+)', 'epoch': '([^']+)'\}"
)

eval_pattern = re.compile(
    r"\{'eval_loss': '([^']+)', 'eval_runtime': '([^']+)', "
    r"'eval_samples_per_second': '([^']+)', 'eval_steps_per_second': '([^']+)', "
    r"'epoch': '([^']+)'\}"
)

train_records = []
for match in train_pattern.findall(text):
    loss, grad_norm, learning_rate, epoch = match
    train_records.append({
        "split": "train",
        "epoch": float(epoch),
        "loss": float(loss),
        "grad_norm": float(grad_norm),
        "learning_rate": float(learning_rate),
    })

eval_records = []
for match in eval_pattern.findall(text):
    eval_loss, eval_runtime, eval_sps, eval_steps_ps, epoch = match
    eval_records.append({
        "split": "eval",
        "epoch": float(epoch),
        "loss": float(eval_loss),
        "eval_runtime": float(eval_runtime),
        "eval_samples_per_second": float(eval_sps),
        "eval_steps_per_second": float(eval_steps_ps),
    })

train_df = pd.DataFrame(train_records).sort_values("epoch")
eval_df = pd.DataFrame(eval_records).sort_values("epoch")

curve_df = pd.concat([train_df, eval_df], ignore_index=True, sort=False)
curve_csv = FIG_DIR / "dt2_training_curve_data.csv"
curve_df.to_csv(curve_csv, index=False)


# ============================================================
# CHART 3: TRAINING LOSS
# ============================================================

fig, ax = plt.subplots(figsize=(10, 6))

if not train_df.empty:
    ax.plot(
        train_df["epoch"],
        train_df["loss"],
        label="Training loss",
        linewidth=1.5,
    )

if not eval_df.empty:
    ax.plot(
        eval_df["epoch"],
        eval_df["loss"],
        marker="o",
        label="Validation loss",
        linewidth=1.8,
    )

    best_idx = eval_df["loss"].idxmin()
    best_epoch = eval_df.loc[best_idx, "epoch"]
    best_loss = eval_df.loc[best_idx, "loss"]

    ax.annotate(
        f"Best val loss = {best_loss:.4f}\nEpoch {best_epoch:.0f}",
        xy=(best_epoch, best_loss),
        xytext=(best_epoch + 0.2, best_loss + 0.03),
        arrowprops=dict(arrowstyle="->"),
        fontsize=9,
    )

ax.set_xlabel("Epoch")
ax.set_ylabel("Loss")
ax.set_title(
    "DT2 All-Dataset SFT Training Curve\n"
    "Training and Validation Loss Across Epochs"
)
ax.legend()
ax.grid(alpha=0.25)

fig.tight_layout()

loss_png = FIG_DIR / "dt2_training_loss.png"
loss_pdf = FIG_DIR / "dt2_training_loss.pdf"
fig.savefig(loss_png, dpi=300, bbox_inches="tight")
fig.savefig(loss_pdf, bbox_inches="tight")
plt.close(fig)


# ============================================================
# DONE
# ============================================================

print("\nGenerated files:")
for p in [
    summary_csv,
    overall_png, overall_pdf,
    fe_png, fe_pdf,
    curve_csv,
    loss_png, loss_pdf,
]:
    print(p)