#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score

ROOT = Path(__file__).resolve().parents[2] if 'FINAL_FIGURES' in str(Path(__file__).resolve()) else Path.cwd()
OUT1 = ROOT / 'FINAL_FIGURES' / 'DT1'
OUT2 = ROOT / 'FINAL_FIGURES' / 'DT2'
OUT1.mkdir(parents=True, exist_ok=True)
OUT2.mkdir(parents=True, exist_ok=True)

# ------------------------------- helpers ----------------------------------
def save(fig, outdir, stem):
    fig.savefig(outdir / f'{stem}.png', dpi=400, bbox_inches='tight')
    fig.savefig(outdir / f'{stem}.pdf', bbox_inches='tight')
    plt.close(fig)

def norm_dt1(x):
    x = str(x).strip().upper()
    return {'A':'LOW','B':'MEDIUM','C':'HIGH'}.get(x,x)

def norm_dt2(x):
    x = str(x).strip().upper()
    return {'EQUIVALENT':'EQUIV','DIVERGENT':'DIVERGE'}.get(x,x)

def detect_cols(df, gold_candidates, pred_candidates):
    gold = next((c for c in gold_candidates if c in df.columns), None)
    pred = next((c for c in pred_candidates if c in df.columns), None)
    if gold is None:
        gold = next((c for c in df.columns if any(k in c.lower() for k in ['gold','target','true'])), None)
    if pred is None:
        pred = next((c for c in df.columns if 'pred' in c.lower()), None)
    if gold is None or pred is None:
        raise RuntimeError(f'Cannot detect gold/prediction columns in {list(df.columns)}')
    return gold, pred

def load_dt1_file(p):
    df = pd.read_csv(p)
    g,pred = detect_cols(df,
        ['fusion_benefit','simplification_benefit','gold','gold_label','target','label','true_label'],
        ['prediction','predicted_label','pred_label','predicted','prediction_label'])
    df = df.copy(); df['_gold']=df[g].map(norm_dt1); df['_pred']=df[pred].map(norm_dt1)
    return df[df['_gold'].isin(['LOW','MEDIUM','HIGH']) & df['_pred'].isin(['LOW','MEDIUM','HIGH'])].copy()

def pooled_dt1(root, method):
    base = root/'outputs'/'final_cv'/method
    parts=[]
    for fold in range(5):
        opts=[base/f'fold_{fold}_val_predictions.csv', base/f'fold_{fold}'/'val_predictions.csv']
        p=next((x for x in opts if x.exists()),None)
        if p is None: raise FileNotFoundError(f'Missing fold {fold}: {base}')
        d=load_dt1_file(p); d['fold']=fold; parts.append(d)
    return pd.concat(parts,ignore_index=True)

def dt1_metrics(df):
    C=['LOW','MEDIUM','HIGH']; y=df['_gold']; p=df['_pred']
    pc=f1_score(y,p,labels=C,average=None,zero_division=0)
    return dict(n=len(df), accuracy=accuracy_score(y,p), balanced_accuracy=balanced_accuracy_score(y,p),
                macro_f1=f1_score(y,p,labels=C,average='macro',zero_division=0),
                f1_low=pc[0],f1_medium=pc[1],f1_high=pc[2])

def mean_metrics(ms, keys): return {k:float(np.mean([m[k] for m in ms])) for k in keys}

# =============================== DT1 =======================================
LIN=ROOT/'DT1_ELEMENTWISE'; TOR=ROOT/'DT1_TORCH_OPT'
lin_zero=dt1_metrics(pooled_dt1(LIN,'zero'))
lin_shots=[dt1_metrics(pooled_dt1(LIN,'three_shot_seed_42')),dt1_metrics(pooled_dt1(LIN,'three_shot_seed_123'))]
lin_few=mean_metrics(lin_shots,['accuracy','balanced_accuracy','macro_f1','f1_low','f1_medium','f1_high'])
lin_sft_df=pooled_dt1(LIN,'sft'); lin_sft=dt1_metrics(lin_sft_df)

tor_zero=dt1_metrics(pooled_dt1(TOR,'zero'))
tor_shots=[dt1_metrics(pooled_dt1(TOR,'three_shot_seed_42')),dt1_metrics(pooled_dt1(TOR,'three_shot_seed_123')),dt1_metrics(pooled_dt1(TOR,'three_shot_seed_2026'))]
tor_few=mean_metrics(tor_shots,['accuracy','balanced_accuracy','macro_f1','f1_low','f1_medium','f1_high'])
tor_sft_df=pooled_dt1(TOR,'sft'); tor_sft=dt1_metrics(tor_sft_df)

pd.DataFrame([
    {'task':'Linalg fusion','method':'Zero-shot',**lin_zero},{'task':'Linalg fusion','method':'Few-shot mean',**lin_few},{'task':'Linalg fusion','method':'SFT',**lin_sft},
    {'task':'Torch simplification','method':'Zero-shot',**tor_zero},{'task':'Torch simplification','method':'Few-shot mean',**tor_few},{'task':'Torch simplification','method':'Balanced SFT',**tor_sft},
]).to_csv(OUT1/'dt1_metrics_summary.csv',index=False)

# DT1 Figure 1
methods=['Zero-shot','Few-shot','SFT']; x=np.arange(3); w=.36
lv=[lin_zero['macro_f1']*100,lin_few['macro_f1']*100,lin_sft['macro_f1']*100]
tv=[tor_zero['macro_f1']*100,tor_few['macro_f1']*100,tor_sft['macro_f1']*100]
fig,ax=plt.subplots(figsize=(8.4,5.2)); b1=ax.bar(x-w/2,lv,w,label='Linalg fusion'); b2=ax.bar(x+w/2,tv,w,label='Torch simplification')
ax.set_title('Benchmark Supervision Enables Optimization-Benefit Prediction'); ax.set_ylabel('Macro-F1 (%)'); ax.set_xticks(x); ax.set_xticklabels(methods); ax.set_ylim(0,100); ax.grid(axis='y',alpha=.25); ax.legend(frameon=False)
for bs in [b1,b2]:
    for b in bs: ax.text(b.get_x()+b.get_width()/2,b.get_height()+1.2,f'{b.get_height():.1f}',ha='center',fontsize=9)
fig.tight_layout(); save(fig,OUT1,'dt1_01_supervision_gain')

# DT1 Figure 2
C=['LOW','MEDIUM','HIGH']; lpc=[lin_sft['f1_low'],lin_sft['f1_medium'],lin_sft['f1_high']]; tpc=[tor_sft['f1_low'],tor_sft['f1_medium'],tor_sft['f1_high']]
pd.DataFrame({'class':C,'linalg_f1':lpc,'torch_f1':tpc}).to_csv(OUT1/'dt1_per_class_f1.csv',index=False)
x=np.arange(3); fig,ax=plt.subplots(figsize=(8.4,5.2)); b1=ax.bar(x-w/2,np.array(lpc)*100,w,label='Linalg fusion SFT'); b2=ax.bar(x+w/2,np.array(tpc)*100,w,label='Torch simplification SFT')
ax.set_title('Final SFT Distinguishes Compiler-Benefit Classes'); ax.set_ylabel('Per-class F1 (%)'); ax.set_xlabel('Compiler-observed benefit class'); ax.set_xticks(x); ax.set_xticklabels(C); ax.set_ylim(0,100); ax.grid(axis='y',alpha=.25); ax.legend(frameon=False)
for bs in [b1,b2]:
    for b in bs: ax.text(b.get_x()+b.get_width()/2,b.get_height()+1.2,f'{b.get_height():.1f}',ha='center',fontsize=9)
fig.tight_layout(); save(fig,OUT1,'dt1_02_per_class_generalization')

# DT1 Figure 3
fs=pd.read_csv(LIN/'outputs'/'fusion_scan_results.csv'); fv=fs[fs['fusion_success']==True]; fchg=100*fv['fusion_changed_ir'].astype(bool).mean()
ts=pd.read_csv(TOR/'outputs'/'torch_opt_scan.csv'); tvv=ts[ts['simplification_pipeline_success']==True]; tchg=100*tvv['simplification_pipeline_changed_ir'].astype(bool).mean()
with open(LIN/'outputs'/'riscv_backend_extension'/'riscv_backend_summary.json') as f: rv=json.load(f)
imp=[]; tie=[]; wor=[]
for c in C:
    q=rv['by_fusion_benefit'][c]; n=q['n']; imp.append(100*q['improved']/n); tie.append(100*q['tied']/n); wor.append(100*q['worsened']/n)
fig,axs=plt.subplots(1,2,figsize=(11.4,4.8)); bars=axs[0].bar(['Linalg\nfusion','Torch\nsimplification'],[fchg,tchg]); axs[0].set_title('(a) Compiler transformation coverage'); axs[0].set_ylabel('Compiler-valid programs with changed IR (%)'); axs[0].set_ylim(0,100); axs[0].grid(axis='y',alpha=.25)
for b in bars: axs[0].text(b.get_x()+b.get_width()/2,b.get_height()+1.3,f'{b.get_height():.1f}%',ha='center',fontsize=9)
x=np.arange(3); axs[1].bar(x,imp,label='Improved'); axs[1].bar(x,tie,bottom=imp,label='Tied'); axs[1].bar(x,wor,bottom=np.array(imp)+np.array(tie),label='Worsened'); axs[1].set_title('(b) RISC-V backend outcome after fusion'); axs[1].set_ylabel('Programs within class (%)'); axs[1].set_xlabel('Fusion-benefit class'); axs[1].set_xticks(x); axs[1].set_xticklabels(C); axs[1].set_ylim(0,100); axs[1].grid(axis='y',alpha=.25); axs[1].legend(frameon=False,fontsize=9)
fig.suptitle('DT1 Labels Are Grounded in Real Compiler Transformations',y=1.02,fontsize=13); fig.tight_layout(); save(fig,OUT1,'dt1_03_compiler_grounding')

# =============================== DT2 =======================================
P=ROOT/'outputs'/'dt2_all-dataset'/'predictions'; C2=['EQUIV','DIVERGE','ERROR']
def load_dt2(p):
    df=pd.read_csv(p); g,pr=detect_cols(df,['gold','gold_label','label','target','true_label','semantic_label','expected_label'],['prediction','predicted_label','pred_label','predicted','prediction_label','model_prediction'])
    df=df.copy(); df['_gold']=df[g].map(norm_dt2); df['_pred']=df[pr].map(norm_dt2); df=df[df['_gold'].isin(C2)&df['_pred'].isin(C2)].copy()
    d=next((c for c in ['dialect','mlir_dialect','source_dialect'] if c in df.columns),None)
    if d is None: d=next((c for c in df.columns if 'dialect' in c.lower()),None)
    if d is not None: df['_dialect']=df[d].astype(str).str.lower().str.strip()
    return df

def dt2_metrics(df):
    y=df['_gold']; p=df['_pred']; pc=f1_score(y,p,labels=C2,average=None,zero_division=0); unsafe=y.isin(['DIVERGE','ERROR']); den=int(unsafe.sum())
    fer=float((((p=='EQUIV')&unsafe).sum()/den) if den else np.nan)
    return dict(n=len(df),accuracy=accuracy_score(y,p),macro_f1=f1_score(y,p,labels=C2,average='macro',zero_division=0),f1_equiv=pc[0],f1_diverge=pc[1],f1_error=pc[2],false_equiv_rate=fer)

z=load_dt2(P/'all-dataset_zero_shot_predictions.csv'); s42=load_dt2(P/'all-dataset_6shot_seed_42_predictions.csv'); s123=load_dt2(P/'all-dataset_6shot_seed_123_predictions.csv'); ft=load_dt2(P/'all-dataset_sft_test_predictions.csv')
zm=dt2_metrics(z); sm1=dt2_metrics(s42); sm2=dt2_metrics(s123); fm=dt2_metrics(ft)
sm=mean_metrics([sm1,sm2],['accuracy','macro_f1','f1_equiv','f1_diverge','f1_error','false_equiv_rate']); sm['n']=int(round((sm1['n']+sm2['n'])/2))
pd.DataFrame([{'method':'Zero-shot',**zm},{'method':'6-shot mean',**sm},{'method':'SFT',**fm}]).to_csv(OUT2/'dt2_metrics_summary.csv',index=False)

# DT2 Figure 1
mnames=['Zero-shot','6-shot','SFT']; acc=[zm['accuracy']*100,sm['accuracy']*100,fm['accuracy']*100]; mf1=[zm['macro_f1']*100,sm['macro_f1']*100,fm['macro_f1']*100]
fig,axs=plt.subplots(1,2,figsize=(10.2,4.6),sharey=True)
for ax,vals,title in [(axs[0],acc,'(a) Accuracy'),(axs[1],mf1,'(b) Macro-F1')]:
    bs=ax.bar(mnames,vals); ax.set_title(title); ax.set_ylim(0,100); ax.grid(axis='y',alpha=.25)
    for b in bs: ax.text(b.get_x()+b.get_width()/2,b.get_height()+1.3,f'{b.get_height():.1f}',ha='center',fontsize=9)
axs[0].set_ylabel('Score (%)'); fig.suptitle('Execution-Grounded Supervision Improves Semantic Transformation Triage',y=1.02,fontsize=13); fig.tight_layout(); save(fig,OUT2,'dt2_01_supervision_gain')

# DT2 Figure 2
for name,df in [('zero',z),('6shot42',s42),('6shot123',s123),('sft',ft)]:
    if '_dialect' not in df.columns: raise RuntimeError(f'{name} predictions lack dialect column: {list(df.columns)}')
def dmf(df,d):
    q=df[df['_dialect']==d]; return f1_score(q['_gold'],q['_pred'],labels=C2,average='macro',zero_division=0) if len(q) else np.nan
rows=[]
for d in ['linalg','torch']:
    rows.extend([{'dialect':d,'method':'Zero-shot','macro_f1':dmf(z,d)},{'dialect':d,'method':'6-shot mean','macro_f1':float(np.nanmean([dmf(s42,d),dmf(s123,d)]))},{'dialect':d,'method':'SFT','macro_f1':dmf(ft,d)}])
ddf=pd.DataFrame(rows); ddf.to_csv(OUT2/'dt2_dialect_metrics.csv',index=False)
x=np.arange(3); l=[ddf[(ddf.dialect=='linalg')&(ddf.method==m)].macro_f1.iloc[0]*100 for m in ['Zero-shot','6-shot mean','SFT']]; t=[ddf[(ddf.dialect=='torch')&(ddf.method==m)].macro_f1.iloc[0]*100 for m in ['Zero-shot','6-shot mean','SFT']]
fig,ax=plt.subplots(figsize=(8.4,5.2)); b1=ax.bar(x-w/2,l,w,label='Linalg'); b2=ax.bar(x+w/2,t,w,label='Torch'); ax.set_title('DT2 Generalizes Across Both MLIRBench Dialects'); ax.set_ylabel('Macro-F1 (%)'); ax.set_xticks(x); ax.set_xticklabels(['Zero-shot','6-shot','SFT']); ax.set_ylim(0,100); ax.grid(axis='y',alpha=.25); ax.legend(frameon=False)
for bs in [b1,b2]:
    for b in bs: ax.text(b.get_x()+b.get_width()/2,b.get_height()+1.2,f'{b.get_height():.1f}',ha='center',fontsize=9)
fig.tight_layout(); save(fig,OUT2,'dt2_02_dialect_generalization')

# DT2 Figure 3
class_rows=[]
for name,m in [('Zero-shot',zm),('6-shot mean',sm),('SFT',fm)]:
    for c,k in [('EQUIV','f1_equiv'),('DIVERGE','f1_diverge'),('ERROR','f1_error')]: class_rows.append({'method':name,'class':c,'f1':m[k]})
cdf=pd.DataFrame(class_rows); cdf.to_csv(OUT2/'dt2_class_metrics.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(11.4,4.8)); x=np.arange(3); ww=.25
for i,name in enumerate(['Zero-shot','6-shot mean','SFT']):
    vals=[cdf[(cdf.method==name)&(cdf['class']==c)].f1.iloc[0]*100 for c in C2]; axs[0].bar(x+(i-1)*ww,vals,ww,label=name)
axs[0].set_title('(a) Per-class semantic recognition'); axs[0].set_ylabel('F1 (%)'); axs[0].set_xticks(x); axs[0].set_xticklabels(C2); axs[0].set_ylim(0,100); axs[0].grid(axis='y',alpha=.25); axs[0].legend(frameon=False,fontsize=8)
fvals=[zm['false_equiv_rate']*100,sm['false_equiv_rate']*100,fm['false_equiv_rate']*100]; bs=axs[1].bar(['Zero-shot','6-shot','SFT'],fvals); axs[1].set_title('(b) Unsafe pairs mislabeled EQUIV'); axs[1].set_ylabel('False-EQUIV rate (%) ↓'); axs[1].set_ylim(0,max(60,max(fvals)+10)); axs[1].grid(axis='y',alpha=.25)
for b in bs: axs[1].text(b.get_x()+b.get_width()/2,b.get_height()+1.2,f'{b.get_height():.1f}%',ha='center',fontsize=9)
fig.suptitle('DT2 Improves Semantic Safety, Not Just Aggregate Accuracy',y=1.02,fontsize=13); fig.tight_layout(); save(fig,OUT2,'dt2_03_semantic_safety')

print('\nGenerated FINAL_FIGURES:')
for d in [OUT1,OUT2]:
    print('\n',d)
    for p in sorted(d.iterdir()): print(' ',p.name)
 