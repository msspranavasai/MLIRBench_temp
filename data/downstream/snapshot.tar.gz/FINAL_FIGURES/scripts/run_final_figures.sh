#!/usr/bin/env bash
set -euo pipefail
ROOT="/lustre/hdd/LAS/jannesar-lab/pranava7/cgo2027-r1/revised-r1/MLIRBench"
cd "$ROOT"
source .venv/bin/activate
mkdir -p FINAL_FIGURES/scripts FINAL_FIGURES/DT1 FINAL_FIGURES/DT2
python -u FINAL_FIGURES/scripts/generate_final_figures.py
