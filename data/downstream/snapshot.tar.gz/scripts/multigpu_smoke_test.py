import os
import socket
import time

import torch
import torch.distributed as dist


def setup_distributed():
    """
    torchrun creates one Python process per GPU and provides
    these environment variables automatically.
    """
    rank = int(os.environ["RANK"])
    local_rank = int(os.environ["LOCAL_RANK"])
    world_size = int(os.environ["WORLD_SIZE"])

    # Bind this Python process to exactly one GPU.
    torch.cuda.set_device(local_rank)

    # NCCL is NVIDIA's high-performance GPU communication backend.
    dist.init_process_group(backend="nccl")

    return rank, local_rank, world_size


def main():
    rank, local_rank, world_size = setup_distributed()

    device = torch.device(f"cuda:{local_rank}")
    gpu_name = torch.cuda.get_device_name(local_rank)
    hostname = socket.gethostname()

    print(
        f"[Rank {rank}] "
        f"Host={hostname} "
        f"GPU={local_rank} "
        f"Device={gpu_name}",
        flush=True,
    )

    # Give every process different random numbers.
    torch.manual_seed(1234 + rank)

    # Create matrices directly on this process's GPU.
    size = 8192

    a = torch.randn(
        size,
        size,
        device=device,
        dtype=torch.float16,
    )

    b = torch.randn(
        size,
        size,
        device=device,
        dtype=torch.float16,
    )

    # Make sure allocation has actually completed.
    torch.cuda.synchronize()

    print(
        f"[Rank {rank}] Starting matrix multiplication on GPU {local_rank}",
        flush=True,
    )

    start = time.time()

    # Do enough work that nvidia-smi can visibly catch the GPUs working.
    for _ in range(20):
        c = torch.matmul(a, b)

    torch.cuda.synchronize()

    elapsed = time.time() - start

    allocated_gb = torch.cuda.memory_allocated(device) / (1024**3)
    reserved_gb = torch.cuda.memory_reserved(device) / (1024**3)

    print(
        f"[Rank {rank}] Finished in {elapsed:.2f}s | "
        f"allocated={allocated_gb:.2f} GB | "
        f"reserved={reserved_gb:.2f} GB",
        flush=True,
    )

    # ---------------------------------------------------------
    # Test communication between all three GPUs.
    # ---------------------------------------------------------

    value = torch.tensor(
        [rank + 1.0],
        device=device,
    )

    print(
        f"[Rank {rank}] Before all_reduce: {value.item()}",
        flush=True,
    )

    dist.all_reduce(
        value,
        op=dist.ReduceOp.SUM,
    )

    print(
        f"[Rank {rank}] After all_reduce: {value.item()}",
        flush=True,
    )

    # Wait until every process reaches this point.
    dist.barrier()

    if rank == 0:
        print()
        print("=" * 60)
        print("SUCCESS: all GPUs computed and communicated correctly.")
        print(f"World size: {world_size}")
        print("=" * 60)

    dist.destroy_process_group()


if __name__ == "__main__":
    main()