# Put at: /lustre/hdd/LAS/jannesar-lab/pranava7/cgo2027-r1/revised-r1/MLIRBench/scripts/r2_workers_all_dataset/evaluate_sft.py
import json
from pathlib import Path

import pandas as pd
import torch
from peft import PeftModel
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

from common import extract_label, full_metrics, zero_shot_prompt

MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"
DATA_PATH = Path("/home/pranava7/mlirbench/dt-2-all-dataset/data/test.json")
RUN_DIR = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/outputs/dt2_all-dataset"
)
ADAPTER_DIR = RUN_DIR / "adapter"
OUTPUT_DIR = RUN_DIR / "predictions"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 16
BATCH_SIZE = 4

with DATA_PATH.open("r", encoding="utf-8") as f:
    df = pd.DataFrame(json.load(f))

tokenizer = AutoTokenizer.from_pretrained(
    ADAPTER_DIR,
    trust_remote_code=True,
)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"

prompt_lengths = []
for _, row in df.iterrows():
    prompt = zero_shot_prompt(tokenizer, row)
    n = len(tokenizer(prompt, add_special_tokens=False)["input_ids"])
    prompt_lengths.append(n)

print("SFT-eval prompt lengths:")
print("Min:", min(prompt_lengths))
print("Mean:", sum(prompt_lengths) / len(prompt_lengths))
print("Max:", max(prompt_lengths))

if max(prompt_lengths) > MAX_SEQ_LEN:
    raise RuntimeError(
        f"SFT evaluation prompt exceeds context limit: {max(prompt_lengths)} > {MAX_SEQ_LEN}"
    )

base_model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)
model = PeftModel.from_pretrained(base_model, ADAPTER_DIR)
model.eval()

predictions = []
raw_outputs = []

for start in tqdm(range(0, len(df), BATCH_SIZE), desc="All-dataset SFT evaluation"):
    batch = df.iloc[start : start + BATCH_SIZE]
    prompts = [zero_shot_prompt(tokenizer, row) for _, row in batch.iterrows()]

    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to("cuda")

    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    input_len = inputs["input_ids"].shape[1]
    for output in outputs:
        raw = tokenizer.decode(output[input_len:], skip_special_tokens=True).strip()
        raw_outputs.append(raw)
        predictions.append(extract_label(raw))

result = df.copy()
result["prediction"] = predictions
result["raw_output"] = raw_outputs
result["correct"] = result["prediction"] == result["label"]

pred_path = OUTPUT_DIR / "all-dataset_sft_predictions.csv"
metrics_path = OUTPUT_DIR / "all-dataset_sft_metrics.json"

result.to_csv(pred_path, index=False)
metrics = full_metrics(result)
metrics["prompt_lengths"] = {
    "min": int(min(prompt_lengths)),
    "mean": float(sum(prompt_lengths) / len(prompt_lengths)),
    "max": int(max(prompt_lengths)),
}

with metrics_path.open("w", encoding="utf-8") as f:
    json.dump(metrics, f, indent=2)

print(json.dumps(metrics, indent=2))
print("Saved predictions:", pred_path)
print("Saved metrics:", metrics_path)
