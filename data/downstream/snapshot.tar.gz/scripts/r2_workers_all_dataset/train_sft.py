# Put at: /lustre/hdd/LAS/jannesar-lab/pranava7/cgo2027-r1/revised-r1/MLIRBench/scripts/r2_workers_all_dataset/train_sft.py
import inspect
import json
import os
from pathlib import Path

import pandas as pd
import torch
from peft import LoraConfig, get_peft_model
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)

from common import task_text

MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"
DATA_DIR = Path("/home/pranava7/mlirbench/dt-2-all-dataset/data/outputs")
RUN_DIR = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/outputs/dt2_all-dataset"
)
ADAPTER_DIR = RUN_DIR / "adapter"
CHECKPOINT_DIR = RUN_DIR / "checkpoints"
LOG_DIR = RUN_DIR / "logs"

ADAPTER_DIR.mkdir(parents=True, exist_ok=True)
CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

TRAIN_MAX_SEQ_LEN = 32768
SEED = 42
NUM_EPOCHS = 6
LEARNING_RATE = 1e-4
PER_DEVICE_TRAIN_BATCH = 1
PER_DEVICE_EVAL_BATCH = 1
GRAD_ACCUM_STEPS = int(os.environ.get("DT2_GRAD_ACCUM_STEPS", "1"))

with (DATA_DIR / "train.json").open("r", encoding="utf-8") as f:
    train_df = pd.DataFrame(json.load(f))
with (DATA_DIR / "val.json").open("r", encoding="utf-8") as f:
    val_df = pd.DataFrame(json.load(f))

print("=" * 72)
print("DT2 ALL-DATASET SFT")
print("=" * 72)
print("Train:", len(train_df))
print(pd.crosstab(train_df["dialect"], train_df["label"]))
print("\nValidation:", len(val_df))
print(pd.crosstab(val_df["dialect"], val_df["label"]))

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "right"


def prompt_messages(row):
    return [{"role": "user", "content": task_text(row)}]


def full_messages(row):
    return prompt_messages(row) + [
        {"role": "assistant", "content": str(row["label"])}
    ]


def sequence_length(row):
    text = tokenizer.apply_chat_template(
        full_messages(row),
        tokenize=False,
        add_generation_prompt=False,
    )
    return len(tokenizer(text, add_special_tokens=False)["input_ids"])


all_lengths = [sequence_length(row) for _, row in pd.concat([train_df, val_df]).iterrows()]
print("\nSFT sequence lengths:")
print("Min:", min(all_lengths))
print("Mean:", sum(all_lengths) / len(all_lengths))
print("Max:", max(all_lengths))

if max(all_lengths) > TRAIN_MAX_SEQ_LEN:
    raise RuntimeError(
        f"An SFT example exceeds context limit: {max(all_lengths)} > {TRAIN_MAX_SEQ_LEN}. "
        "Do not silently truncate MLIR pairs."
    )


class DT2Dataset(Dataset):
    def __init__(self, dataframe: pd.DataFrame):
        self.examples = []

        for _, row in dataframe.iterrows():
            p_messages = prompt_messages(row)
            f_messages = full_messages(row)

            prompt_text = tokenizer.apply_chat_template(
                p_messages,
                tokenize=False,
                add_generation_prompt=True,
            )
            full_text = tokenizer.apply_chat_template(
                f_messages,
                tokenize=False,
                add_generation_prompt=False,
            )

            prompt_ids = tokenizer(
                prompt_text,
                add_special_tokens=False,
            )["input_ids"]

            encoded = tokenizer(
                full_text,
                add_special_tokens=False,
                truncation=False,
            )

            input_ids = encoded["input_ids"]
            attention_mask = encoded["attention_mask"]
            labels = input_ids.copy()
            prompt_len = min(len(prompt_ids), len(labels))
            labels[:prompt_len] = [-100] * prompt_len

            self.examples.append(
                {
                    "input_ids": input_ids,
                    "attention_mask": attention_mask,
                    "labels": labels,
                }
            )

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.examples[idx]


class CausalLMDataCollator:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, features):
        max_len = max(len(x["input_ids"]) for x in features)
        input_ids = []
        attention_mask = []
        labels = []

        for feature in features:
            pad_len = max_len - len(feature["input_ids"])
            input_ids.append(
                feature["input_ids"]
                + [self.tokenizer.pad_token_id] * pad_len
            )
            attention_mask.append(feature["attention_mask"] + [0] * pad_len)
            labels.append(feature["labels"] + [-100] * pad_len)

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


train_dataset = DT2Dataset(train_df)
val_dataset = DT2Dataset(val_df)
collator = CausalLMDataCollator(tokenizer)

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    low_cpu_mem_usage=True,
    trust_remote_code=True,
)
model.config.use_cache = False
model.gradient_checkpointing_enable()

lora_config = LoraConfig(
    r=64,
    lora_alpha=128,
    lora_dropout=0.0,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=[
        "q_proj",
        "k_proj",
        "v_proj",
        "o_proj",
        "gate_proj",
        "up_proj",
        "down_proj",
    ],
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()

# Build TrainingArguments compatibly with the locally installed transformers.
params = inspect.signature(TrainingArguments.__init__).parameters
kwargs = {
    "output_dir": str(CHECKPOINT_DIR),
    "num_train_epochs": NUM_EPOCHS,
    "per_device_train_batch_size": PER_DEVICE_TRAIN_BATCH,
    "per_device_eval_batch_size": PER_DEVICE_EVAL_BATCH,
    "gradient_accumulation_steps": GRAD_ACCUM_STEPS,
    "learning_rate": LEARNING_RATE,
    "bf16": True,
    "logging_steps": 5,
    "save_strategy": "epoch",
    "save_total_limit": 2,
    "report_to": "none",
    "seed": SEED,
    "ddp_find_unused_parameters": False,
    "remove_unused_columns": False,
    "gradient_checkpointing": True,
}

if "eval_strategy" in params:
    kwargs["eval_strategy"] = "epoch"
    kwargs["load_best_model_at_end"] = True
    kwargs["metric_for_best_model"] = "eval_loss"
    kwargs["greater_is_better"] = False
elif "evaluation_strategy" in params:
    kwargs["evaluation_strategy"] = "epoch"
    kwargs["load_best_model_at_end"] = True
    kwargs["metric_for_best_model"] = "eval_loss"
    kwargs["greater_is_better"] = False

if "warmup_steps" in params:
    kwargs["warmup_steps"] = 20

training_args = TrainingArguments(**kwargs)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    data_collator=collator,
)

trainer.train()
trainer.save_model(str(ADAPTER_DIR))

if trainer.is_world_process_zero():
    tokenizer.save_pretrained(str(ADAPTER_DIR))
    metadata = {
        "model": MODEL_NAME,
        "train_examples": int(len(train_df)),
        "val_examples": int(len(val_df)),
        "train_max_seq_len": TRAIN_MAX_SEQ_LEN,
        "observed_max_seq_len": int(max(all_lengths)),
        "epochs": NUM_EPOCHS,
        "learning_rate": LEARNING_RATE,
        "gradient_accumulation_steps": GRAD_ACCUM_STEPS,
        "lora_r": 64,
        "lora_alpha": 128,
        "best_model_checkpoint": trainer.state.best_model_checkpoint,
        "best_eval_loss": trainer.state.best_metric,
    }
    with (RUN_DIR / "all-dataset_sft_training_metadata.json").open(
        "w", encoding="utf-8"
    ) as f:
        json.dump(metadata, f, indent=2)
    print("Saved adapter to:", ADAPTER_DIR)
