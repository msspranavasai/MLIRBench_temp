# Put at: /lustre/hdd/LAS/jannesar-lab/pranava7/cgo2027-r1/revised-r1/MLIRBench/scripts/r2_workers_all_dataset/run_six_shot.py
import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

from common import extract_label, few_shot_prompt, full_metrics

parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, default=42)
args = parser.parse_args()
SEED = args.seed

MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"
DATA_DIR = Path("/home/pranava7/mlirbench/dt-2-all-dataset/data/outputs")
OUTPUT_DIR = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/outputs/"
    "dt2_all-dataset/predictions"
)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 16
BATCH_SIZE = 2

with (DATA_DIR / "train.json").open("r", encoding="utf-8") as f:
    train_df = pd.DataFrame(json.load(f))
with (DATA_DIR / "test.json").open("r", encoding="utf-8") as f:
    test_df = pd.DataFrame(json.load(f))

examples = []
for dialect in ["linalg", "torch"]:
    for label in ["EQUIV", "DIVERGE", "ERROR"]:
        subset = train_df[
            (train_df["dialect"] == dialect) & (train_df["label"] == label)
        ].copy()
        if subset.empty:
            raise RuntimeError(f"No training example for {dialect}/{label}")

        # Prefer shorter demonstrations to protect context budget, then sample
        # deterministically among the 10 shortest so seeds still matter.
        subset["prompt_chars"] = (
            subset["original_mlir"].astype(str).str.len()
            + subset["mutated_mlir"].astype(str).str.len()
        )
        pool = subset.sort_values("prompt_chars").head(min(10, len(subset)))
        examples.append(pool.sample(n=1, random_state=SEED).iloc[0])

print("Balanced 6-shot examples:")
for ex in examples:
    print(
        ex["program_id"],
        "dialect=", ex["dialect"],
        "label=", ex["label"],
        "family=", ex.get("family_id", "n/a"),
    )

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"

prompt_lengths = []
for _, row in test_df.iterrows():
    prompt = few_shot_prompt(tokenizer, row, examples)
    n = len(tokenizer(prompt, add_special_tokens=False)["input_ids"])
    prompt_lengths.append(n)

print("\nAll-dataset 6-shot prompt lengths:")
print("Min:", min(prompt_lengths))
print("Mean:", sum(prompt_lengths) / len(prompt_lengths))
print("Max:", max(prompt_lengths))

if max(prompt_lengths) + MAX_NEW_TOKENS > MAX_SEQ_LEN:
    raise RuntimeError(
        f"6-shot prompt + generation exceeds context limit: {max(prompt_lengths)} + {MAX_NEW_TOKENS} > {MAX_SEQ_LEN}"
    )

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)
model.eval()

predictions = []
raw_outputs = []

for start in tqdm(
    range(0, len(test_df), BATCH_SIZE),
    desc=f"All-dataset 6-shot seed {SEED}",
):
    batch = test_df.iloc[start : start + BATCH_SIZE]
    prompts = [
        few_shot_prompt(tokenizer, row, examples)
        for _, row in batch.iterrows()
    ]

    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to("cuda")

    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    input_len = inputs["input_ids"].shape[1]
    for output in outputs:
        raw = tokenizer.decode(output[input_len:], skip_special_tokens=True).strip()
        raw_outputs.append(raw)
        predictions.append(extract_label(raw))

result = test_df.copy()
result["prediction"] = predictions
result["raw_output"] = raw_outputs
result["correct"] = result["prediction"] == result["label"]

pred_path = OUTPUT_DIR / f"all-dataset_6shot_seed_{SEED}_predictions.csv"
metrics_path = OUTPUT_DIR / f"all-dataset_6shot_seed_{SEED}_metrics.json"
examples_path = OUTPUT_DIR / f"all-dataset_6shot_seed_{SEED}_examples.json"

result.to_csv(pred_path, index=False)
metrics = full_metrics(result)
metrics["seed"] = int(SEED)
metrics["prompt_lengths"] = {
    "min": int(min(prompt_lengths)),
    "mean": float(sum(prompt_lengths) / len(prompt_lengths)),
    "max": int(max(prompt_lengths)),
}

with metrics_path.open("w", encoding="utf-8") as f:
    json.dump(metrics, f, indent=2)

example_records = [
    {
        "program_id": str(ex["program_id"]),
        "family_id": str(ex.get("family_id", "")),
        "dialect": str(ex["dialect"]),
        "label": str(ex["label"]),
    }
    for ex in examples
]
with examples_path.open("w", encoding="utf-8") as f:
    json.dump(example_records, f, indent=2)

print(json.dumps(metrics, indent=2))
print("Saved predictions:", pred_path)
print("Saved metrics:", metrics_path)
print("Saved demonstrations:", examples_path)
