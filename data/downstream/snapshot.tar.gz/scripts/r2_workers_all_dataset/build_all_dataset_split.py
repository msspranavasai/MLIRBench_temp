# Put at: /lustre/hdd/LAS/jannesar-lab/pranava7/cgo2027-r1/revised-r1/MLIRBench/scripts/r2_workers_all_dataset/build_all_dataset_split.py
import argparse
import json
import re
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

EXPECTED_TOTAL = 1768
EXPECTED_DIALECT_COUNTS = {"linalg": 888, "torch": 880}
VALID_LABELS = {"EQUIV", "DIVERGE", "ERROR"}
SEED = 42


def load_one(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()

    if suffix == ".csv":
        return pd.read_csv(path)

    if suffix == ".jsonl":
        rows = []
        with path.open("r", encoding="utf-8") as f:
            for lineno, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise RuntimeError(
                        f"Invalid JSONL at {path}:{lineno}: {exc}"
                    ) from exc
        return pd.DataFrame(rows)

    if suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            obj = json.load(f)

        if isinstance(obj, list):
            return pd.DataFrame(obj)

        if isinstance(obj, dict):
            for key in ("data", "records", "examples", "pairs", "results"):
                if key in obj and isinstance(obj[key], list):
                    return pd.DataFrame(obj[key])

        raise RuntimeError(
            f"Could not find a list of records in JSON file: {path}"
        )

    raise RuntimeError(
        f"Unsupported input format for {path}. Use .json, .jsonl, or .csv"
    )


def normalize_schema(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize common field-name variants into the DT2 schema."""
    aliases = {
        "program_id": ["program_id", "id", "pair_id", "mutation_id"],
        "dialect": ["dialect", "mlir_dialect"],
        "label": [
            "label",
            "relationship_label",
            "semantic_label",
            "ground_truth_label",
            "ground_truth",
        ],
        "original_mlir": ["original_mlir", "input_mlir", "source_mlir"],
        "mutated_mlir": ["mutated_mlir", "variant_mlir", "output_mlir"],
    }

    rename = {}
    columns = set(df.columns)

    for canonical, candidates in aliases.items():
        if canonical in columns:
            continue
        for candidate in candidates:
            if candidate in columns:
                rename[candidate] = canonical
                break

    df = df.rename(columns=rename).copy()

    required = {
        "program_id",
        "dialect",
        "label",
        "original_mlir",
        "mutated_mlir",
    }

    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(
            "Master dataset is missing required columns after alias normalization: "
            f"{sorted(missing)}\nAvailable columns: {sorted(df.columns)}"
        )

    df["dialect"] = df["dialect"].astype(str).str.lower().str.strip()
    df["label"] = df["label"].astype(str).str.upper().str.strip()
    df["program_id"] = df["program_id"].astype(str)

    unknown_labels = sorted(set(df["label"]) - VALID_LABELS)
    if unknown_labels:
        raise RuntimeError(f"Unexpected labels: {unknown_labels}")

    unknown_dialects = sorted(set(df["dialect"]) - set(EXPECTED_DIALECT_COUNTS))
    if unknown_dialects:
        raise RuntimeError(f"Unexpected dialects: {unknown_dialects}")

    return df


def family_id(program_id: str) -> str:
    """
    Collapse mutations and dialect variants from the same seed program.

    Example:
      seed2_linalg_prog14_L2_R3 -> seed2_prog14
      seed2_torch_prog14_L3_R4  -> seed2_prog14
    """
    text = str(program_id)

    seed_match = re.search(r"seed\s*([0-9]+)", text, flags=re.IGNORECASE)
    prog_match = re.search(r"prog(?:ram)?\s*([0-9]+)", text, flags=re.IGNORECASE)

    if seed_match and prog_match:
        return f"seed{seed_match.group(1)}_prog{prog_match.group(1)}"

    # Fallback for similar IDs that do not exactly match the known pattern.
    text = re.sub(r"_(linalg|torch)_", "_", text, flags=re.IGNORECASE)
    text = re.sub(r"_L\d+_R\d+.*$", "", text, flags=re.IGNORECASE)
    return text


def split_summary(name: str, split: pd.DataFrame) -> None:
    print("\n" + "=" * 72)
    print(f"{name}: {len(split)} examples | {split['family_id'].nunique()} families")
    print("=" * 72)
    print("\nDialect counts:")
    print(split["dialect"].value_counts().sort_index())
    print("\nDialect x label:")
    print(pd.crosstab(split["dialect"], split["label"]))


def save_json_records(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    records = df.to_dict(orient="records")
    with path.open("w", encoding="utf-8") as f:
        json.dump(records, f, indent=2)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a family-disjoint mixed-dialect DT2 split from all 1,768 MLIRBench pairs."
    )
    parser.add_argument(
        "--input",
        nargs="+",
        required=True,
        help="One or more master dataset files (.json/.jsonl/.csv). They are concatenated before splitting.",
    )
    parser.add_argument(
        "--output-dir",
        default="/home/pranava7/mlirbench/dt-2-all-dataset/data",
    )
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()

    frames = []
    for raw_path in args.input:
        path = Path(raw_path).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(path)
        print(f"Loading: {path}")
        frames.append(load_one(path))

    df = normalize_schema(pd.concat(frames, ignore_index=True))

    print("\n" + "=" * 72)
    print("MASTER DATASET CHECK")
    print("=" * 72)
    print("Total:", len(df))
    print("\nDialect counts:")
    print(df["dialect"].value_counts().sort_index())
    print("\nLabel counts:")
    print(df["label"].value_counts().sort_index())

    if len(df) != EXPECTED_TOTAL:
        raise RuntimeError(
            f"Expected exactly {EXPECTED_TOTAL} pairs, found {len(df)}. "
            "Point --input at the complete benchmark, not an existing DT2 split."
        )

    actual_dialects = df["dialect"].value_counts().to_dict()
    if actual_dialects != EXPECTED_DIALECT_COUNTS:
        raise RuntimeError(
            f"Expected dialect counts {EXPECTED_DIALECT_COUNTS}, found {actual_dialects}."
        )

    if df[["program_id", "original_mlir", "mutated_mlir", "label"]].isna().any().any():
        raise RuntimeError("Missing values found in required DT2 fields.")

    df["family_id"] = df["program_id"].apply(family_id)
    df["stratum"] = df["dialect"] + "__" + df["label"]

    print("\nUnderlying families:", df["family_id"].nunique())

    sgkf = StratifiedGroupKFold(
        n_splits=5,
        shuffle=True,
        random_state=args.seed,
    )

    df["fold"] = -1
    for fold_idx, (_, heldout_idx) in enumerate(
        sgkf.split(df, y=df["stratum"], groups=df["family_id"])
    ):
        df.loc[df.index[heldout_idx], "fold"] = fold_idx

    if (df["fold"] < 0).any():
        raise RuntimeError("At least one row was not assigned to a fold.")

    test_df = df[df["fold"] == 0].copy()
    val_df = df[df["fold"] == 1].copy()
    train_df = df[df["fold"].isin([2, 3, 4])].copy()

    train_families = set(train_df["family_id"])
    val_families = set(val_df["family_id"])
    test_families = set(test_df["family_id"])

    overlaps = {
        "train_val": sorted(train_families & val_families),
        "train_test": sorted(train_families & test_families),
        "val_test": sorted(val_families & test_families),
    }

    if any(overlaps.values()):
        raise RuntimeError(f"Family leakage detected: {overlaps}")

    if len(train_df) + len(val_df) + len(test_df) != EXPECTED_TOTAL:
        raise RuntimeError("Split sizes do not sum to 1,768.")

    for split_name, split in (("train", train_df), ("val", val_df), ("test", test_df)):
        observed = set(zip(split["dialect"], split["label"]))
        expected = {(d, l) for d in EXPECTED_DIALECT_COUNTS for l in VALID_LABELS}
        missing_cells = sorted(expected - observed)
        if missing_cells:
            raise RuntimeError(f"{split_name} is missing dialect/label cells: {missing_cells}")

    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Keep family_id in the split files for leakage auditing. Remove internal stratum/fold only.
    save_cols_drop = ["stratum", "fold"]
    train_out = train_df.drop(columns=save_cols_drop)
    val_out = val_df.drop(columns=save_cols_drop)
    test_out = test_df.drop(columns=save_cols_drop)
    all_out = df.drop(columns=["stratum"])

    save_json_records(train_out, output_dir / "train.json")
    save_json_records(val_out, output_dir / "val.json")
    save_json_records(test_out, output_dir / "test.json")
    save_json_records(all_out, output_dir / "all.json")

    train_out.to_csv(output_dir / "train.csv", index=False)
    val_out.to_csv(output_dir / "val.csv", index=False)
    test_out.to_csv(output_dir / "test.csv", index=False)

    metadata = {
        "total": int(len(df)),
        "train": int(len(train_df)),
        "val": int(len(val_df)),
        "test": int(len(test_df)),
        "dialect_counts": {k: int(v) for k, v in df["dialect"].value_counts().to_dict().items()},
        "label_counts": {k: int(v) for k, v in df["label"].value_counts().to_dict().items()},
        "family_count": int(df["family_id"].nunique()),
        "seed": int(args.seed),
        "split_method": "StratifiedGroupKFold(n_splits=5); fold0=test, fold1=val, folds2-4=train",
        "family_overlap": {k: len(v) for k, v in overlaps.items()},
    }

    with (output_dir / "metadata.json").open("w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    split_summary("TRAIN", train_df)
    split_summary("VALIDATION", val_df)
    split_summary("TEST", test_df)

    print("\nSaved all-dataset DT2 splits to:", output_dir)
    print("Metadata:", output_dir / "metadata.json")


if __name__ == "__main__":
    main()
