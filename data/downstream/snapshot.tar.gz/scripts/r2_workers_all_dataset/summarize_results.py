# Put at: /lustre/hdd/LAS/jannesar-lab/pranava7/cgo2027-r1/revised-r1/MLIRBench/scripts/r2_workers_all_dataset/summarize_results.py
import json
from pathlib import Path

import pandas as pd

RUN_DIR = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/outputs/dt2_all-dataset"
)
PRED_DIR = RUN_DIR / "predictions"

metric_files = [
    ("zero-shot", PRED_DIR / "all-dataset_zero_shot_metrics.json"),
    ("6-shot seed 42", PRED_DIR / "all-dataset_6shot_seed_42_metrics.json"),
    ("6-shot seed 123", PRED_DIR / "all-dataset_6shot_seed_123_metrics.json"),
    ("SFT", PRED_DIR / "all-dataset_sft_metrics.json"),
]

rows = []
full = {}

for method, path in metric_files:
    if not path.exists():
        print("Missing, skipping:", path)
        continue

    with path.open("r", encoding="utf-8") as f:
        m = json.load(f)

    full[method] = m
    overall = m["overall"]
    linalg = m.get("by_dialect", {}).get("linalg", {})
    torch_m = m.get("by_dialect", {}).get("torch", {})

    rows.append(
        {
            "method": method,
            "n": m.get("sample_size"),
            "accuracy": overall.get("accuracy"),
            "macro_f1": overall.get("macro_f1"),
            "false_equiv_rate": overall.get("false_equiv_rate"),
            "unsafe_recall": overall.get("unsafe_recall"),
            "linalg_accuracy": linalg.get("accuracy"),
            "linalg_macro_f1": linalg.get("macro_f1"),
            "torch_accuracy": torch_m.get("accuracy"),
            "torch_macro_f1": torch_m.get("macro_f1"),
        }
    )

summary = pd.DataFrame(rows)
summary_path = RUN_DIR / "all-dataset_summary_metrics.csv"
summary.to_csv(summary_path, index=False)

json_path = RUN_DIR / "all-dataset_summary_metrics.json"
with json_path.open("w", encoding="utf-8") as f:
    json.dump(full, f, indent=2)

print("\nALL-DATASET DT2 SUMMARY")
print(summary.to_string(index=False))
print("\nSaved:", summary_path)
print("Saved:", json_path)
