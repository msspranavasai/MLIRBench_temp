# Put at: /lustre/hdd/LAS/jannesar-lab/pranava7/cgo2027-r1/revised-r1/MLIRBench/scripts/r2_workers_all_dataset/common.py
import re

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score

LABELS = ["EQUIV", "DIVERGE", "ERROR"]


def task_text(row):
    dialect = str(row.get("dialect", "unknown")).lower()

    return (
        f"MLIR dialect: {dialect}\n\n"
        "Original MLIR:\n"
        f"```mlir\n{row['original_mlir']}\n```\n\n"
        "Mutated MLIR:\n"
        f"```mlir\n{row['mutated_mlir']}\n```\n\n"
        "Relationship labels:\n"
        "EQUIV\n"
        "DIVERGE\n"
        "ERROR\n\n"
        "Return exactly one label."
    )


def zero_shot_prompt(tokenizer, row):
    messages = [{"role": "user", "content": task_text(row)}]
    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def few_shot_prompt(tokenizer, row, examples):
    messages = []

    for ex in examples:
        messages.append({"role": "user", "content": task_text(ex)})
        messages.append({"role": "assistant", "content": str(ex["label"])})

    messages.append({"role": "user", "content": task_text(row)})

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def extract_label(output):
    if output is None:
        return "INVALID"

    text = str(output).strip()
    if not text:
        return "INVALID"

    first_line = text.splitlines()[0].strip().upper()
    for label in LABELS:
        if re.search(rf"\b{label}\b", first_line):
            return label

    upper = text.upper()
    for label in LABELS:
        if re.search(rf"\b{label}\b", upper):
            return label

    return "INVALID"


def metrics_dict(y_true, y_pred):
    y_true = list(y_true)
    y_pred = list(y_pred)

    accuracy = accuracy_score(y_true, y_pred)
    macro_f1 = f1_score(
        y_true,
        y_pred,
        labels=LABELS,
        average="macro",
        zero_division=0,
    )
    weighted_f1 = f1_score(
        y_true,
        y_pred,
        labels=LABELS,
        average="weighted",
        zero_division=0,
    )
    per_class = f1_score(
        y_true,
        y_pred,
        labels=LABELS,
        average=None,
        zero_division=0,
    )

    unsafe_total = sum(gold in {"DIVERGE", "ERROR"} for gold in y_true)
    false_equiv = sum(
        gold in {"DIVERGE", "ERROR"} and pred == "EQUIV"
        for gold, pred in zip(y_true, y_pred)
    )
    unsafe_correctly_flagged = sum(
        gold in {"DIVERGE", "ERROR"} and pred in {"DIVERGE", "ERROR"}
        for gold, pred in zip(y_true, y_pred)
    )

    cm = confusion_matrix(
        y_true,
        y_pred,
        labels=LABELS + ["INVALID"],
    )

    return {
        "n": int(len(y_true)),
        "accuracy": float(accuracy),
        "macro_f1": float(macro_f1),
        "weighted_f1": float(weighted_f1),
        "per_class_f1": {
            label: float(score)
            for label, score in zip(LABELS, per_class)
        },
        "false_equiv_rate": (
            float(false_equiv / unsafe_total) if unsafe_total else None
        ),
        "unsafe_recall": (
            float(unsafe_correctly_flagged / unsafe_total)
            if unsafe_total
            else None
        ),
        "invalid_count": int(sum(pred == "INVALID" for pred in y_pred)),
        "confusion_matrix_labels": LABELS + ["INVALID"],
        "confusion_matrix": cm.tolist(),
    }


def full_metrics(result_df):
    overall = metrics_dict(result_df["label"], result_df["prediction"])

    by_dialect = {}
    for dialect in sorted(result_df["dialect"].astype(str).unique()):
        subset = result_df[result_df["dialect"] == dialect]
        by_dialect[dialect] = metrics_dict(
            subset["label"],
            subset["prediction"],
        )

    return {
        "sample_size": int(len(result_df)),
        "dialect_counts": {
            str(k): int(v)
            for k, v in result_df["dialect"].value_counts().to_dict().items()
        },
        "label_counts": {
            str(k): int(v)
            for k, v in result_df["label"].value_counts().to_dict().items()
        },
        "overall": overall,
        "by_dialect": by_dialect,
    }
