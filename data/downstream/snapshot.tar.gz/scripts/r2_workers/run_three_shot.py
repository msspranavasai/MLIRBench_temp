import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from tqdm.auto import tqdm

from common import three_shot_prompt, extract_label, metrics_dict


parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, default=42)
args = parser.parse_args()

SEED = args.seed

MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"

DATA_DIR = Path("/home/pranava7/mlirbench/dt-2/data")

OUTPUT_DIR = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/"
    "outputs/dt2_final/predictions"
)

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 16
BATCH_SIZE = 2


with open(DATA_DIR / "train.json", "r", encoding="utf-8") as f:
    train_df = pd.DataFrame(json.load(f))

with open(DATA_DIR / "test.json", "r", encoding="utf-8") as f:
    test_df = pd.DataFrame(json.load(f))


examples = []

for label in ["EQUIV", "DIVERGE", "ERROR"]:
    subset = train_df[
        train_df["label"] == label
    ]

    example = subset.sample(
        n=1,
        random_state=SEED,
    ).iloc[0]

    examples.append(example)


print("3-shot examples:")
for ex in examples:
    print(ex["program_id"], ex["label"])


tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"

# Preflight: verify 3-shot prompts fit in context
prompt_lengths = []

for _, row in test_df.iterrows():
    prompt = three_shot_prompt(
        tokenizer,
        row,
        examples,
    )

    length = len(
        tokenizer(
            prompt,
            add_special_tokens=False,
        )["input_ids"]
    )

    prompt_lengths.append(length)

print("\n3-shot prompt lengths:")
print("Min:", min(prompt_lengths))
print("Mean:", sum(prompt_lengths) / len(prompt_lengths))
print("Max:", max(prompt_lengths))

if max(prompt_lengths) > MAX_SEQ_LEN:
    raise RuntimeError(
        f"3-shot prompt exceeds context limit: "
        f"{max(prompt_lengths)} > {MAX_SEQ_LEN}"
    )

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

print(
    "Model loaded. GPU memory:",
    round(torch.cuda.memory_allocated() / 1024**3, 2),
    "GB allocated"
)

model.eval()


predictions = []
raw_outputs = []

for start in tqdm(
    range(0, len(test_df), BATCH_SIZE),
    desc=f"3-shot seed {SEED}",
):
    batch = test_df.iloc[
        start:start + BATCH_SIZE
    ]

    prompts = [
        three_shot_prompt(
            tokenizer,
            row,
            examples,
        )
        for _, row in batch.iterrows()
    ]

    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=MAX_SEQ_LEN,
    ).to("cuda")

    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    input_len = inputs["input_ids"].shape[1]

    for output in outputs:
        raw = tokenizer.decode(
            output[input_len:],
            skip_special_tokens=True,
        ).strip()

        raw_outputs.append(raw)
        predictions.append(extract_label(raw))


result = test_df.copy()
result["prediction"] = predictions
result["raw_output"] = raw_outputs
result["correct"] = result["prediction"] == result["label"]

output_path = (
    OUTPUT_DIR
    / f"three_shot_seed_{SEED}_predictions.csv"
)

result.to_csv(output_path, index=False)

metrics = metrics_dict(
    result["label"],
    result["prediction"],
)

with open(
    OUTPUT_DIR
    / f"three_shot_seed_{SEED}_metrics.json",
    "w",
    encoding="utf-8",
) as f:
    json.dump(metrics, f, indent=2)

print(metrics)
print("Saved:", output_path)