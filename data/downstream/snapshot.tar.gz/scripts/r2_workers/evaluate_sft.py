import json
from pathlib import Path

import pandas as pd
import torch

from peft import PeftModel

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
)

from tqdm.auto import tqdm

from common import (
    zero_shot_prompt,
    extract_label,
    metrics_dict,
)


MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"

DATA_PATH = Path(
    "/home/pranava7/mlirbench/dt-2/data/test.json"
)

RUN_DIR = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/"
    "outputs/dt2_final"
)

ADAPTER_DIR = RUN_DIR / "adapter"
OUTPUT_DIR = RUN_DIR / "predictions"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

MAX_SEQ_LEN = 32768
MAX_NEW_TOKENS = 16
BATCH_SIZE = 4


with open(DATA_PATH, "r", encoding="utf-8") as f:
    df = pd.DataFrame(json.load(f))


tokenizer = AutoTokenizer.from_pretrained(
    ADAPTER_DIR,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "left"


base_model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    device_map={"": 0},
    trust_remote_code=True,
)

model = PeftModel.from_pretrained(
    base_model,
    ADAPTER_DIR,
)

model.eval()


predictions = []
raw_outputs = []

for start in tqdm(
    range(0, len(df), BATCH_SIZE),
    desc="SFT evaluation",
):
    batch = df.iloc[
        start:start + BATCH_SIZE
    ]

    prompts = [
        zero_shot_prompt(tokenizer, row)
        for _, row in batch.iterrows()
    ]

    inputs = tokenizer(
        prompts,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=MAX_SEQ_LEN,
    ).to("cuda")

    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    input_len = inputs["input_ids"].shape[1]

    for output in outputs:
        raw = tokenizer.decode(
            output[input_len:],
            skip_special_tokens=True,
        ).strip()

        raw_outputs.append(raw)
        predictions.append(
            extract_label(raw)
        )


result = df.copy()

result["prediction"] = predictions
result["raw_output"] = raw_outputs
result["correct"] = (
    result["prediction"]
    == result["label"]
)

output_path = (
    OUTPUT_DIR
    / "sft_predictions.csv"
)

result.to_csv(
    output_path,
    index=False,
)

metrics = metrics_dict(
    result["label"],
    result["prediction"],
)

with open(
    OUTPUT_DIR / "sft_metrics.json",
    "w",
    encoding="utf-8",
) as f:
    json.dump(
        metrics,
        f,
        indent=2,
    )

print(metrics)
print("Saved:", output_path)