import re
import numpy as np
from sklearn.metrics import accuracy_score, f1_score

LABELS = ["EQUIV", "DIVERGE", "ERROR"]


def task_text(row):
    return (
        "Original MLIR:\n"
        f"```mlir\n{row['original_mlir']}\n```\n\n"
        "Mutated MLIR:\n"
        f"```mlir\n{row['mutated_mlir']}\n```\n\n"
        "Relationship labels:\n"
        "EQUIV\n"
        "DIVERGE\n"
        "ERROR\n\n"
        "Return exactly one label."
    )


def zero_shot_prompt(tokenizer, row):
    messages = [
        {
            "role": "user",
            "content": task_text(row),
        }
    ]

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def three_shot_prompt(tokenizer, row, examples):
    messages = []

    for ex in examples:
        messages.append(
            {
                "role": "user",
                "content": task_text(ex),
            }
        )

        messages.append(
            {
                "role": "assistant",
                "content": str(ex["label"]),
            }
        )

    messages.append(
        {
            "role": "user",
            "content": task_text(row),
        }
    )

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def extract_label(output):
    if output is None:
        return "INVALID"

    text = str(output).strip()

    if not text:
        return "INVALID"

    first_line = text.splitlines()[0].strip().upper()

    for label in LABELS:
        if re.search(rf"\b{label}\b", first_line):
            return label

    text_upper = text.upper()

    for label in LABELS:
        if re.search(rf"\b{label}\b", text_upper):
            return label

    return "INVALID"


def metrics_dict(y_true, y_pred):
    y_true = list(y_true)
    y_pred = list(y_pred)

    accuracy = accuracy_score(y_true, y_pred)

    macro_f1 = f1_score(
        y_true,
        y_pred,
        labels=LABELS,
        average="macro",
        zero_division=0,
    )

    unsafe_total = sum(
        gold in {"DIVERGE", "ERROR"}
        for gold in y_true
    )

    false_equiv = sum(
        gold in {"DIVERGE", "ERROR"} and pred == "EQUIV"
        for gold, pred in zip(y_true, y_pred)
    )

    unsafe_correctly_flagged = sum(
        gold in {"DIVERGE", "ERROR"}
        and pred in {"DIVERGE", "ERROR"}
        for gold, pred in zip(y_true, y_pred)
    )

    return {
        "accuracy": float(accuracy),
        "macro_f1": float(macro_f1),
        "false_equiv_rate": (
            float(false_equiv / unsafe_total)
            if unsafe_total else np.nan
        ),
        "unsafe_recall": (
            float(unsafe_correctly_flagged / unsafe_total)
            if unsafe_total else np.nan
        ),
        "invalid_count": int(
            sum(pred == "INVALID" for pred in y_pred)
        ),
    }