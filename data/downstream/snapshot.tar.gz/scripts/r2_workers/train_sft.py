import json
from pathlib import Path

import pandas as pd
import torch

from datasets import Dataset

from peft import (
    LoraConfig,
    get_peft_model,
)

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    DataCollatorForLanguageModeling,
    Trainer,
    TrainingArguments,
)


MODEL_NAME = "Qwen/Qwen2.5-Coder-14B-Instruct"

DATA_DIR = Path("/home/pranava7/mlirbench/dt-2/data")

RUN_DIR = Path(
    "/lustre/hdd/LAS/jannesar-lab/pranava7/"
    "cgo2027-r1/revised-r1/MLIRBench/"
    "outputs/dt2_final"
)

ADAPTER_DIR = RUN_DIR / "adapter"
CHECKPOINT_DIR = RUN_DIR / "checkpoints"

ADAPTER_DIR.mkdir(parents=True, exist_ok=True)
CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

TRAIN_MAX_SEQ_LEN = 12288
SEED = 42


with open(DATA_DIR / "train.json", "r", encoding="utf-8") as f:
    train_df = pd.DataFrame(json.load(f))

with open(DATA_DIR / "val.json", "r", encoding="utf-8") as f:
    val_df = pd.DataFrame(json.load(f))


if "text" not in train_df.columns:
    raise RuntimeError(
        "train.json does not contain the existing SFT 'text' field."
    )

if "text" not in val_df.columns:
    raise RuntimeError(
        "val.json does not contain the existing SFT 'text' field."
    )


tokenizer = AutoTokenizer.from_pretrained(
    MODEL_NAME,
    trust_remote_code=True,
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.padding_side = "right"


train_dataset = Dataset.from_pandas(
    train_df[["text"]].reset_index(drop=True)
)

val_dataset = Dataset.from_pandas(
    val_df[["text"]].reset_index(drop=True)
)


def tokenize(batch):
    return tokenizer(
        batch["text"],
        truncation=True,
        max_length=TRAIN_MAX_SEQ_LEN,
        padding=False,
    )


train_dataset = train_dataset.map(
    tokenize,
    batched=True,
    remove_columns=train_dataset.column_names,
)

val_dataset = val_dataset.map(
    tokenize,
    batched=True,
    remove_columns=val_dataset.column_names,
)


model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    dtype=torch.bfloat16,
    low_cpu_mem_usage=True,
    trust_remote_code=True,
)

model.config.use_cache = False
model.gradient_checkpointing_enable()


lora_config = LoraConfig(
    r=64,
    lora_alpha=128,
    lora_dropout=0.0,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=[
        "q_proj",
        "k_proj",
        "v_proj",
        "o_proj",
        "gate_proj",
        "up_proj",
        "down_proj",
    ],
)

model = get_peft_model(
    model,
    lora_config,
)

model.print_trainable_parameters()


collator = DataCollatorForLanguageModeling(
    tokenizer=tokenizer,
    mlm=False,
)


training_args = TrainingArguments(
    output_dir=str(CHECKPOINT_DIR),

    num_train_epochs=6,

    per_device_train_batch_size=1,
    per_device_eval_batch_size=1,

    gradient_accumulation_steps=4,

    learning_rate=1e-4,

    bf16=True,

    logging_steps=5,

    eval_strategy="epoch",
    save_strategy="epoch",

    save_total_limit=2,

    report_to="none",

    seed=SEED,

    ddp_find_unused_parameters=False,

    remove_unused_columns=False,
)


trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    data_collator=collator,
)


trainer.train()

trainer.save_model(
    str(ADAPTER_DIR)
)

tokenizer.save_pretrained(
    str(ADAPTER_DIR)
)

print(
    f"Saved adapter to {ADAPTER_DIR}"
)